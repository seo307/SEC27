# Artifact Evaluation Guide

## Recommended reviewer workflow

### Phase A — Kick the tires
1. Unpack the artifact.
2. Run `./run_smoke.sh`.
3. Confirm all checks return PASS.

### Phase B — Reproduce paper tables
Run `./run_reproduce.sh`.

Compare:
- `reproduced/REPRODUCED_ABLATION.csv`
- `data/final_evaluation/FINAL_ABLATION_RESULTS.csv`

The script also recomputes the formal zero-failure Clopper–Pearson upper bound and checks the two method-pair equivalences.

### Phase C — Inspect blinding
Inspect:
- `casepack_agent_blinded.jsonl`
- `casepack_oracle.jsonl`
- `casepack_case_map.jsonl`
- `PRE_AGENT_MANIFEST.sha256`

The agent-facing file intentionally excludes oracle truth, ideal decisions, scenario labels, and original case names.

### Phase D — Inspect source
Relevant implementation:
- `source_snapshot/orchestrator/finding_service.py`
- `source_snapshot/orchestrator/proof_bundle.py`
- `source_snapshot/orchestrator/proof_obligations.py`
- `source_snapshot/research/risk_controlled_confirmation_experiment/risk_statistics.py`
- `source_snapshot/research/risk_controlled_confirmation_experiment/provenance.py`
- `source_snapshot/research/risk_controlled_confirmation_experiment/phase2/final_evaluation.py`

### Phase E — Optional live rerun
Not required for reproducing paper results. Live agent calls consume external API resources and may not be deterministic over time. Live acquisition additionally requires Docker/Compose and deliberately vulnerable public benchmarks.

## What should not be treated as formal independent N
- the 12 controlled stress cases,
- their repetitions,
- challenge transformations,
- the Phase-2 Juice Shop candidate in the final casepack.

These are included for mechanism evaluation only.
