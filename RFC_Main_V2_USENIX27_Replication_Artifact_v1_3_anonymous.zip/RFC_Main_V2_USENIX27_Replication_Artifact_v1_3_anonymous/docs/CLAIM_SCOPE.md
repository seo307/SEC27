# Claim scope for the revised submission — v1.3

## Primary empirical claim
The paper's primary empirical result is the separation between **vulnerability truth** and **evidentiary justification**. Five frozen cases are ambiguous positives: the environment is genuinely vulnerable, but the predeclared ideal decision is ABSTAIN because the current evidence is insufficient for autonomous promotion. The blinded GPT-5.4 baseline over-confirms 2/5 of these cases. This is an **existence demonstration** on a frozen, deliberately constructed set, not an estimate of a population-level or model-wide over-confirmation rate.

## Secondary assurance claim
Environment-level independence is part of an assurance claim, not bookkeeping. The current formal registry has 7 independent certification confirmations and 0 observed false confirmations, but the one-sided 95% exact upper bound is 0.348, so q=.10 remains NOT READY. A pseudo-independence counterfactual shows that duplicating the same observations can create spurious nominal assurance.

## Reference-mechanism claim
The ProofBundle gate is presented as an explicit, auditable evidence-admission contract. It binds claims to executed evidence, target/deployment continuity, provenance, artifact integrity, contradictions, and family-specific obligations.

The frozen casepack does **not** establish a causal estimate of the family-specific obligations. All 12 controlled-stress cases are rejected by proof-gate-only, and a post-hoc cohort heuristic reproduces the frozen proof-gate decisions. This limitation is explicit in the paper.

## Claims not made
The revised paper does **not** claim:
- that zero unsupported confirmations under proof gating is an independent empirical gain;
- that structural gating improves symmetric decision accuracy;
- that the frozen casepack causally isolates family-specific ProofBundle obligations;
- that the statistical layer changes any of the 24 per-case decisions;
- that the current data certify FCR <= 0.10;
- that the 1.5 cost break-even value estimates real organizational costs;
- a population over-confirmation rate from the 2/5 ambiguous-positive count;
- cross-model generality beyond the frozen GPT-5.4 agent baseline.

## Cost sensitivity scope
The ratio 1.5 follows deterministically from the frozen casepack decision counts (2 unsafe promotions avoided versus 3 additional ideal-confirm abstentions). It is retained only as a local sensitivity calculation. It is not a population parameter, does not receive a confidence interval, and has no claimed external validity.
