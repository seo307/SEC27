# v1.3 Revision Notes

v1.3 changes paper ordering and claim scope; it adds no new experimental observations and formal N remains unchanged.

- Ambiguous-positive evidentiary over-confirmation is the first research question and first evaluation result.
- GPT-5.4's 2/5 ambiguous-positive confirmations are scoped as an existence demonstration, not a population-rate estimate.
- Structural admission and confidence become the second and third research questions.
- The paper distinguishes CSAF/VEX product-level vulnerability status from RFC's execution-level evidence state: a vulnerable environment may be admissible to confirm in one execution state and require abstention in another.
- Cross-model generality is not claimed. No additional model outputs are added in v1.3.
- All v1.3 read-only sensitivity and confounding analyses are retained.
- Raw experimental data and formal N are unchanged.
