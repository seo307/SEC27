# USENIX Security '27 Submission-Time Artifact Guide

This package is prepared for anonymous submission-time review.

## Recommended hosting

Use an anonymous, non-tracking artifact host. The USENIX Security '27 CFP
recommends anonymous.4open.science and conference ID `SEC27`.

Before the paper submission deadline:
1. Create the anonymous artifact location and obtain its stable anonymous URL.
2. Upload this ZIP without changing its contents.
3. Put that same anonymous URL in the paper's **Open Science** appendix.

During the three-day artifact grace period, the artifact may be finalized at
the already-referenced anonymous location. The manuscript itself cannot be
changed during that grace period. After the grace period, treat the artifact
as frozen.

## Reviewer quick path

```bash
unzip RFC_Main_V2_USENIX27_Replication_Artifact_v1_0_anonymous.zip
cd RFC_Main_V2_USENIX27_Replication_Artifact_v1_0_anonymous
python3 scripts/verify_artifact.py
./run_smoke.sh
./run_reproduce.sh
```

The primary reproduction path does not require a network connection, Docker,
or an API key.

## Double-blind note

Do not add author names, organization names, personal repository URLs, local
user paths, or identifying commit history to the anonymous artifact. See
`ANONYMIZATION_REPORT.json` and `SANITIZATION_MAP.json`.
