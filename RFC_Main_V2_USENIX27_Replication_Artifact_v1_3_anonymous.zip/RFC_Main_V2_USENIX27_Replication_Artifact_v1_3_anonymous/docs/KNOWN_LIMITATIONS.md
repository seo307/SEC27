# Known Artifact Limitations

1. The frozen raw-agent baseline uses one hosted model identifier (`gpt-5.4`). Hosted services can change; therefore a live rerun is not expected to be byte-identical. The exact responses used by the paper are included.
2. The final 24-case ablation contributes formal N=0. Formal certification is computed only from the explicitly accepted external registry.
3. The structural proof gate and full RFC produce identical per-case decisions on this frozen casepack. The risk layer's distinct role is corpus-level certification/refusal.
4. The scientific registry has only seven independent certification confirmations; the q=.10 certificate is therefore NOT READY.
5. The source snapshot is curated to the paper-relevant mechanism and experiment code, not the entire larger application repository.
6. Third-party benchmark source trees are not redistributed. Their provenance appears in frozen run records; optional live reruns may fetch public benchmark sources.
7. One Phase-2 Juice Shop candidate is excluded from formal registry admission because its independent source-only oracle was frozen post-capture.


## Revision-specific claim limits

- `unsupported_confirmations=0` for proof-gated methods is by construction and is diagnostic only.
- Symmetric decision accuracy is lower for proof-gate-only (87.5%) than validator-only (91.7%).
- The simple cost analysis is a deterministic sensitivity calculation induced by the frozen casepack composition; the 1.5 break-even value is not a population parameter, does not estimate operational costs, and has no claimed confidence interval or external validity.
- All 12 controlled-stress cases are rejected by proof-gate-only. A post-hoc cohort heuristic matches proof-gate-only on 24/24 cases, so the frozen casepack does not isolate family-specific ProofBundle obligations as the unique causal mechanism.
- The statistical risk layer does not change any of the 24 per-case decisions. Its observed contribution is process-level certificate refusal and independence-aware assurance accounting.
- The raw-agent evaluation uses one GPT-5.4 snapshot and does not establish cross-model generality.

- The 2/5 ambiguous-positive result is an existence demonstration on five deliberately constructed frozen cases, not a population-rate estimate. No confidence interval is used to imply a sampling population that the casepack does not represent.
- The raw-agent baseline is a single GPT-5.4 snapshot. Cross-model replication on the same predeclared 24 blinded inputs is future work and is not included in v1.3.
