# Third-Party Components

The artifact does not redistribute full third-party benchmark repositories. The research used public, intentionally vulnerable benchmark environments and frozen source/runtime provenance where applicable, including Vulhub and OWASP projects such as Juice Shop.

The frozen-result reproduction path does not need these third-party repositories.

Optional live acquisition must use only authorized, local/public intentionally vulnerable environments and should follow the source identifiers/commits recorded in the frozen run artifacts and Phase-2 provenance.
