# v1.2 Revision Notes

This package updates **claim scope and read-only derived analysis metadata only**. It adds no new experimental cases and changes no frozen experimental record.

Changes relative to v1.1:
1. Measurement-first framing: ambiguous-positive over-confirmation is the primary empirical result.
2. Structural-gate results are described as case-level decision differences with explicit controlled-cohort confounding.
3. The `unsupported_confirmations=0` result remains diagnostic and by construction.
4. The 1.5 cost break-even value is explicitly marked as deterministic and casepack-composition-dependent, with no external-validity or confidence-interval claim.
5. Risk-sensitivity and pseudo-independence analyses remain unchanged and formal N remains 0.
6. Paper-side rendering uses a bold indicator symbol (`\mathbf{1}`) rather than a broken blackboard-bold digit.
7. Learn-then-Test is identified as arXiv preprint arXiv:2110.01052 (2021).

Frozen raw data: unchanged.
Formal N added by v1.2: 0.
