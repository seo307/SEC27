# Revision-only analyses — v1.3

These analyses are read-only transformations of the original frozen evaluation. They modify no raw experimental record and contribute formal N=0.

## Ambiguous-positive measurement
The primary empirical failure mode is preserved from the frozen evaluation: five cases have `vulnerable=true` and `ideal_decision=abstain`. The blinded GPT-5.4 baseline confirms 2/5; the validator confirms 1/5; proof-gated methods abstain on all five.

**Interpretation limit:** the five cases are deliberately constructed and frozen rather than sampled from a defined population. v1.3 therefore treats 2/5 as an existence demonstration and does not infer a model-wide probability or attach a population confidence interval.

## Cost sensitivity
The frozen 24-case comparison has:
- validator-only: 2 unsafe promotions, 0 missed ideal-confirm cases;
- proof-gate-only: 0 unsafe promotions, 3 missed ideal-confirm cases.

For `L = C_H * unsafe + C_A * missed_ideal`, the arithmetic break-even ratio is `C_H/C_A = 1.5`.

**Interpretation limit:** this ratio is determined by the composition of the frozen casepack, particularly the controlled-stress cohort. It is not an estimate of a deployment cost distribution or a population parameter, so no confidence interval or external-validity claim is attached to it.

## Certification sensitivity
Using the same one-sided 95% zero-failure Clopper-Pearson calculation:
- q=.20 requires at least 14 independent confirmations;
- q=.10 requires at least 29;
- q=.05 requires at least 59.

## Pseudo-independence
The artifact deliberately does not count repeats as independent. As a counterfactual illustration, if the same seven zero-failure confirmations were incorrectly counted 5 times, nominal N=35 would yield an upper bound near 0.082 and falsely appear to pass q=.10.

## Controlled-cohort confounding
All 12 `internal_controlled_stress` cases are rejected by proof-gate-only. The post-hoc heuristic

`ABSTAIN if cohort == internal_controlled_stress; otherwise copy validator-only`

matches the frozen proof-gate decisions on 24/24 cases.

Therefore the current casepack does not causally isolate family-specific ProofBundle obligations from cohort construction. v1.3 narrows the mechanism claim instead of adding synthetic post-submission cases.
