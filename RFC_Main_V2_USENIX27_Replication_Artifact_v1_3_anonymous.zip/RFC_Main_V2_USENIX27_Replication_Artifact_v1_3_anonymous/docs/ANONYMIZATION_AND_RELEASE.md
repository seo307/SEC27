# Anonymization and Release Checklist

The submission artifact must remain double-blind.

Before upload:
1. Run `python3 scripts/anonymization_scan.py`.
2. Confirm `ANONYMIZATION_REPORT.json` reports PASS.
3. Do not add Git history or account-identifying repository metadata.
4. Do not upload API keys, `.env` files, shell histories, home-directory paths, or organization-specific paths.
5. Use an anonymous, non-tracking hosting URL.
6. Do not use a personal GitHub account or analytics-enabled link during review.
7. After the artifact grace period, do not mutate the hosted artifact.
8. If accepted, replace the anonymous URL with a stable public link in the camera-ready Open Science appendix.

The package deliberately excludes third-party cloned source repositories and unrelated project code.
