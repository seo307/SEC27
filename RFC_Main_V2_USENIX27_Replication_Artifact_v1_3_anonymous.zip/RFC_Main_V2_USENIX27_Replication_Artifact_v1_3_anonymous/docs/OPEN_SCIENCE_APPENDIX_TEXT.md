# Open Science Appendix Text (Revised)

For double-blind review, the replication artifact is available at:

https://anonymous.4open.science/r/SEC27-DE67/

The artifact contains the RFC implementation, frozen method rules, immutable acquisition/evaluation outputs needed to reproduce the reported tables, the scientific environment registry, blinded agent inputs, frozen GPT-5.4 outputs, separately stored oracle rows, and SHA-256 manifests.

Artifact v1.3 additionally contains **read-only derived analyses** used in the revised manuscript: cost break-even sensitivity, zero-failure certification sensitivity, a pseudo-independence counterfactual, and a controlled-cohort confounding audit. These analyses do not modify raw experimental outputs and contribute formal N=0.

The primary reproduction path requires only Python 3.9+ and no network/API/Docker. Optional live reruns require external model credentials and/or Docker and are not needed to reproduce the reported frozen results.
