#!/usr/bin/env python3
"""Recompute the paper's final ablation metrics and formal risk checkpoint.

Requires Python >=3.9 and only the standard library.
Does NOT contact external services and does NOT modify frozen data.
"""
from pathlib import Path
import argparse, csv, json, math, hashlib

METHOD_FIELDS = [
    ("agent_raw", "agent_raw_decision"),
    ("validator_only", "validator_only_decision"),
    ("proof_gate_only", "proof_gate_only_decision"),
    ("confidence_threshold", "confidence_threshold_decision"),
    ("rfc_full", "rfc_full_decision"),
]

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
def read_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]

def metrics(rows, field):
    n=len(rows)
    confirms=sum(r[field]=="confirm" for r in rows)
    false=sum(r[field]=="confirm" and r.get("vulnerable") is False for r in rows)
    abst=n-confirms
    ideal_conf=sum(r.get("ideal_decision")=="confirm" for r in rows)
    recall=sum(r.get("ideal_decision")=="confirm" and r[field]=="confirm" for r in rows)
    correct=sum(r[field]==r.get("ideal_decision") for r in rows)
    unsafe=sum(r[field]=="confirm" and r.get("ideal_decision")!="confirm" for r in rows)
    unsupported=sum(r[field]=="confirm" and r.get("proof_gate_only_decision")!="confirm" for r in rows)
    amb=sum(r[field]=="confirm" and r.get("scenario_kind")=="ambiguous_positive" and r.get("ideal_decision")!="confirm" for r in rows)
    return {
        "n":n, "confirmations":confirms, "false_confirmations":false,
        "false_confirmation_rate": false/confirms if confirms else None,
        "coverage": confirms/n if n else None,
        "abstention_rate": abst/n if n else None,
        "ideal_confirm_recall": recall/ideal_conf if ideal_conf else None,
        "decision_accuracy": correct/n if n else None,
        "unsafe_promotions":unsafe,
        "unsafe_promotion_rate": unsafe/confirms if confirms else None,
        "unsupported_confirmations":unsupported,
        "unsupported_confirmation_rate": unsupported/confirms if confirms else None,
        "ambiguous_positive_overconfirmations":amb,
    }

def group_metrics(rows, key):
    out={}
    for val in sorted({str(r.get(key)) for r in rows}):
        rr=[r for r in rows if str(r.get(key))==val]
        out[val]={m:metrics(rr,f) for m,f in METHOD_FIELDS}
    return out

def approx_equal(a,b,tol=1e-12):
    if a is None or b is None: return a is b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        return abs(float(a)-float(b))<=tol
    return a==b

def compare_dict(calc, frozen, path=""):
    issues=[]
    if isinstance(calc,dict) and isinstance(frozen,dict):
        for k,v in calc.items():
            if k not in frozen: issues.append(f"{path}/{k}: missing in frozen")
            else: issues += compare_dict(v,frozen[k],f"{path}/{k}")
    else:
        if not approx_equal(calc,frozen):
            issues.append(f"{path}: computed={calc!r}, frozen={frozen!r}")
    return issues

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--artifact-root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--output-dir", default=None)
    args=ap.parse_args()
    root=Path(args.artifact_root)
    data=root/"data"/"final_evaluation"
    rows=read_jsonl(data/"ablation_rows.jsonl")
    frozen=read_json(data/"FINAL_ABLATION_RESULTS.json")
    overall={m:metrics(rows,f) for m,f in METHOD_FIELDS}
    calc={
        "overall":overall,
        "by_category":group_metrics(rows,"category"),
        "by_scenario":group_metrics(rows,"scenario_kind"),
        "by_cohort":group_metrics(rows,"cohort"),
    }
    issues=[]
    for k in calc:
        issues += compare_dict(calc[k], frozen[k], k)

    # Formal checkpoint: exact one-sided 95% CP upper bound for k=0.
    fp=read_json(data/"formal_progress.json")
    n=int(fp["certification_confirmations"])
    k=int(fp["false_confirmations_observed"])
    if k != 0:
        issues.append("This frozen reproducer implements the closed-form k=0 checkpoint only.")
        cp=None
    else:
        cp=1 - 0.05**(1/n) if n>0 else None
        if not approx_equal(cp, fp["one_sided_cp_upper_at_95pct"]):
            issues.append(f"formal CP mismatch: computed={cp}, frozen={fp['one_sided_cp_upper_at_95pct']}")
    ready=bool(cp is not None and cp<=0.10)
    if ready != bool(fp["formal_certificate_ready_at_q_0_10"]):
        issues.append("formal certificate readiness mismatch")

    # Key equivalence / ambiguity checks reported in the paper.
    validator_eq_conf=all(r["validator_only_decision"]==r["confidence_threshold_decision"] for r in rows)
    proof_eq_full=all(r["proof_gate_only_decision"]==r["rfc_full_decision"] for r in rows)
    ambiguous=[r for r in rows if r.get("scenario_kind")=="ambiguous_positive"]
    agent_amb_over=sum(r["agent_raw_decision"]=="confirm" and r["ideal_decision"]!="confirm" for r in ambiguous)

    summary={
        "status":"PASS" if not issues else "FAIL",
        "rows":len(rows),
        "overall":overall,
        "validator_equals_confidence_threshold_all_cases":validator_eq_conf,
        "proof_gate_equals_rfc_full_all_cases":proof_eq_full,
        "ambiguous_positive_cases":len(ambiguous),
        "agent_ambiguous_positive_overconfirmations":agent_amb_over,
        "formal":{
            "certification_confirmations":n,
            "false_confirmations":k,
            "cp_upper_95_one_sided":cp,
            "q":0.10,
            "certificate_ready":ready,
        },
        "issues":issues,
    }
    outdir=Path(args.output_dir) if args.output_dir else root/"reproduced"
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/"REPRODUCED_RESULTS.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    with (outdir/"REPRODUCED_ABLATION.csv").open("w",newline="",encoding="utf-8") as f:
        cols=["method","n","confirmations","false_confirmations","false_confirmation_rate","coverage","abstention_rate","ideal_confirm_recall","decision_accuracy","unsafe_promotions","unsafe_promotion_rate","unsupported_confirmations","unsupported_confirmation_rate","ambiguous_positive_overconfirmations"]
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
        for m,_ in METHOD_FIELDS: w.writerow({"method":m,**overall[m]})
    print(json.dumps(summary,indent=2,sort_keys=True))
    return 0 if not issues else 2

if __name__=="__main__":
    raise SystemExit(main())
