#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json
def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
    return h.hexdigest()
def verify_manifest(root, manifest, allowed_missing=None):
    allowed_missing=set(allowed_missing or [])
    issues=[]; checked=0; skipped=[]
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        h, rel=line.split("  ",1)
        p=root/rel
        if not p.is_file():
            if rel in allowed_missing:
                skipped.append(rel); continue
            issues.append(f"missing: {rel}"); continue
        got=sha(p); checked+=1
        if got!=h: issues.append(f"hash mismatch: {rel}")
    return checked,issues,skipped
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--artifact-root",default=str(Path(__file__).resolve().parents[1]))
    args=ap.parse_args(); root=Path(args.artifact_root)
    checked,issues,skipped=verify_manifest(root,root/"MANIFEST.sha256")
    fed=root/"data"/"final_evaluation"
    allowed={"RUN_DIR.txt","agent_outputs/openai-gpt-5.4.summary.json"}
    for mn in ["PRE_AGENT_MANIFEST.sha256","FINAL_MANIFEST.sha256"]:
        p=fed/mn
        if p.is_file():
            c,iss,sk=verify_manifest(fed,p,allowed_missing=allowed); checked+=c; issues += [f"{mn}: {x}" for x in iss]; skipped += [f"{mn}:{x}" for x in sk]
    rep={"status":"PASS" if not issues else "FAIL","files_checked":checked,"sanitized_historical_manifest_entries_skipped":skipped,"issues":issues}
    print(json.dumps(rep,indent=2))
    return 0 if not issues else 2
if __name__=="__main__": raise SystemExit(main())
