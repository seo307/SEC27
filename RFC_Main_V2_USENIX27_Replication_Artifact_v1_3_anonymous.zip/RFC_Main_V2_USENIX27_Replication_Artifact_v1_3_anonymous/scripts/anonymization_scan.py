#!/usr/bin/env python3
from pathlib import Path
import re, sys, zipfile, json
root=Path(__file__).resolve().parents[1]
# Patterns are assembled to avoid self-matching in this scanner source.
patterns={
 "author_name":re.compile("Paul"+"\\s+"+"Seo",re.I),
 "user_handle":re.compile("seo"+"307",re.I),
 "host_marker":re.compile("thefin"+"-024",re.I),
 "personal_email":re.compile(r"[\w.+-]+@"+"gmail"+r"\.com",re.I),
 "home_path":re.compile(r"/"+"home"+r"/[A-Za-z0-9_.-]+/"),
}
text_ext={".md",".txt",".py",".sh",".json",".jsonl",".csv",".yml",".yaml",".toml",".ini",".cfg"}
hits=[]
def scan_text(label,text):
    for name,p in patterns.items():
        for m in p.finditer(text):
            hits.append({"pattern":name,"file":label})
for p in root.rglob("*"):
    if not p.is_file() or p.name in {"ANONYMIZATION_REPORT.json","anonymization_scan.py"}:
        continue
    if p.suffix.lower() in text_ext:
        try: scan_text(str(p.relative_to(root)),p.read_text(encoding="utf-8",errors="ignore"))
        except Exception: pass
    elif p.suffix.lower()==".zip":
        try:
            with zipfile.ZipFile(p) as z:
                for i in z.infolist():
                    if i.is_dir() or Path(i.filename).suffix.lower() not in text_ext or i.file_size>5_000_000: continue
                    try: scan_text(str(p.relative_to(root))+"::"+i.filename,z.read(i).decode("utf-8","ignore"))
                    except Exception: pass
        except Exception: pass
rep={"status":"PASS" if not hits else "FAIL","hits":hits}
(root/"ANONYMIZATION_REPORT.json").write_text(json.dumps(rep,indent=2)+"\n",encoding="utf-8")
print(json.dumps(rep,indent=2))
sys.exit(0 if not hits else 2)
