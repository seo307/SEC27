#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
d=root/"data"/"final_evaluation"
case=json.loads((d/"CASEPACK_SUMMARY.json").read_text())
formal=json.loads((d/"formal_progress.json").read_text())
agent_rows=[json.loads(x) for x in (d/"agent_outputs"/"openai-gpt-5.4.jsonl").read_text().splitlines() if x.strip()]
agent_ok=sum((r.get("decision") in {"confirm","abstain"} and r.get("status")=="PASS") for r in agent_rows)
checks={
 "casepack_24":case.get("cases")==24,
 "six_categories":len(case.get("categories",{}))==6,
 "registry_11":case.get("registry_accepted_cases")==11,
 "internal_stress_12":case.get("internal_stress_cases")==12,
 "agent_24_of_24":len(agent_rows)==24 and agent_ok==24,
 "formal_n_7":formal.get("certification_confirmations")==7,
 "formal_false_0":formal.get("false_confirmations_observed")==0,
 "certificate_not_ready":formal.get("formal_certificate_ready_at_q_0_10") is False,
}
bad=[k for k,v in checks.items() if not v]
print(json.dumps({"status":"PASS" if not bad else "FAIL","checks":checks,"failed":bad},indent=2))
sys.exit(0 if not bad else 2)
