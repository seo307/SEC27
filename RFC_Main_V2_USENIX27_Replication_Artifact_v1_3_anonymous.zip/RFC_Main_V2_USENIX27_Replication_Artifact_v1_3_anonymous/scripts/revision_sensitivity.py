#!/usr/bin/env python3
"""Read-only revision analyses over the frozen 24-case evaluation.

No raw input is modified. All outputs are derived artifacts with formal_n_contribution=0.
Standard-library only.
"""
from pathlib import Path
import argparse, csv, json, math

def read_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]

def cp_upper_zero(n, alpha=0.05):
    return 1.0 - alpha ** (1.0/n) if n > 0 else None

def min_n_zero(q, alpha=0.05, max_n=100000):
    for n in range(1, max_n+1):
        if cp_upper_zero(n, alpha) <= q:
            return n
    raise RuntimeError("search bound exceeded")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--artifact-root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--output-dir", default=None)
    args=ap.parse_args()
    root=Path(args.artifact_root)
    data=root/"data"/"final_evaluation"
    out=Path(args.output_dir) if args.output_dir else root/"derived_revision"
    out.mkdir(parents=True, exist_ok=True)
    rows=read_jsonl(data/"ablation_rows.jsonl")

    # Cost sensitivity: harmful promotion = ideal_decision != confirm and method confirms.
    # Missed ideal = ideal_decision == confirm and method abstains.
    methods={
        "validator_only":"validator_only_decision",
        "proof_gate_only":"proof_gate_only_decision",
        "rfc_full":"rfc_full_decision",
    }
    def counts(field):
        unsafe=sum(r[field]=="confirm" and r["ideal_decision"]!="confirm" for r in rows)
        missed=sum(r[field]!="confirm" and r["ideal_decision"]=="confirm" for r in rows)
        return unsafe, missed
    count_map={m:counts(f) for m,f in methods.items()}
    ratios=[0,0.5,1.0,1.5,2.0,5.0,10.0]
    cost_rows=[]
    for ratio in ratios:
        rec={"harmful_to_abstention_cost_ratio":ratio}
        for m,(unsafe,missed) in count_map.items():
            rec[f"{m}_unsafe_promotions"]=unsafe
            rec[f"{m}_missed_ideal_confirms"]=missed
            rec[f"{m}_normalized_loss"]=unsafe*ratio+missed
        cost_rows.append(rec)
    with (out/"COST_SENSITIVITY.csv").open("w",newline="",encoding="utf-8") as f:
        cols=list(cost_rows[0].keys()); w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(cost_rows)

    break_even=None
    vu,vm=count_map["validator_only"]; pu,pm=count_map["proof_gate_only"]
    denom=vu-pu
    if denom>0:
        break_even=(pm-vm)/denom
    cost_json={
        "formal_n_contribution":0,
        "definition":{"C_H":"cost of an unsafe promotion","C_A":"cost of an unnecessary abstention on an ideal-confirm case"},
        "validator_only":{"unsafe_promotions":vu,"missed_ideal_confirms":vm},
        "proof_gate_only":{"unsafe_promotions":pu,"missed_ideal_confirms":pm},
        "break_even_C_H_over_C_A":break_even,
        "is_statistical_estimate":False,
        "depends_on_frozen_casepack_composition":True,
        "external_validity_claimed":False,
        "confidence_interval_applicable":False,
        "interpretation":"local deterministic sensitivity only: proof gate has lower normalized loss when C_H/C_A is strictly above the break-even value for this frozen casepack"
    }
    (out/"COST_SENSITIVITY.json").write_text(json.dumps(cost_json,indent=2,sort_keys=True)+"\n",encoding="utf-8")

    # Certification sensitivity for zero observed failures.
    q_values=[0.20,0.10,0.05]
    cert_rows=[]
    for q in q_values:
        mn=min_n_zero(q)
        cert_rows.append({"q":q,"minimum_n_zero_failures_95pct_one_sided":mn,"cp_upper_at_min_n":cp_upper_zero(mn)})
    with (out/"CERTIFICATION_SENSITIVITY.csv").open("w",newline="",encoding="utf-8") as f:
        cols=list(cert_rows[0].keys()); w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(cert_rows)

    # Pseudo-independence: counterfactually duplicate same seven observations.
    base_n=7
    dup_rows=[]
    for multiple in range(1,6):
        n=base_n*multiple
        upper=cp_upper_zero(n)
        dup_rows.append({
            "duplication_multiple":multiple,
            "nominal_n_if_duplicates_miscounted":n,
            "new_independent_environments_added":0 if multiple>1 else 7,
            "cp_upper_zero_failures_95pct_one_sided":upper,
            "would_nominally_pass_q_0_10": upper <= 0.10
        })
    with (out/"PSEUDO_INDEPENDENCE.csv").open("w",newline="",encoding="utf-8") as f:
        cols=list(dup_rows[0].keys()); w=csv.DictWriter(f,fieldnames=cols); w.writeheader(); w.writerows(dup_rows)

    # Cohort confounding audit.
    cohorts=sorted({r["cohort"] for r in rows})
    cohort_report={}
    for cohort in cohorts:
        rr=[r for r in rows if r["cohort"]==cohort]
        cohort_report[cohort]={
            "n":len(rr),
            "validator_confirmations":sum(r["validator_only_decision"]=="confirm" for r in rr),
            "proof_gate_confirmations":sum(r["proof_gate_only_decision"]=="confirm" for r in rr),
            "validator_proof_agreement":sum(r["validator_only_decision"]==r["proof_gate_only_decision"] for r in rr),
        }
    heuristic_agree=0
    for r in rows:
        heuristic="abstain" if r["cohort"]=="internal_controlled_stress" else r["validator_only_decision"]
        heuristic_agree += heuristic==r["proof_gate_only_decision"]
    confounding={
        "formal_n_contribution":0,
        "cohorts":cohort_report,
        "posthoc_heuristic":"ABSTAIN for internal_controlled_stress; otherwise copy validator_only",
        "heuristic_proof_gate_agreement_count":heuristic_agree,
        "heuristic_proof_gate_agreement_total":len(rows),
        "heuristic_proof_gate_agreement_rate":heuristic_agree/len(rows),
        "interpretation":"The frozen casepack does not isolate family-specific ProofBundle obligations from cohort construction; this audit is descriptive and post hoc."
    }
    (out/"COHORT_CONFOUNDING_AUDIT.json").write_text(json.dumps(confounding,indent=2,sort_keys=True)+"\n",encoding="utf-8")

    summary={
        "status":"PASS",
        "formal_n_contribution":0,
        "raw_data_modified":False,
        "cost_break_even_C_H_over_C_A":break_even,
        "cost_break_even_is_statistical_estimate":False,
        "cost_break_even_depends_on_frozen_casepack_composition":True,
        "cost_break_even_external_validity_claimed":False,
        "cost_break_even_confidence_interval_applicable":False,
        "minimum_n_zero_failures":{"q_0_20":min_n_zero(.20),"q_0_10":min_n_zero(.10),"q_0_05":min_n_zero(.05)},
        "current_cp_upper_n7_zero_failures":cp_upper_zero(7),
        "pseudo_independence_5x_cp_upper":cp_upper_zero(35),
        "cohort_heuristic_agreement_with_proof_gate":heuristic_agree,
        "cohort_heuristic_total":len(rows),
        "unsupported_metric_note":"zero unsupported confirmations for proof-gated methods is by construction and is diagnostic only"
    }
    (out/"REVISION_ANALYSIS_SUMMARY.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(json.dumps(summary,indent=2,sort_keys=True))

if __name__=="__main__":
    main()
