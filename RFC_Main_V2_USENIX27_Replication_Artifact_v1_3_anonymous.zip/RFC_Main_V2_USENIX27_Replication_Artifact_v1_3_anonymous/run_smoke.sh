#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/verify_artifact.py" --artifact-root "$ROOT"
python3 "$ROOT/scripts/smoke_test.py"
python3 "$ROOT/scripts/anonymization_scan.py"
