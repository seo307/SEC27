# Artifact Claims and Paper Mapping — v1.3

## C1 — Frozen evaluation corpus
**Claim:** 24 unique evaluation cases spanning six vulnerability families; 11 external reviewed, 12 controlled stress, and one Phase-2 external candidate.

**Frozen evidence:** `data/final_evaluation/CASEPACK_SUMMARY.json`

**Reproduce:** `python3 scripts/smoke_test.py`

## C2 — Ambiguous-positive measurement result
**Claim:** vulnerability truth and evidentiary justification can diverge. In the five frozen ambiguous-positive cases (`vulnerable=true`, `ideal_decision=abstain`), the blinded GPT-5.4 baseline over-confirms 2/5 and the validator 1/5.

This is the primary empirical failure mode in v1.3.

**Scope:** the 2/5 result is an existence demonstration on a frozen, deliberately constructed five-case set. It is not treated as a population-level or model-wide over-confirmation probability, and v1.3 makes no cross-model generality claim.

**Frozen evidence:** `data/final_evaluation/agent_outputs/openai-gpt-5.4.jsonl`, separate `casepack_oracle.jsonl`, and `ablation_rows.jsonl`.

**Reproduce:** `./run_reproduce.sh`

## C3 — Structural admission behavior, with causal scope limit
**Claim:** relative to validator-only, proof-gate-only changes two unsafe promotions (including the single false confirmation) to abstentions, while also abstaining on three cases whose oracle ideal decision is CONFIRM.

**Scope:** these decision differences are concentrated in the controlled-stress cohort. The frozen casepack does **not** isolate family-specific ProofBundle obligations as the unique causal source of the aggregate difference.

**Frozen evidence:** `data/final_evaluation/ablation_rows.jsonl`

**Derived confounding audit:** `derived_revision/COHORT_CONFOUNDING_AUDIT.json`

## C4 — Unsupported-confirmation diagnostic is by construction
The frozen evaluation retains the `unsupported_confirmations` field for provenance. A proof-gated method has zero unsupported confirmations by definition of the gate. v1.3 reports this only as a diagnostic of what was filtered, not as an independent effectiveness endpoint.

## C5 — Cost sensitivity is casepack-composition-dependent
Relative to validator-only, proof-gate-only removes 2 unsafe promotions and adds 3 unnecessary abstentions on ideal-confirm cases. Under the stated normalized loss `L = C_H * unsafe + C_A * missed_ideal`, this frozen casepack gives a break-even ratio `C_H/C_A = 1.5`.

**Important:** 1.5 is a deterministic sensitivity value induced by the frozen casepack composition. It is **not** a statistical estimate of organizational costs, has no claimed external validity, and no confidence interval is asserted.

**Derived evidence:** `derived_revision/COST_SENSITIVITY.*`

## C6 — Confidence threshold equivalence
**Claim:** confidence-threshold and validator-only decisions are identical on 24/24 cases.

**Reproduce:** `./run_reproduce.sh`

## C7 — Formal certificate unavailable
**Claim:** 0 observed false confirmations among 7 independent certification confirmations yields a one-sided 95% exact upper bound of 0.3481636551311609, above q=.10; certificate = NOT READY.

**Frozen evidence:** `data/final_evaluation/formal_progress.json`

## C8 — Risk sensitivity and pseudo-independence
**Claim:** zero-failure 95% minimum independent N is 14 at q=.20, 29 at q=.10, and 59 at q=.05. Counterfactually counting five copies of the same seven zero-failure confirmations as independent would produce a nominal upper bound of about 0.082, illustrating pseudo-assurance.

**Derived evidence:** `derived_revision/CERTIFICATION_SENSITIVITY.csv`, `PSEUDO_INDEPENDENCE.csv`

## C9 — Controlled-cohort confounding
**Claim:** all 12 controlled-stress cases are rejected by proof-gate-only, while external reviewed decisions match validator-only. A post-hoc rule `ABSTAIN on internal_controlled_stress; otherwise copy validator-only` matches proof-gate-only on 24/24 frozen cases.

v1.3 therefore does **not** claim that the current casepack causally isolates family-specific proof obligations.

**Derived evidence:** `derived_revision/COHORT_CONFOUNDING_AUDIT.json`

## C10 — Independence and artifact integrity
Repeated internal runs and controlled stress cases contribute formal N=0; accepted external environments are deduplicated by environment fingerprint. Method rules and registry were frozen before the agent run; outputs are manifest-bound.

**Evidence:** frozen method rules, scientific registry snapshot, pre-agent manifest, and final manifest under `data/final_evaluation/`.
