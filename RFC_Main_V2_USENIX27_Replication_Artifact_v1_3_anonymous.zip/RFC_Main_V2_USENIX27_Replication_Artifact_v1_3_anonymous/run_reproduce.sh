#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/scripts/reproduce_paper_results.py" --artifact-root "$ROOT"
python3 "$ROOT/scripts/revision_sensitivity.py" --artifact-root "$ROOT"
