"""Corrections spec P0-D §6.2/§6.5: the 10-point confirmation gate."""
from __future__ import annotations

import pytest

from orchestrator.finding_service import (
    ConfirmationStatus,
    FindingConfirmationService,
    new_finding,
)
from orchestrator.proof_bundle import ProofBundle
from orchestrator.schemas import ExecutionStatus


def _full_bundle(finding_id, target_id="t1", **overrides):
    """A bundle that satisfies every gate check for sql_injection."""
    data = dict(
        finding_id=finding_id,
        target_id=target_id,
        session_id="s1",
        claim="SQLi on /search",
        vulnerability_type="sql_injection",
        preconditions=["injectable_parameter"],
        direct_evidence_refs=["ev-direct-1"],
        derived_evidence_refs=[],
        validator_result_refs=["vr-1"],
        raw_artifact_refs=["art-1"],
        contradictions=[],
        proof_obligations=[
            "control_request_compared",
            "differential_response_or_error",
            "target_endpoint_match",
            "reproduction_request",
        ],
        target_continuity_verified=True,
        session_continuity_verified=True,
        artifact_integrity_verified=True,
    )
    data.update(overrides)
    return ProofBundle(**data)


def _service(
    *,
    evidence_status=ExecutionStatus.SUCCEEDED,
    validator_status="confirmed",
    artifacts_ok=True,
):
    return FindingConfirmationService(
        evidence_status_of=lambda _id: evidence_status,
        validator_status_of=lambda _ref: validator_status,
        verify_artifacts=lambda _refs: artifacts_ok,
    )


def test_all_conditions_met_confirms():
    svc = _service()
    f = new_finding(target_id="t1", title="SQLi", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, _full_bundle(f.finding_id))
    assert result.allowed
    assert result.resulting_status == ConfirmationStatus.CONFIRMED
    assert svc.get(f.finding_id).status == ConfirmationStatus.CONFIRMED


def test_no_proof_bundle_cannot_confirm():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, None)
    assert not result.allowed
    assert result.resulting_status == ConfirmationStatus.UNSUPPORTED
    assert "no_proof_bundle" in result.failures


def test_no_direct_evidence_cannot_confirm():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, _full_bundle(f.finding_id, direct_evidence_refs=[]))
    assert not result.allowed
    assert "no_direct_evidence" in result.failures
    assert result.resulting_status == ConfirmationStatus.MANUAL_REVIEW


def test_evidence_not_succeeded_cannot_confirm():
    svc = _service(evidence_status=ExecutionStatus.BLOCKED)
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, _full_bundle(f.finding_id))
    assert not result.allowed
    assert any(x.startswith("evidence_not_succeeded") for x in result.failures)


def test_validator_fail_cannot_confirm():
    svc = _service(validator_status="false_positive")
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, _full_bundle(f.finding_id))
    assert not result.allowed
    assert "validator_did_not_pass" in result.failures


def test_artifact_hash_mismatch_cannot_confirm():
    svc = _service(artifacts_ok=False)
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, _full_bundle(f.finding_id))
    assert not result.allowed
    assert "artifact_integrity_failed" in result.failures


def test_target_mismatch_is_unsupported():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(f.finding_id, _full_bundle(f.finding_id, target_id="OTHER"))
    assert not result.allowed
    assert result.resulting_status == ConfirmationStatus.UNSUPPORTED
    assert "target_mismatch" in result.failures


def test_missing_obligations_cannot_confirm():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(
        f.finding_id, _full_bundle(f.finding_id, proof_obligations=["control_request_compared"])
    )
    assert not result.allowed
    assert any(x.startswith("missing_obligations") for x in result.failures)


def test_contradiction_is_unsupported():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    result = svc.confirm(
        f.finding_id, _full_bundle(f.finding_id, contradictions=["conflicting evidence ev-9"])
    )
    assert not result.allowed
    assert result.resulting_status == ConfirmationStatus.UNSUPPORTED
    assert "unresolved_contradiction" in result.failures


def test_session_continuity_required_but_unverified():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="privilege_escalation")
    svc.register(f)
    bundle = _full_bundle(
        f.finding_id,
        vulnerability_type="privilege_escalation",
        proof_obligations=[
            "valid_foothold", "escalation_action_executed",
            "effective_identity_changed", "session_continuity",
        ],
        session_continuity_verified=False,
    )
    result = svc.confirm(f.finding_id, bundle, require_session_continuity=True)
    assert not result.allowed
    assert "session_continuity_unverified" in result.failures


def test_target_continuity_required_but_unverified():
    svc = _service()
    f = new_finding(target_id="t1", title="x", vulnerability_type="sql_injection")
    svc.register(f)
    bundle = _full_bundle(f.finding_id, target_continuity_verified=False)
    result = svc.confirm(f.finding_id, bundle, require_target_continuity=True)
    assert not result.allowed
    assert "target_continuity_unverified" in result.failures
