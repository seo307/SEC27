"""Corrections spec P0-D §6.1: ProofBundle schema."""
from __future__ import annotations

from orchestrator.proof_bundle import ProofBundle


def test_minimal_bundle_defaults():
    b = ProofBundle(
        finding_id="F1", target_id="t1",
        claim="c", vulnerability_type="idor",
    )
    assert b.direct_evidence_refs == []
    assert b.contradictions == []
    assert b.target_continuity_verified is False
    assert b.created_at  # auto timestamp


def test_bundle_roundtrip():
    b = ProofBundle(
        finding_id="F1", target_id="t1", claim="c", vulnerability_type="ssrf",
        direct_evidence_refs=["e1"], raw_artifact_refs=["a1"],
        proof_obligations=["server_side_outbound_interaction"],
    )
    d = b.model_dump()
    b2 = ProofBundle(**d)
    assert b2.direct_evidence_refs == ["e1"]
    assert b2.vulnerability_type == "ssrf"
