#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, shutil, subprocess, sys
from pathlib import Path
from common import HERE, ROOT, load_json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--require-live-deps',action='store_true'); a=ap.parse_args()
    errors=[]; warnings=[]
    for rel in ['benchmarks/run_benchmark.py','orchestrator/finding_service.py','orchestrator/proof_bundle.py']:
        if not (ROOT/rel).exists(): errors.append(f'missing:{rel}')
    m=load_json(HERE/'config/study_manifest.json')
    seen_groups=set()
    for c in m['cases']:
        if not (ROOT/'benchmarks'/c['case_id']).is_dir(): errors.append('missing_case:'+c['case_id'])
        for key in ['group_id','source_class','independence_eligible']:
            if key not in c: errors.append(f'manifest_missing:{c.get("case_id")}:{key}')
        if c.get('independence_eligible') and c.get('group_id') in seen_groups: errors.append('duplicate_independent_group:'+str(c.get('group_id')))
        if c.get('independence_eligible'): seen_groups.add(c.get('group_id'))
    if a.require_live_deps:
        if shutil.which('docker') is None: errors.append('docker_not_found')
        else:
            p=subprocess.run(['docker','compose','version'],capture_output=True,text=True)
            if p.returncode: errors.append('docker_compose_unavailable')
        for mod in ['flask','requests','yaml','pydantic','selenium','scipy']:
            if importlib.util.find_spec(mod) is None: errors.append('python_dependency_missing:'+mod)
    try:
        from calibration_sanity import run as _cal_sanity
        if _cal_sanity().get('status')!='PASS': errors.append('calibration_sanity_failed')
    except Exception as e:
        errors.append('calibration_sanity_error:'+str(e))
    status='PASS' if not errors else 'FAIL'
    print(json.dumps({'status':status,'cases':len(m['cases']),'errors':errors,'warnings':warnings},indent=2))
    raise SystemExit(0 if status=='PASS' else 2)
if __name__=='__main__': main()
