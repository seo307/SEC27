from __future__ import annotations
from collections import defaultdict
from orchestrator.tool_families import family_of


def normalize_evidence(e: dict, *, deployment_id: str = 'deployment:T1') -> dict:
    out = dict(e)
    out.setdefault('captured_at', out.get('timestamp') or out.get('created_at'))
    out.setdefault('deployment_id', deployment_id)
    out.setdefault('source_family', family_of(out.get('source_tool', 'unknown')))
    out.setdefault('provenance_root', out.get('id'))
    out.setdefault('derived_from', [])
    out.setdefault('support_direction', 'support')
    return out


def provenance_features(evidences: list[dict]) -> dict:
    roots = {}
    families = set()
    tool_names = set()
    dependency_edges = 0
    support_roots = set()
    contradict_roots = set()
    for e in evidences:
        tool_names.add(e.get('source_tool', 'unknown'))
        root = e.get('provenance_root') or e.get('id')
        roots[root] = roots.get(root, 0) + 1
        families.add(e.get('source_family') or family_of(e.get('source_tool', 'unknown')))
        dependency_edges += len(e.get('derived_from') or [])
        if e.get('support_direction') == 'contradict':
            contradict_roots.add(root)
        else:
            support_roots.add(root)
    independent_roots = len(roots)
    # Conservative support: duplicated/derived observations sharing a root count once.
    independent_support = float(len(support_roots))
    return {
        'nominal_tool_count': len(tool_names),
        'distinct_family_count': len(families),
        'independent_root_count': independent_roots,
        'independent_support_score': independent_support,
        'dependency_edge_count': dependency_edges,
        'contradictory_root_count': len(contradict_roots),
        'duplicate_observation_count': max(0, len(evidences) - independent_roots),
    }


def duplicate_correlated_evidence(evidences: list[dict], *, copies_per_source: int = 2) -> list[dict]:
    out = [dict(e) for e in evidences]
    for e in evidences:
        root = e.get('provenance_root') or e.get('id')
        family = e.get('source_family') or family_of(e.get('source_tool', 'unknown'))
        for i in range(copies_per_source):
            c = dict(e)
            c['id'] = f"{e.get('id')}.corr{i+1}"
            c['source_tool'] = f"{e.get('source_tool','unknown')}_correlated_{i+1}"
            c['source_family'] = family
            c['provenance_root'] = root
            c['derived_from'] = [e.get('id')]
            c['tags'] = list(e.get('tags') or []) + ['controlled_correlated_copy']
            out.append(c)
    return out


def add_soft_conflict(evidences: list[dict]) -> list[dict]:
    out = [dict(e) for e in evidences]
    if not evidences:
        return out
    src = evidences[0]
    c = {
        'id': f"{src.get('id')}.soft_conflict",
        'target_id': src.get('target_id'),
        'target': src.get('target'),
        'type': 'observational_evidence',
        'value': {'controlled_observation': 'conflicting telemetry'},
        'source_tool': 'secondary_observer',
        'source_family': 'secondary_observer',
        'confidence': 0.55,
        'captured_at': src.get('captured_at') or src.get('timestamp'),
        'timestamp': src.get('timestamp'),
        'deployment_id': src.get('deployment_id'),
        'provenance_root': f"{src.get('id')}.soft_conflict.root",
        'derived_from': [],
        'support_direction': 'contradict',
        'tags': ['controlled_soft_conflict'],
    }
    out.append(c)
    return out
