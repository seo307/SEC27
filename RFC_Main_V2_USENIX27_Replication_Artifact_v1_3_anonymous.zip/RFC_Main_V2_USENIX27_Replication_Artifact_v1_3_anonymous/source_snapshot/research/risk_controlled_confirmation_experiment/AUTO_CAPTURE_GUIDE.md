# Main-V2 Automated Local Capture Layer

This layer consumes the output of `run_external_bootstrap.sh --execute` and attempts to turn assigned public scenarios into blinded RFC captures **without manually filling the 120-row CSV**.

## What is automated

1. Documentation-only pre-execution feasibility screen.
2. Extraction of conservative `curl` HTTP reproduction snippets from public README files.
3. Local Docker Compose startup/teardown, one scenario at a time.
4. Rewriting documented HTTP requests to Docker-published `127.0.0.1` ports.
5. Direct HTTP evidence capture and category-specific conservative validator decisions.
6. Separate blinded capture and oracle JSONL export.
7. External bundle validation.

## What is deliberately not automated

- Arbitrary Python/Java/Metasploit/exploit scripts in public repositories are never executed.
- Requests to Internet targets are rejected; HTTP replay is loopback-only.
- Missing negative controls are not fabricated.
- A README that does not document sufficient evidence for a `positive_confirmable` slot is excluded **before execution** rather than relabeled after seeing results.
- XSS is collected as partial HTTP evidence only until a separate local browser-execution adapter is introduced.

## Run

After bootstrap:

```bash
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh --limit 5
```

Use the five-job smoke run first. If it is clean, run all pre-screened jobs:

```bash
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh
```

Outputs are under `research/risk_controlled_confirmation_experiment/external/`:

- `screened_capture_jobs.jsonl`
- `screen_summary.json`
- `acquired_raw/`
- `captures_blinded.jsonl`
- `oracle.jsonl`
- `acquisition_ledger.json`

Then import/build/analyze using the Main-V2 formal workflow.
