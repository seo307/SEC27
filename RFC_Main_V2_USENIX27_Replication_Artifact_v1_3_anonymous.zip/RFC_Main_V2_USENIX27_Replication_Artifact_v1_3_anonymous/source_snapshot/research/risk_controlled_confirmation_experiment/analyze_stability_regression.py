#!/usr/bin/env python3
"""Analyze repeated smoke/regression runs without adding to formal sample size.

The output is descriptive stability evidence only.  Repetitions of the same
external group are explicitly assigned formal_n_contribution=0.
"""
from __future__ import annotations
import argparse,json
from collections import Counter,defaultdict
from pathlib import Path


def _validator_status(rec:dict):
    rows=((rec.get('result') or {}).get('rfc_capture') or {}).get('validation_records') or []
    if not rows:return None
    return ((rows[0].get('validator_result') or {}).get('status'))


def _signature(rec:dict):
    obs=rec.get('observations') or []
    return {
        'status':rec.get('status'),
        'capture_validity':rec.get('capture_validity'),
        'validator_status':_validator_status(rec),
        'db_backend_evidence':any(bool(x.get('db_backend_error')) for x in obs),
        'callback_received':any(bool(x.get('nonce_present')) for x in (rec.get('callback_receipts') or [])),
        'fixture_ready':(rec.get('fixture_readiness') or {}).get('ready') if (rec.get('fixture_readiness') or {}).get('required') else None,
    }


def analyze(series_dir:Path):
    reps=sorted(p for p in series_dir.glob('rep-*') if p.is_dir())
    groups=defaultdict(list);rep_rows=[]
    for rep in reps:
        raw=rep/'acquired_raw';summary=raw/'acquisition_summary.json'
        rep_id=rep.name
        if not summary.exists():
            rep_rows.append({'rep':rep_id,'summary_present':False});continue
        sm=json.loads(summary.read_text());rep_rows.append({'rep':rep_id,'summary_present':True,'status':sm.get('status'),'scheduled':sm.get('scheduled'),'valid_captures':sm.get('valid_captures'),'invalid_captures':sm.get('invalid_captures'),'run_errors':sm.get('run_errors')})
        for f in raw.glob('RFCEXT-*.json'):
            rec=json.loads(f.read_text());groups[rec.get('group_id') or f.stem].append({'rep':rep_id,'signature':_signature(rec)})
    gout={};unstable=[]
    for gid,rows in sorted(groups.items()):
        serial=[json.dumps(x['signature'],sort_keys=True) for x in rows];counts=Counter(serial);stable=(len(rows)==len(reps) and len(counts)==1)
        if not stable:unstable.append(gid)
        gout[gid]={
            'observed_repetitions':len(rows),
            'planned_repetitions':len(reps),
            'stable':stable,
            'signature_counts':[{ 'signature':json.loads(k), 'count':v } for k,v in sorted(counts.items())],
        }
    complete=bool(reps) and all(x.get('summary_present') for x in rep_rows)
    status='STABLE' if complete and gout and not unstable else ('UNSTABLE' if complete and gout else 'INCOMPLETE')
    return {
        'status':status,
        'regression_only':True,
        'formal_n_contribution':0,
        'formal_independence_note':'Repeated executions of the same group are stability evidence only and MUST NOT be counted as independent formal samples.',
        'repetitions':len(reps),
        'repetition_summaries':rep_rows,
        'groups':gout,
        'stable_groups':sum(1 for x in gout.values() if x['stable']),
        'unstable_groups':unstable,
    }


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--series-dir',required=True);ap.add_argument('--output')
    a=ap.parse_args();series=Path(a.series_dir);obj=analyze(series)
    out=Path(a.output) if a.output else series/'stability_summary.json';out.write_text(json.dumps(obj,indent=2,sort_keys=True))
    print(json.dumps({k:v for k,v in obj.items() if k!='groups' and k!='repetition_summaries'},indent=2,sort_keys=True))
    if obj['status']=='INCOMPLETE':raise SystemExit(2)
    if obj['status']=='UNSTABLE':raise SystemExit(3)

if __name__=='__main__':main()
