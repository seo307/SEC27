# RFC/Main-V2 V5.2 — Integrated Corpus Expansion & Certification Controller

V5.2 replaces the repeated small-batch workflow with one integrated controller.
It does **not** alter the structural-vs-risk gate separation, the independent
oracle, the FCR definition, the preregistered split, or the environment-level
independence rule.

## What V5.2 does

1. Screens the complete preregistered external corpus.
2. Excludes fingerprints already in the explicit scientific registry.
3. Excludes previously established execution blockers unless `--retry-blockers`
   is explicitly requested.
4. Prioritizes `certify / positive_confirmable` environments.
5. Runs all currently safe/ready primary environments in one batch.
6. Produces a scientific review queue and registry-candidate file.
7. Produces a cumulative formal-progress report, including the one-sided
   Clopper-Pearson upper bound.
8. Never adds a registry entry automatically.

## Current checkpoint expected before V5.2

The reviewed checkpoint immediately before this release is:

- scientifically accepted unique environments: **10**
- certify environments: **7**
- certification confirmations: **6**
- observed false confirmations: **0**
- formal certificate: **NOT READY**

The default runner therefore fails closed when the registry contains fewer than
10 accepted fingerprints. Override only with an explicit `--min-registry N`
when reconstructing an older checkpoint.

## Install

```bash
python /tmp/main_v2_capture_patch_v5_2/apply_patch.py \
  --repo ~/main_test_V2 \
  --check

python /tmp/main_v2_capture_patch_v5_2/apply_patch.py \
  --repo ~/main_test_V2
```

## Verify

```bash
cd ~/main_test_V2
python -m pytest -q research/risk_controlled_confirmation_experiment/tests
```

Audited release expectation: `104 passed`.

## Optional plan-only preview

```bash
research/risk_controlled_confirmation_experiment/run_external_certification_expansion.sh \
  --plan-only
```

At the reviewed 10-environment checkpoint, the audited plan selects
`RFCEXT-ssrf-009` as the only new ready primary certify-positive environment.
Known prior blockers are not rerun by default.

## One-shot corpus expansion

```bash
research/risk_controlled_confirmation_experiment/run_external_certification_expansion.sh
```

The runner creates one immutable V5.2 run directory containing at least:

- `controller_plan.json`
- `corpus_inventory.jsonl`
- `corpus_blockers.jsonl`
- `ready_groups.txt`
- normal capture-pipeline artifacts
- `scientific_review_queue.jsonl`
- `registry_review_candidates.jsonl`
- `scientific_review_summary.json`
- `formal_progress.json`
- `V52_RUN_SUMMARY.md`
- `controller_manifest.json`

`registry_review_candidates.jsonl` is only a review aid. It is **not** scientific
acceptance and is never applied automatically.

## Blocker policy

The packaged V5.2 blocker seed is execution-only metadata. It currently keeps
three already-reviewed non-yield environments from being rerun automatically:

- `RFCEXT-sqli-010` — authentication fixture/precondition failure
- `RFCEXT-sqli-013` — installer/application fixture precondition
- `RFCEXT-auth_bypass-011` — nondifferential same-500 application/auth init state

Use `--retry-blockers` only when the underlying fixture/state has materially
changed. Repetition never creates additional formal N.

## V5.2 SSRF body adapter

V5.2 adds one generic conservative SSRF transformation for source-documented
arbitrary-URL server fetches where a raw HTTP body contains an explicit
URL-bearing `href` attribute. The source URL is retained by hash/provenance only
and is replaced before replay with the local nonce-correlated callback URL.
Stale source `Content-Length` is removed so the HTTP library can recompute it.

This unlocks the predeclared Apache CXF `RFCEXT-ssrf-009` benchmark without
replaying the source `file:///etc/hosts` value.

## Scientific boundary

The controller may recommend `REVIEW_FOR_ACCEPTANCE`, but the final registry
admission remains an explicit scientific-review step. This preserves the study's
separation between automated acquisition/validation and formal sample admission.
