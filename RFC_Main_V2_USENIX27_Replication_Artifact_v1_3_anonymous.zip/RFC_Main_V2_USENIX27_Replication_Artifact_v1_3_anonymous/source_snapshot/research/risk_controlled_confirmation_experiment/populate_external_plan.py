#!/usr/bin/env python3
"""Bind preregistered slots to unique public environments.

V4 uses category-independent environment_fingerprint as the formal allocation
unit. Even when one environment exposes multiple mechanisms, it may occupy at
most one independence-eligible formal group.
"""
from __future__ import annotations
import argparse,csv,json
from collections import Counter,defaultdict
from pathlib import Path

def read_csv(p):
    with open(p,newline='') as f:return list(csv.DictReader(f))
def write_csv(p,rows):
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields:fields.append(k)
    with open(p,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',required=True);ap.add_argument('--catalog',required=True);ap.add_argument('--output-plan',required=True);ap.add_argument('--recipes',required=True)
    a=ap.parse_args();plan=read_csv(a.plan);cat=read_csv(a.catalog)
    pools=defaultdict(list)
    for c in cat:
        if c.get('formal_independence_recommended')=='true' and c.get('confidence')=='high' and c.get('primary_category','true')=='true':
            pools[c['category']].append(c)
    for k in pools:pools[k].sort(key=lambda c:(-int(c.get('classification_score') or 0),c['source_name'],c['relative_path']))
    used_env=set();recipes=[];short=Counter();assigned=Counter()
    for r in plan:
        kind=r['scenario_kind']; candidates=[]
        for c in pools[r['category']]:
            env=c.get('environment_fingerprint') or c['scenario_fingerprint']
            if env in used_env:continue
            if kind=='negative_lookalike' and c.get('supports_negative_control')!='true':continue
            if kind!='negative_lookalike' and c.get('supports_vulnerable_modes')!='true':continue
            candidates.append(c)
        if not candidates:
            r['status']='SHORTFALL_NEEDS_INDEPENDENT_SOURCE';short[(r['category'],kind)]+=1;continue
        c=candidates[0];env=c.get('environment_fingerprint') or c['scenario_fingerprint'];used_env.add(env);assigned[(r['category'],kind)]+=1
        r.update({
          'source_class':'public_cve_container' if c['source_name']=='vulhub' else 'public_benchmark',
          'oracle_source':f"{c['source_url']}::{c['readme_path']}",'oracle_independent_of_validator':'true',
          'independence_basis':f"Unique public environment {c['source_name']}:{c['relative_path']}; environment fingerprint cannot be reused by another formal group.",
          'software_product':c['software_product'],'software_version':c['advisory_or_state'],
          'target_state_id':f"{c['source_name']}:{c['relative_path']}:{c['advisory_or_state']}",
          'environment_fingerprint':env,'finding_fingerprint':c.get('finding_fingerprint') or c['scenario_fingerprint'],'scenario_fingerprint':c['scenario_fingerprint'],
          'capture_path':f"external/acquired/{r['group_id']}/capture.json",'oracle_path':f"external/acquired/{r['group_id']}/oracle.json",'status':'ASSIGNED_PENDING_CAPTURE'
        })
        mode='full_evidence' if kind=='positive_confirmable' else ('partial_evidence' if kind=='ambiguous_positive' else 'negative_control')
        recipes.append({'group_id':r['group_id'],'category':r['category'],'split_role':r['split_role'],'scenario_kind':kind,'candidate_id':c['candidate_id'],'source_name':c['source_name'],'source_url':c['source_url'],'source_relative_path':c['relative_path'],'compose_path':c['compose_path'],'readme_path':c['readme_path'],'evidence_mode':mode,'planned_vulnerable':r['planned_vulnerable'],'planned_ideal_decision':r['planned_ideal_decision'],'environment_fingerprint':env,'finding_fingerprint':c.get('finding_fingerprint') or c['scenario_fingerprint'],'scenario_fingerprint':c['scenario_fingerprint'],'classification_basis':c.get('classification_basis'),'classification_score':c.get('classification_score')})
    Path(a.output_plan).parent.mkdir(parents=True,exist_ok=True);write_csv(a.output_plan,plan)
    rp=Path(a.recipes);rp.parent.mkdir(parents=True,exist_ok=True);rp.write_text('\n'.join(json.dumps(x,sort_keys=True) for x in recipes)+('\n' if recipes else ''))
    print(json.dumps({'status':'PASS','assigned':len(recipes),'shortfall':len(plan)-len(recipes),'unique_environments_assigned':len(used_env),'assigned_by_category_kind':{f'{k[0]}:{k[1]}':v for k,v in assigned.items()},'shortfall_by_category_kind':{f'{k[0]}:{k[1]}':v for k,v in short.items()},'output_plan':a.output_plan,'recipes':a.recipes},indent=2))
if __name__=='__main__':main()
