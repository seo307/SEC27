# RFC Main-V2 Capture V5.1.2 — Fixture Readiness & Stability Regression

V5.1.2 is a small correction on top of audited V5.1.1. It does **not** change the formal FCR methodology, oracle separation, group independence rules, or the 9000–9998 / callback-9999 port policy.

## What V5.1.2 changes

### 1. Fixture-specific readiness
Generic HTTP readiness is no longer sufficient for WFS/GeoServer recipes that reference a concrete `typeName`.

Before executing the documented GetFeature/SQLi request, the runner derives a benign WFS `DescribeFeatureType` request for the same `typeName` and waits until the feature schema actually exists.

Example:

```text
GetFeature&typeName=vulhub:example&CQL_FILTER=...
                 ↓
DescribeFeatureType&typeName=vulhub:example
                 ↓
requested XML schema exists
                 ↓
only then execute the documented experimental requests
```

If the feature type is temporarily absent during startup, the runner waits. If it never becomes available before the readiness timeout, the record is classified as `APPLICATION_PRECONDITION_FAILED` (when an explicit missing-fixture response was observed) or `APPLICATION_NOT_FULLY_READY` otherwise. Such records do not contribute to formal N.

### 2. Separate readiness provenance
Each relevant raw record now contains `fixture_readiness` separately from generic `readiness`, including:
- probe type,
- requested WFS feature type,
- attempt count,
- explicit missing-fixture observations,
- final readiness state,
- response hashes.

### 3. Stability regression runner
Use the new regression-only runner to repeat the **same smoke groups** 2–3 times without inflating the formal sample size:

```bash
research/risk_controlled_confirmation_experiment/run_external_stability_regression.sh \
  --repetitions 3 \
  --limit 5
```

Outputs are written under:

```text
research/risk_controlled_confirmation_experiment/external/stability/<SERIES_ID>/
```

The stability path intentionally:
- does **not** call `export_external_bundle.py`,
- does **not** generate a formal oracle bundle,
- sets `formal_n_contribution = 0`,
- compares per-group status, capture validity, validator status, DB-backend evidence, callback evidence, and fixture readiness across repetitions.

`stability_summary.json` reports `STABLE`, `UNSTABLE`, or `INCOMPLETE`.

## Recommended next execution

First run one normal 5-case regression after applying V5.1.2:

```bash
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh --limit 5
```

Then run three stability repetitions:

```bash
research/risk_controlled_confirmation_experiment/run_external_stability_regression.sh \
  --repetitions 3 --limit 5
```

For the GeoServer SQLi case, the expected stable behavior is either:
- fixture becomes ready, backend PostgreSQL evidence is observed, and confirmation is reproduced; or
- fixture never becomes ready and the run is consistently excluded as an application precondition failure.

A mixture of those states across repetitions should be reported as `UNSTABLE` and investigated before scaling to all automatable scenarios.

## Formal-sample warning

Repeated runs of the same `group_id` are stability evidence only. They MUST NOT be counted as independent formal samples, regardless of how many repetitions succeed.
