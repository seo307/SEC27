#!/usr/bin/env python3
"""Execute screened evidence-only HTTP recipes against loopback Docker targets.

V5.2 integrated corpus-expansion support adds a generic source-grounded SSRF body-URL callback transformation used only when documentation explicitly states arbitrary server-side URL fetching. The original body URL is provenance only and is not replayed.

V5.1.5 certify-batch expansion adds source-grounded, read-only auth-bypass control/candidate evidence for selected public benchmarks and raw path preservation for the documented DataEase traversal request.

V5.1.4.1 runtime/evidence corrections (on top of V5.1.4):
- persistent redirects to installer/setup endpoints are application precondition failures and stop before vulnerability replay;
- HTTP(S) application ports are preferred over known debugger/JDWP ports when a documented URL omits a logical port;
- MySQL error-based SQLi evidence includes directly observed XPATH syntax errors from updatexml()/extractvalue() execution.

V5.1.3 family-adapter corrections (on top of V5.1.2):
- SSRF callback substitution covers URL query, form-urlencoded body, and JSON body fields with body-hash provenance;
- V5.1.4 can align the effective Host header to the controlled callback authority only when source documentation explicitly requires URL-host/Host-header equality;
- V5.1.4 records narrow SQLi benign-control transformation provenance supplied by the screening stage;
- transformed SSTI probes use benign deterministic arithmetic evaluation and preserve source/transformed hashes;
- SSTI confirmation requires control/candidate semantic evidence instead of command output;
- targeted group execution is supported for family-adapter regression.

V5.1.2 fixture-readiness changes (on top of V5.1.1):
- WFS/GeoServer recipes wait for the documented feature type to exist via a benign DescribeFeatureType probe;
- generic HTTP readiness and benchmark-fixture readiness are recorded separately;
- fixture startup races are classified without turning them into model abstentions.

V5.1.1 correction changes (on top of V5.1):
- target host ports are restricted to 127.0.0.1:9000..9998; port 9999 is reserved for the local SSRF callback;
- TLS is inferred from documented/container ports such as 443/8443/9443;
- application warm-up pages do not satisfy readiness;
- auth/login precondition failures are infrastructure-invalid, not abstentions;
- replay-fidelity hashes and allowed transformations are recorded;
- SQLi confirmation requires backend-database evidence, not generic parser errors;
- SSRF can be rewritten to a nonce-correlated callback on the Docker bridge gateway;
- network/registry failures receive explicit infrastructure classifications;
- every raw record is bound to a run_id for manifest-bound export;
- explicit missing benchmark fixtures become APPLICATION_PRECONDITION_FAILED;
- DB-backend error features are only populated for SQLi captures.
"""
from __future__ import annotations
import argparse,copy,hashlib,http.client,json,platform,posixpath,re,socket,subprocess,threading,time,urllib.parse
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import requests,yaml

try:
    from screen_capture_jobs import proof_only_safe,replay_fidelity_precheck,spec_sha256
except Exception:
    proof_only_safe=lambda spec:(True,'screen module unavailable')
    replay_fidelity_precheck=lambda spec:(True,'screen module unavailable')
    def spec_sha256(spec):
        return hashlib.sha256(json.dumps(spec,sort_keys=True,default=str).encode()).hexdigest()

LOGIN=re.compile(r'(login|sign in|authenticate|password)',re.I)
ADMIN=re.compile(r'(admin|dashboard|management|administrator|apisix)',re.I)
AUTH_DENIED=re.compile(r'(unauthori[sz]ed|notauthorized|authentication credentials are required|token is empty|missing (?:authorization|token)|invalid (?:token|credentials))',re.I)
INTERNAL=re.compile(r'(instance-id|ami-id|169\.254\.169\.254|metadata|localhost|127\.0\.0\.1|root:x:0:0)',re.I)
DB_BACKEND=re.compile(
    r'(?:psycopg|postgresql|mysql|mariadb|sqlite3?(?:\.|\b)|oracle|ora-\d+|jdbc|sqlstate|'
    r'databaseerror|operationalerror|programmingerror.{0,240}(?:sql|query|database)|'
    r'xpath\s+syntax\s+error|'
    r'(?:sql|query).{0,160}(?:syntax error|unterminated|column .* does not exist|no such column))',re.I|re.S)
APP_PARSER=re.compile(r'(could not parse|lexical error|parse error|unexpected token|invalid (?:cql|filter|expression)|encountered:\s*<eof>)',re.I)
WARMUP=re.compile(r'(deploying application|application is deployed on the first access|please wait.{0,80}(?:start|deploy)|initiali[sz]ing|starting application)',re.I|re.S)
TLS_REQUIRED=re.compile(r'(requires tls|requires ssl|plain http request was sent to https port|client sent an http request to an https server)',re.I)
APP_FIXTURE_MISSING=re.compile(r'(?:feature\s+type\s+[^<\n]{0,160}?\s+(?:unknown|not\s+found)|no\s+such\s+(?:workspace|feature\s*type)|(?:unknown|missing)\s+workspace|workspace\s+[^<\n]{0,160}?\s+(?:unknown|not\s+found))',re.I)
SSRF_KEY=re.compile(r'(?:url|uri|target|host|callback|fetch|proxy|operator|endpoint|dest(?:ination)?|location)',re.I)
SSRF_BODY_URL_ATTR=re.compile(r"(?P<prefix>\bhref\s*=\s*[\"'])(?P<url>(?:file|https?)://[^\"']+)(?P<suffix>[\"'])",re.I)
NETWORK_ERR=re.compile(r'(temporary failure in name resolution|name or service not known|no such host|network is unreachable|i/o timeout|tls handshake timeout|proxyconnect tcp|connection timed out)',re.I)
REGISTRY_ERR=re.compile(r'(pull access denied|failed to pull|failed to resolve source metadata|registry-1\.docker\.io|auth\.docker\.io|manifest unknown)',re.I)
TLS_CONTAINER_PORTS={443,8443,9443,10443}
HTTP_CONTAINER_PORT_PREFERENCE=(80,8080,8000,8888,8081,3000,5000,8008,8088)
KNOWN_DEBUG_CONTAINER_PORTS={5005}
INSTALLER_REDIRECT=re.compile(r'(?i)(?:^|/)(?:install(?:ation)?|installer|setup)(?:\.php)?(?:/|$|[?#])')
WFS_SCHEMA=re.compile(r'<(?:[A-Za-z_][\w.-]*:)?schema\b',re.I)
WFS_SERVICE_EXCEPTION=re.compile(r'<(?:[A-Za-z_][\w.-]*:)?ServiceException(?:Report)?\b',re.I)


def now():return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def run(cmd,cwd,timeout=180):return subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
def _inside(p:Path,base:Path):
    p=p.resolve();base=base.resolve();return p==base or base in p.parents

class PortPool:
    def __init__(self,start:int=9000,end:int=9998):
        if not (9000<=start<=end<=9998):raise ValueError('target host port range must remain within 9000..9998; 9999 is reserved for SSRF callback')
        self.start=start;self.end=end;self.reserved=set()
    def _free(self,p:int,host='127.0.0.1')->bool:
        if p in self.reserved:return False
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,0);s.bind((host,p));return True
        except OSError:return False
        finally:s.close()
    def next(self)->int:
        for p in range(self.start,self.end+1):
            if self._free(p):self.reserved.add(p);return p
        raise RuntimeError(f'no free host port in {self.start}-{self.end}')


def _parse_port(port):
    if isinstance(port,int):return int(port),'tcp'
    if isinstance(port,str):
        raw=port.strip();proto='tcp'
        if '/' in raw:raw,proto=raw.rsplit('/',1)
        target=raw.split(':')[-1]
        if '-' in target:raise ValueError(f'port ranges are not supported: {port}')
        return int(target),proto
    if isinstance(port,dict):
        target=port.get('target')
        if target is None:raise ValueError(f'compose port mapping lacks target: {port}')
        if isinstance(target,str) and '-' in target:raise ValueError(f'port ranges are not supported: {port}')
        return int(target),str(port.get('protocol','tcp'))
    raise ValueError(f'unsupported compose port declaration: {port!r}')


def prepare_safe_compose(src:Path,pool:PortPool|None=None,return_assignments:bool=False,run_tag='run'):
    pool=pool or PortPool();data=yaml.safe_load(src.read_text()) or {};services=data.get('services') or {};assigned=[]
    for name,svc in services.items():
        if not isinstance(svc,dict):continue
        if svc.get('privileged') is True:raise ValueError(f'{name}: privileged container rejected')
        if str(svc.get('network_mode','')).lower()=='host':raise ValueError(f'{name}: host network rejected')
        if str(svc.get('pid','')).lower()=='host' or str(svc.get('ipc','')).lower()=='host':raise ValueError(f'{name}: host pid/ipc namespace rejected')
        caps=[str(x).upper() for x in (svc.get('cap_add') or [])]
        if 'SYS_ADMIN' in caps:raise ValueError(f'{name}: SYS_ADMIN capability rejected')
        for vol in svc.get('volumes') or []:
            text=str(vol)
            if '/var/run/docker.sock' in text:raise ValueError(f'{name}: docker socket mount rejected')
            source=text.split(':',1)[0]
            if source.startswith('/') and not source.startswith('/tmp/'):raise ValueError(f'{name}: absolute host bind mount rejected: {source}')
        ports=[]
        for original in svc.get('ports') or []:
            target,proto=_parse_port(original);host=pool.next();ports.append(f'127.0.0.1:{host}:{target}/{proto}')
            assigned.append({'service':name,'target_port':target,'host_port':host,'protocol':proto,'original':str(original)})
        if ports:svc['ports']=ports
    clean=re.sub(r'[^A-Za-z0-9_.-]+','_',run_tag)[-80:]
    out=src.parent/f'.rfc_capture_compose_v51_{clean}.yml';out.write_text(yaml.safe_dump(data,sort_keys=False))
    return (out,assigned) if return_assignments else out


def compose_ps(cwd:Path,compose:Path):
    p=run(['docker','compose','-f',str(compose),'ps','--format','json'],cwd,60)
    if p.returncode:return []
    txt=p.stdout.strip();objs=[]
    if not txt:return []
    try:
        x=json.loads(txt);objs=x if isinstance(x,list) else [x]
    except Exception:
        for line in txt.splitlines():
            try:objs.append(json.loads(line))
            except Exception:pass
    return objs


def published_ports(objs):
    out=[]
    for o in objs:
        pubs=o.get('Publishers') or o.get('publishers') or []
        if isinstance(pubs,str):continue
        for p in pubs:
            pub=p.get('PublishedPort') or p.get('published_port');tgt=p.get('TargetPort') or p.get('target_port')
            if pub:
                try:out.append((int(tgt or 0),int(pub)))
                except Exception:pass
    return sorted(set(out))


def _application_precondition_redirect(location:str|None)->bool:
    if not location:return False
    try:path=urllib.parse.urlsplit(location).path or ''
    except Exception:path=str(location or '')
    return bool(INSTALLER_REDIRECT.search(path))


def _preferred_application_port(ports:list[tuple[int,int]],scheme:str='http'):
    """Choose a likely HTTP(S) application mapping when the source URL omits its port.

    Exact documented logical-port matches are still handled by rewrite_url() first.
    This fallback only avoids treating known debugger/JDWP mappings as HTTP.
    """
    pairs=list(ports or [])
    if not pairs:return None,None,'no_published_ports'
    scheme=(scheme or 'http').lower()
    preferred=TLS_CONTAINER_PORTS if scheme=='https' else HTTP_CONTAINER_PORT_PREFERENCE
    for target in preferred:
        pair=next(((t,p) for t,p in pairs if int(t or 0)==int(target)),None)
        if pair:return pair[0],pair[1],f'{scheme}_application_port_preference'
    safe=next(((t,p) for t,p in pairs if int(t or 0) not in KNOWN_DEBUG_CONTAINER_PORTS),None)
    if safe:return safe[0],safe[1],'non_debug_port_fallback'
    return pairs[0][0],pairs[0][1],'first_published_port_fallback'


def rewrite_url(url:str,ports:list[tuple[int,int]],return_meta=False):
    u=urllib.parse.urlsplit(url if '://' in url else 'http://'+url);logical_port=u.port;chosen=None;target=None;selection_reason=None
    scheme=u.scheme or 'http'
    if logical_port:
        pair=next(((t,p) for t,p in ports if t==logical_port),None)
        if pair:target,chosen=pair;selection_reason='exact_documented_logical_port'
    if chosen is None:
        target,chosen,selection_reason=_preferred_application_port(ports,scheme)
    if chosen is None:raise ValueError('no published Docker port available')
    if not 9000<=int(chosen)<=9998:raise ValueError(f'published target host port escaped 9000..9998 range: {chosen}')
    inferred=False
    if scheme=='http' and int(target or 0) in TLS_CONTAINER_PORTS:
        scheme='https';inferred=True
    rewritten=urllib.parse.urlunsplit((scheme,f'127.0.0.1:{chosen}',u.path or '/',u.query,u.fragment))
    meta={'original_url':url,'rewritten_url':rewritten,'container_port':target,'host_port':chosen,'protocol_inferred':inferred,'scheme':scheme,'port_selection_reason':selection_reason,'known_debug_port_avoided':bool(logical_port is None and any(int(t or 0) in KNOWN_DEBUG_CONTAINER_PORTS for t,_ in ports) and int(target or 0) not in KNOWN_DEBUG_CONTAINER_PORTS)}
    return (rewritten,meta) if return_meta else rewritten


def _headers(spec):
    out={};dropped=[]
    for h in spec.get('headers',[]):
        if ':' not in h:continue
        k,v=h.split(':',1);kl=k.strip().lower()
        if kl=='host':
            if spec.get('effective_host_header'):
                out['Host']=str(spec['effective_host_header'])
            continue
        if kl in {'content-length','connection'}:continue
        if kl in {'cookie','authorization'} and re.search(r'(your-|example|placeholder|<|>)',v,re.I):dropped.append(k.strip());continue
        out[k.strip()]=v.strip()
    return out,dropped


def _raw_path_http_request(method:str,url:str,headers:dict,data,timeout=15):
    """Send an HTTP request without normalizing documented dot segments.

    Activated only by a screening-stage `preserve_raw_path` annotation.  This is
    required for the DataEase whitelist-traversal benchmark where a normal HTTP
    client canonicalizes `/geo/../...` before transmission.
    """
    u=urllib.parse.urlsplit(url)
    if u.scheme!='http':raise ValueError('raw-path preservation currently supports loopback HTTP only')
    if u.hostname not in {'127.0.0.1','localhost','::1'}:raise ValueError('non-loopback raw-path URL rejected')
    path=urllib.parse.urlunsplit(('', '', u.path or '/',u.query,''))
    conn=http.client.HTTPConnection(u.hostname,u.port,timeout=timeout)
    try:
        conn.request(method,path,body=data,headers=headers)
        r=conn.getresponse();content=r.read(200000);rh={k:v for k,v in r.getheaders()}
        return {'status_code':r.status,'headers':rh,'content':content,'text':content.decode('utf-8','replace'),'wire_path':path}
    finally:
        conn.close()


def _request_once(spec,ports,session:requests.Session,timeout=15,category=None):
    url,rmeta=rewrite_url(spec['url'],ports,return_meta=True);u=urllib.parse.urlsplit(url)
    if u.hostname not in {'127.0.0.1','localhost','::1'}:raise ValueError('non-loopback URL rejected')
    headers,dropped=_headers(spec);data='\n'.join(spec.get('data') or []) or None;auth=None
    if spec.get('user') and ':' in spec['user'] and not re.search(r'(your-|example|placeholder|<|>)',spec['user'],re.I):auth=tuple(spec['user'].split(':',1))
    t0=time.time()
    if spec.get('preserve_raw_path'):
        rr=_raw_path_http_request(spec.get('method','GET'),url,headers,data,timeout=timeout);status_code=rr['status_code'];response_headers=rr['headers'];content=rr['content'];body=rr['text'][:200000];wire_path=rr['wire_path']
    else:
        r=session.request(spec.get('method','GET'),url,headers=headers,data=data,auth=auth,timeout=timeout,allow_redirects=False,verify=False);status_code=r.status_code;response_headers=r.headers;content=r.content;body=r.text[:200000];wire_path=u.path+((('?'+u.query) if u.query else ''))
    elapsed=time.time()-t0
    parser_error=bool(APP_PARSER.search(body));db_backend=(category=='sqli' and bool(DB_BACKEND.search(body)) and not parser_error)
    auth_value=next((v for k,v in headers.items() if k.lower()=='authorization'),None)
    location=response_headers.get('Location');content_type=response_headers.get('Content-Type')
    return {'source':spec.get('source'),'session_key':spec.get('session_key','anonymous'),'method':spec.get('method','GET'),'url':url,'logical_url':spec.get('url'),'path':u.path,'wire_path':wire_path,'preserve_raw_path':bool(spec.get('preserve_raw_path')),'request_headers':sorted(headers),'dropped_placeholder_headers':dropped,'request_data':data,'status_code':status_code,'location':location,'content_type':content_type,'body_sha256':hashlib.sha256(content).hexdigest(),'body_length':len(content),'body_preview':body[:3000],'elapsed_seconds':round(elapsed,4),'db_backend_error':db_backend,'application_parser_error':parser_error,'db_error':db_backend,'redirected_to_login':bool((300<=status_code<400 and LOGIN.search(location or '')) or LOGIN.search(body[:1000])),'protected_marker':bool(ADMIN.search(body[:3000])),'auth_denied_marker':bool(AUTH_DENIED.search(body[:3000])),'internal_marker':bool(INTERNAL.search(body[:3000])),'warmup_marker':bool(WARMUP.search(body[:5000])),'tls_required_marker':bool(TLS_REQUIRED.search(body[:3000])),'application_precondition_marker':bool(APP_FIXTURE_MISSING.search(body[:12000]) or (300<=status_code<400 and _application_precondition_redirect(location))),'application_precondition_redirect':bool(300<=status_code<400 and _application_precondition_redirect(location)),'attempts':1,'rewrite_metadata':rmeta,'source_request_sha256':spec.get('source_request_sha256'),'parsed_spec_sha256':spec.get('parsed_spec_sha256') or spec_sha256(spec),'effective_spec_sha256':spec_sha256(spec),'allowed_transformations':list(spec.get('allowed_transformations') or []),'source_parsed_spec_sha256':spec.get('source_parsed_spec_sha256'),'transformed_request_sha256':spec.get('transformed_request_sha256'),'safe_proof_transformation':spec.get('safe_proof_transformation'),'ssti_probe_role':spec.get('ssti_probe_role'),'ssti_expected_output':spec.get('ssti_expected_output'),'ssti_control_marker':spec.get('ssti_control_marker'),'sqli_probe_role':spec.get('sqli_probe_role'),'sqli_control_derivation':spec.get('sqli_control_derivation'),'auth_probe_role':spec.get('auth_probe_role'),'auth_bypass_pair_kind':spec.get('auth_bypass_pair_kind'),'auth_candidate_credential_kind':spec.get('auth_candidate_credential_kind'),'auth_normalized_endpoint':spec.get('auth_normalized_endpoint'),'authorization_header_present':bool(auth_value),'authorization_header_sha256':hashlib.sha256(auth_value.encode()).hexdigest() if auth_value else None,'body_rewrite_metadata':spec.get('body_rewrite_metadata'),'ssrf_host_alignment_metadata':spec.get('ssrf_host_alignment_metadata'),'effective_host_header':spec.get('effective_host_header')}


def request_from_spec(spec,ports,session:requests.Session,retries=3,warmup_retries=8,category=None):
    last=None;warm=0
    for attempt in range(1,retries+1):
        try:
            o=_request_once(spec,ports,session,category=category);o['attempts']=attempt
            while o.get('warmup_marker') and warm<warmup_retries:
                warm+=1;time.sleep(min(3,1+warm*0.25));o=_request_once(spec,ports,session,category=category);o['attempts']=attempt;o['warmup_retries']=warm
            return o
        except (requests.ConnectionError,requests.Timeout,OSError) as e:
            last=e
            if attempt<retries:time.sleep(min(2.0,0.5*attempt))
    raise last or RuntimeError('request failed')


def _ready_probe_url(spec,ports):
    url=rewrite_url(spec['url'],ports);u=urllib.parse.urlsplit(url);return urllib.parse.urlunsplit((u.scheme,u.netloc,u.path or '/','',''))


def wait_for_readiness(specs,ports,timeout=120):
    probes=[];seen=set();warmups=0;preconditions=0;last_status=[]
    for s in specs:
        try:u=_ready_probe_url(s,ports)
        except Exception:continue
        if u not in seen:seen.add(u);probes.append(u)
    if not probes:return False,{'method':'none','attempts':0,'last_errors':['no probe URLs'],'warmup_responses':0}
    deadline=time.time()+timeout;attempt=0;last=[]
    while time.time()<deadline:
        attempt+=1;ok=0;last=[];last_status=[]
        for url in probes:
            try:
                r=requests.get(url,timeout=3,allow_redirects=False,verify=False);body=r.text[:5000];pre=bool(300<=r.status_code<400 and _application_precondition_redirect(r.headers.get('Location')));last_status.append({'url':url,'status':r.status_code,'location':r.headers.get('Location'),'application_precondition_redirect':pre})
                if pre:
                    preconditions+=1
                    if preconditions>=2:return False,{'method':'http_get_documented_path','attempts':attempt,'responding':0,'probe_count':len(probes),'warmup_responses':warmups,'application_precondition_responses':preconditions,'explicit_application_precondition':True,'last_status':last_status,'last_errors':last}
                    continue
                if WARMUP.search(body):warmups+=1;continue
                if TLS_REQUIRED.search(body) and urllib.parse.urlsplit(url).scheme=='http':continue
                ok+=1
            except Exception as e:last.append(f'{url}: {type(e).__name__}: {e}')
        if ok:return True,{'method':'http_get_documented_path','attempts':attempt,'responding':ok,'probe_count':len(probes),'warmup_responses':warmups,'last_status':last_status,'last_errors':last}
        time.sleep(1)
    return False,{'method':'http_get_documented_path','attempts':attempt,'responding':0,'probe_count':len(probes),'warmup_responses':warmups,'application_precondition_responses':preconditions,'explicit_application_precondition':bool(preconditions),'last_status':last_status,'last_errors':last[-5:]}


def _query_ci(pairs:list[tuple[str,str]],name:str):
    name=name.lower()
    for k,v in pairs:
        if k.lower()==name:return v
    return None


def _wfs_fixture_probe_spec(spec:dict):
    """Build a benign WFS DescribeFeatureType probe for a documented GetFeature target.

    This is intentionally narrower than a generic readiness probe.  It only
    activates when the documented experimental request names a concrete WFS
    feature type, so normal HTTP targets are unaffected.
    """
    try:u=urllib.parse.urlsplit(spec.get('url',''))
    except Exception:return None
    pairs=urllib.parse.parse_qsl(u.query,keep_blank_values=True)
    service=_query_ci(pairs,'service');request=_query_ci(pairs,'request')
    typename=_query_ci(pairs,'typename') or _query_ci(pairs,'typenames')
    if not (service and service.lower()=='wfs' and request and request.lower()=='getfeature' and typename):return None
    version=_query_ci(pairs,'version') or '1.0.0'
    q=[('service','WFS'),('version',version),('request','DescribeFeatureType'),('typeName',typename)]
    url=urllib.parse.urlunsplit((u.scheme,u.netloc,u.path or '/',urllib.parse.urlencode(q),''))
    return {'kind':'wfs_describe_feature_type','url':url,'type_name':typename,'version':version}


def fixture_readiness_requirements(category:str,specs:list[dict]):
    reqs=[];seen=set()
    # The current benchmark race was observed on a SQLi-via-WFS fixture, but
    # feature-type readiness is a transport/application prerequisite independent
    # of the final vulnerability category.  Apply it whenever the documented
    # recipe actually contains a WFS GetFeature target.
    for spec in specs or []:
        r=_wfs_fixture_probe_spec(spec)
        if r:
            k=(r['kind'],r['url'])
            if k not in seen:seen.add(k);reqs.append(r)
    return reqs


def _fixture_probe_ready(req:dict,body:str,status:int):
    if not (200<=int(status)<300):return False
    if WARMUP.search(body) or APP_FIXTURE_MISSING.search(body) or WFS_SERVICE_EXCEPTION.search(body):return False
    if req.get('kind')=='wfs_describe_feature_type':
        local=str(req.get('type_name','')).split(':')[-1]
        # GeoServer DescribeFeatureType should return an XML schema containing
        # the requested feature name.  Requiring both avoids accepting a generic
        # 200 page as fixture readiness.
        return bool(WFS_SCHEMA.search(body) and re.search(r'\bname=["\']'+re.escape(local)+r'["\']',body,re.I))
    return True


def wait_for_fixture_readiness(category:str,specs:list[dict],ports,timeout=120):
    reqs=fixture_readiness_requirements(category,specs)
    if not reqs:return True,{'required':False,'method':'none','requirements':0,'attempts':0}
    deadline=time.time()+timeout;attempt=0;missing=0;warmups=0;last=[];last_errors=[];last_missing=False
    while time.time()<deadline:
        attempt+=1;all_ready=True;last=[];last_errors=[];last_missing=False
        for req in reqs:
            try:
                url=rewrite_url(req['url'],ports);r=requests.get(url,timeout=4,allow_redirects=False,verify=False);body=r.text[:20000]
                miss=bool(APP_FIXTURE_MISSING.search(body));warm=bool(WARMUP.search(body));ready=_fixture_probe_ready(req,body,r.status_code)
                missing+=int(miss);warmups+=int(warm);last_missing=last_missing or miss
                last.append({'kind':req['kind'],'type_name':req.get('type_name'),'url':url,'status':r.status_code,'ready':ready,'missing_marker':miss,'warmup_marker':warm,'body_sha256':hashlib.sha256(r.content).hexdigest()})
                if not ready:all_ready=False
            except Exception as e:
                all_ready=False;last_errors.append(f"{req.get('kind')}: {type(e).__name__}: {e}")
        if all_ready:
            return True,{'required':True,'method':'fixture_specific_benign_probe','requirements':len(reqs),'attempts':attempt,'ready':True,'missing_responses':missing,'warmup_responses':warmups,'last_status':last,'last_errors':last_errors}
        time.sleep(1)
    return False,{'required':True,'method':'fixture_specific_benign_probe','requirements':len(reqs),'attempts':attempt,'ready':False,'explicit_missing_fixture':bool(last_missing or missing),'missing_responses':missing,'warmup_responses':warmups,'last_status':last,'last_errors':last_errors[-5:]}


class CallbackRecorder:
    def __init__(self,bind_ip:str,port:int,nonce:str):
        self.bind_ip=bind_ip;self.port=port;self.nonce=nonce;self.receipts=[];outer=self
        class H(BaseHTTPRequestHandler):
            def _handle(self):
                n=int(self.headers.get('Content-Length','0') or 0);body=self.rfile.read(min(n,65536)) if n else b''
                outer.receipts.append({'received_at':now(),'method':self.command,'path':self.path,'headers':{k:v for k,v in self.headers.items() if k.lower() not in {'authorization','cookie'}},'body_sha256':hashlib.sha256(body).hexdigest(),'remote_addr':self.client_address[0],'nonce_present':outer.nonce in self.path})
                payload=f'RFC_CALLBACK_OK:{outer.nonce}'.encode();self.send_response(200);self.send_header('Content-Type','text/plain');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
            do_GET=_handle;do_POST=_handle;do_PUT=_handle
            def log_message(self,*args):pass
        self.server=ThreadingHTTPServer((bind_ip,port),H);self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
    def start(self):self.thread.start();return self
    def close(self):self.server.shutdown();self.server.server_close();self.thread.join(timeout=3)


def docker_gateway(cwd:Path,compose:Path):
    q=run(['docker','compose','-f',str(compose),'ps','-q'],cwd,30)
    for cid in q.stdout.split():
        p=run(['docker','inspect',cid],cwd,30)
        if p.returncode:continue
        try:obj=json.loads(p.stdout)[0]
        except Exception:continue
        nets=((obj.get('NetworkSettings') or {}).get('Networks') or {})
        for n in nets.values():
            g=n.get('Gateway')
            if g and ':' not in g:return g
    return None


def free_callback_port(bind_ip,start=9999,end=9999,avoid=()):
    # V5.1.1 reserves a single deterministic callback port.  Target Docker
    # mappings may never consume 9999, so this reservation cannot collide with
    # the experiment allocator.  Fail closed if corporate/local software already
    # occupies it on the Docker gateway.
    p=9999
    if p in set(avoid):
        raise RuntimeError('reserved SSRF callback port 9999 conflicts with a target mapping')
    s=socket.socket()
    try:
        s.bind((bind_ip,p));return p
    except OSError as e:
        raise RuntimeError(f'reserved SSRF callback port 9999 unavailable on Docker gateway {bind_ip}: {e}')
    finally:
        s.close()


def _content_type(spec:dict)->str:
    for h in spec.get('headers') or []:
        if ':' in h:
            k,v=h.split(':',1)
            if k.strip().lower()=='content-type':return v.strip().lower()
    return ''


def _ssrf_target_field(key:str,value:str)->bool:
    dec=urllib.parse.unquote(str(value or ''))
    return bool(SSRF_KEY.search(str(key or '')) and re.match(r'(?i)^https?://',dec.strip()))


def _rewrite_json_ssrf(obj,callback_url,path='$',changes=None):
    changes=changes if changes is not None else []
    if isinstance(obj,dict):
        out={}
        for k,v in obj.items():
            p=f'{path}.{k}'
            if isinstance(v,str) and _ssrf_target_field(str(k),v):
                changes.append({'location':'json','field_path':p,'key':str(k),'original_sha256':hashlib.sha256(v.encode()).hexdigest(),'replacement_sha256':hashlib.sha256(callback_url.encode()).hexdigest()})
                out[k]=callback_url
            else:out[k]=_rewrite_json_ssrf(v,callback_url,p,changes)
        return out
    if isinstance(obj,list):return [_rewrite_json_ssrf(v,callback_url,f'{path}[{i}]',changes) for i,v in enumerate(obj)]
    return obj


def _replace_ssrf_values(spec:dict,callback_url:str):
    out=copy.deepcopy(spec);changes=[];u=urllib.parse.urlsplit(out['url']);pairs=urllib.parse.parse_qsl(u.query,keep_blank_values=True);new=[]
    for k,v in pairs:
        if _ssrf_target_field(k,v):
            changes.append({'location':'query','field_path':f'query.{k}','key':k,'original_sha256':hashlib.sha256(v.encode()).hexdigest(),'replacement_sha256':hashlib.sha256(callback_url.encode()).hexdigest()});v=callback_url
        new.append((k,v))
    if any(x.get('location')=='query' for x in changes):out['url']=urllib.parse.urlunsplit((u.scheme,u.netloc,u.path,urllib.parse.urlencode(new,doseq=True),u.fragment))
    ctype=_content_type(out);nd=[];body_meta=[]
    for di,d in enumerate(out.get('data') or []):
        src_sha=hashlib.sha256(d.encode()).hexdigest();effective=d;local_changes=[]
        if out.get('ssrf_body_url_substitution_allowed'):
            def repl(m):
                original=m.group('url')
                local_changes.append({'location':'body_url_attribute','field_path':f'body[{di}].href','key':'href','original_sha256':hashlib.sha256(original.encode()).hexdigest(),'replacement_sha256':hashlib.sha256(callback_url.encode()).hexdigest()})
                return m.group('prefix')+callback_url+m.group('suffix')
            effective=SSRF_BODY_URL_ATTR.sub(repl,effective)
        if not local_changes and ('application/json' in ctype or d.lstrip().startswith(('{','['))):
            try:
                obj=json.loads(d);obj2=_rewrite_json_ssrf(obj,callback_url,f'body[{di}]',local_changes)
                if local_changes:effective=json.dumps(obj2,separators=(',',':'))
            except Exception:pass
        if not local_changes and ('application/x-www-form-urlencoded' in ctype or ('=' in d and not d.lstrip().startswith(('{','[')))):
            try:pairs=urllib.parse.parse_qsl(d,keep_blank_values=True)
            except Exception:pairs=[]
            if pairs:
                pp=[]
                for k,v in pairs:
                    if _ssrf_target_field(k,v):
                        local_changes.append({'location':'form','field_path':f'body[{di}].{k}','key':k,'original_sha256':hashlib.sha256(v.encode()).hexdigest(),'replacement_sha256':hashlib.sha256(callback_url.encode()).hexdigest()});v=callback_url
                    pp.append((k,v))
                if local_changes:effective=urllib.parse.urlencode(pp,doseq=True)
        nd.append(effective);changes.extend(local_changes)
        body_meta.append({'index':di,'content_type':ctype or None,'source_body_sha256':src_sha,'effective_body_sha256':hashlib.sha256(effective.encode()).hexdigest(),'substitution_count':len(local_changes)})
    out['data']=nd
    if changes:
        if any(x.get('location')=='body_url_attribute' for x in changes):
            old_headers=list(out.get('headers') or [])
            out['headers']=[h for h in old_headers if not h.lower().startswith('content-length:')]
            if len(out['headers'])!=len(old_headers):
                out['allowed_transformations']=list(out.get('allowed_transformations') or [])+['recompute_content_length_after_controlled_body_substitution']
        out['allowed_transformations']=list(out.get('allowed_transformations') or [])+['controlled_local_ssrf_callback_substitution']
        out['parsed_spec_sha256']=spec.get('parsed_spec_sha256') or spec_sha256(spec)
        out['body_rewrite_metadata']=body_meta
        out['ssrf_substitutions']=changes
        if out.get('ssrf_host_alignment_required'):
            authority=urllib.parse.urlsplit(callback_url).netloc
            source_hosts=[h.split(':',1)[1].strip() for h in out.get('headers') or [] if h.lower().startswith('host:') and ':' in h]
            out['effective_host_header']=authority
            out['allowed_transformations']=list(out.get('allowed_transformations') or [])+['controlled_ssrf_host_header_alignment']
            out['ssrf_host_alignment_metadata']={'required':True,'basis':out.get('ssrf_host_alignment_basis'),'source_host_header_sha256':out.get('source_host_header_sha256') or [hashlib.sha256(h.encode()).hexdigest() for h in source_hosts],'effective_host_header_sha256':hashlib.sha256(authority.encode()).hexdigest(),'effective_authority':authority}
    return out,changes


def evidence(category,obs,idx):
    value={'kind':'http_observation',**obs}
    if category=='sqli':value['boolean_signal_detected']=False
    if category=='ssrf':value['callback_received']=False
    if category=='auth_bypass':value['kind']='admin' if re.search(r'/(admin|manage|management|dashboard|apisix/admin)',obs['path'],re.I) else 'http'
    return {'id':f'E{idx}','target_id':'T1','target':'local_public_benchmark','type':'observational_evidence','value':value,'source_tool':'documented_http_replay_v5_1','confidence':0.9,'timestamp':now(),'captured_at':now(),'tags':['external_public_benchmark','documented_reproduction','proof_only_v5_1']}


def callback_evidence(receipt,idx,nonce):
    return {'id':f'E{idx}','target_id':'T1','target':'local_public_benchmark','type':'observational_evidence','value':{'kind':'server_side_callback','callback_received':True,'nonce':nonce,'receipt':receipt},'source_tool':'local_ssrf_callback_v5_1','confidence':1.0,'timestamp':now(),'captured_at':now(),'tags':['external_public_benchmark','local_callback','server_side_outbound']}


def evaluate(category,specs,obs,evidences,scenario_kind,callback_receipts=None):
    ids=[e['id'] for e in evidences];status='needs_manual_review';mapping={};limitations=[];callback_receipts=callback_receipts or []
    if scenario_kind=='ambiguous_positive':return status,{},['partial_evidence_mode_predeclared']
    if category=='sqli' and len(obs)>=2:
        backend=[ids[i] for i,x in enumerate(obs) if x.get('db_backend_error')]
        parser=[ids[i] for i,x in enumerate(obs) if x.get('application_parser_error')]
        if backend:
            status='confirmed';refs=list(dict.fromkeys(ids[:1]+backend));mapping={k:refs for k in ['control_request_compared','differential_response_or_error','target_endpoint_match','reproduction_request']}
        elif parser:limitations.append('application/parser error observed without backend-database evidence; SQLi confirmation withheld')
        else:limitations.append('no backend-database SQLi evidence observed')
    elif category=='ssrf':
        hits=[e['id'] for e in evidences if (e.get('value') or {}).get('kind')=='server_side_callback' and (e.get('value') or {}).get('callback_received')]
        if hits:status='confirmed';mapping={k:hits for k in ['server_side_outbound_interaction','callback_or_internal_response','not_client_side_request']}
        else:limitations.append('no nonce-correlated local callback observed')
    elif category=='auth_bypass':
        controls=[i for i,s in enumerate(specs) if s.get('auth_probe_role')=='control'];candidates=[i for i,s in enumerate(specs) if s.get('auth_probe_role')=='candidate']
        if controls and candidates:
            ci,pi=controls[0],candidates[0];c=obs[ci];p=obs[pi];cs=specs[ci];ps=specs[pi]
            same_target=bool(cs.get('auth_normalized_endpoint') and cs.get('auth_normalized_endpoint')==ps.get('auth_normalized_endpoint'))
            control_denied=bool(c.get('status_code') in {400,401,403,500} or c.get('redirected_to_login') or c.get('auth_denied_marker'))
            candidate_ok=bool(200<=p.get('status_code',0)<300 and not p.get('redirected_to_login') and not p.get('application_precondition_marker'))
            credential_kind=ps.get('auth_candidate_credential_kind')
            no_issued_session=credential_kind in {'no_credential_path_bypass','documented_default_secret_bearer','documented_empty_secret_bearer'}
            path_preserved=(credential_kind!='no_credential_path_bypass' or bool(p.get('preserve_raw_path') and '/../' in (p.get('wire_path') or '')))
            if same_target and control_denied and candidate_ok and no_issued_session and path_preserved:
                refs=[ids[ci],ids[pi]];status='confirmed';mapping={'pre_post_auth_comparison':refs,'protected_resource_access':[ids[pi]],'no_valid_session_used':refs}
            else:limitations.append('source-grounded auth-bypass control/candidate evidence incomplete')
        else:
            auth=[i for i,s in enumerate(specs) if s.get('session_key')=='authenticated'];unauth=[i for i,s in enumerate(specs) if s.get('session_key')=='anonymous']
            goodu=[i for i in unauth if 200<=obs[i]['status_code']<300 and not obs[i]['redirected_to_login'] and obs[i]['protected_marker']]
            if auth and goodu:
                refs=[ids[auth[0]],ids[goodu[0]]];status='confirmed';mapping={k:refs for k in ['pre_post_auth_comparison','protected_resource_access','no_valid_session_used']}
            else:limitations.append('authenticated/anonymous protected-resource comparison not observed')
    elif category=='idor' and len(obs)>=2:
        sessions={s.get('session_key') for s in specs}
        if len(sessions)>=2 and all(200<=x['status_code']<300 for x in obs[:2]) and obs[0]['body_sha256']!=obs[1]['body_sha256']:
            status='confirmed';mapping={k:ids[:2] for k in ['distinct_identities_or_objects','unauthorized_resource_access','authorized_control_request']}
        else:limitations.append('dual-identity authorization evidence not established')
    elif category=='ssti':
        control=[i for i,s in enumerate(specs) if s.get('ssti_probe_role')=='control']
        candidate=[i for i,s in enumerate(specs) if s.get('ssti_probe_role')=='candidate']
        if control and candidate:
            ci,pi=control[0],candidate[0];c=obs[ci];p=obs[pi];marker=specs[ci].get('ssti_control_marker') or 'RFC_SSTI_CONTROL_7X7';expected=specs[pi].get('ssti_expected_output') or '49'
            same_endpoint=(urllib.parse.urlsplit(specs[ci].get('url','')).path==urllib.parse.urlsplit(specs[pi].get('url','')).path)
            control_ok=200<=c.get('status_code',0)<300 and marker in c.get('body_preview','')
            candidate_ok=200<=p.get('status_code',0)<300 and expected in p.get('body_preview','') and '{{7*7}}' not in p.get('body_preview','')
            differential=c.get('body_sha256')!=p.get('body_sha256')
            if same_endpoint and control_ok and candidate_ok and differential:
                status='confirmed';refs=[ids[ci],ids[pi]];mapping={'control_request_compared':refs,'template_expression_evaluated':[ids[pi]],'expected_deterministic_output_observed':[ids[pi]],'target_endpoint_match':refs}
            else:limitations.append('benign SSTI control/candidate evaluation evidence incomplete')
        else:
            joined='\n'.join(x['body_preview'] for x in obs);raw=' '.join(s.get('raw','') for s in specs)
            if ('{{7*7}}' in raw and '49' in joined and '{{7*7}}' not in joined):status='confirmed'
            else:limitations.append('template evaluation not directly observed')
    elif category=='xss':limitations.append('HTTP replay cannot establish browser-side script execution; retain for later browser adapter')
    return status,mapping,limitations


def capture_validity(category,scenario_kind=None,specs=None,observations=None,evidences=None):
    # Backward compatibility with V5 tests/callers that used
    # capture_validity(scenario_kind, specs, observations, evidences).
    legacy=False
    if category in {'positive_confirmable','ambiguous_positive','negative_lookalike'}:
        legacy=True;category,scenario_kind,specs,observations,evidences='unknown',category,scenario_kind,specs,observations
    specs=specs or [];observations=observations or [];evidences=evidences or []
    success=sum(1 for x in observations if not x.get('request_error'));errors=len(observations)-success
    if not evidences or success==0:return 'CAPTURE_INVALID','no successful direct HTTP evidence',False
    if any(x.get('tls_required_marker') for x in observations):return 'PROTOCOL_MISMATCH','target explicitly required TLS; request protocol invalid',False
    if any(x.get('warmup_marker') for x in observations):return 'APPLICATION_NOT_FULLY_READY','application warm-up/deployment response captured',False
    if any(x.get('application_precondition_marker') for x in observations):return 'APPLICATION_PRECONDITION_FAILED','benchmark application fixture/workspace/feature type required by the documented reproduction is missing',False
    if category in {'sqli','idor','auth_bypass'} and observations and all(x.get('redirected_to_login') for x in observations if not x.get('request_error')):
        return 'AUTH_PRECONDITION_FAILED','all successful requests redirected to authentication/login',False
    if scenario_kind=='positive_confirmable' and success<len(specs):return 'CAPTURE_INVALID',f'positive-confirmable recipe incomplete: {success}/{len(specs)} required requests succeeded',False
    if scenario_kind=='ambiguous_positive':
        state=('CAPTURE_PARTIAL_EVIDENTIARY' if errors else 'CAPTURE_OK_EVIDENTIARY')
        if legacy:state=('CAPTURE_PARTIAL' if errors else 'CAPTURE_OK')
        return state,'ambiguous-positive direct evidence acquired',True
    return ('CAPTURE_OK' if legacy else 'CAPTURE_OK_EVIDENTIARY'),'all required documented requests acquired direct evidence',True


def classify_runtime_failure(text:str):
    t=text or ''
    if REGISTRY_ERR.search(t):return 'REGISTRY_PULL_FAILED'
    if NETWORK_ERR.search(t):return 'NETWORK_DEPENDENCY_UNREACHABLE'
    if re.search(r'permission denied.*docker\.sock|cannot connect to the docker daemon',t,re.I):return 'DOCKER_DAEMON_UNAVAILABLE'
    if re.search(r'unknown command.*docker compose|docker:.*compose.*not',t,re.I):return 'DOCKER_COMPOSE_UNAVAILABLE'
    return 'RUNTIME_ERROR'


def runtime_metadata(up_stderr:str,ps:list[dict],assigned:list[dict]):
    docker_arch=None
    try:
        p=subprocess.run(['docker','info','--format','{{.Architecture}}'],text=True,capture_output=True,timeout=20)
        if p.returncode==0:docker_arch=p.stdout.strip() or None
    except Exception:pass
    warning=bool(re.search(r'platform .* does not match.*host platform',up_stderr or '',re.I))
    return {'python_platform':platform.platform(),'host_machine':platform.machine(),'docker_server_arch':docker_arch,'platform_mismatch_warning':warning,'emulation_may_be_used':warning,'assigned_host_ports':assigned,'compose_services':[{'service':x.get('Service') or x.get('service'),'state':x.get('State') or x.get('state'),'health':x.get('Health') or x.get('health'),'image':x.get('Image') or x.get('image')} for x in ps]}


def collect_diagnostics(cwd:Path,compose:Path|None):
    if not compose:return {}
    d={}
    for name,cmd,to in [('ps',['docker','compose','-f',str(compose),'ps','--format','json'],60),('logs',['docker','compose','-f',str(compose),'logs','--no-color','--tail','400'],120)]:
        try:
            p=run(cmd,cwd,to);d[name]={'returncode':p.returncode,'stdout':p.stdout[-50000:],'stderr':p.stderr[-10000:]}
        except Exception as e:d[name]={'error':f'{type(e).__name__}: {e}'}
    return d


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--screened-jobs',required=True);ap.add_argument('--sources-root',required=True);ap.add_argument('--output-dir',required=True);ap.add_argument('--run-id',required=True);ap.add_argument('--limit',type=int);ap.add_argument('--host-port-start',type=int,default=9000);ap.add_argument('--host-port-end',type=int,default=9998);ap.add_argument('--readiness-timeout',type=int,default=120);ap.add_argument('--groups',help='comma-separated group IDs for targeted regression/acquisition');a=ap.parse_args()
    if not (9000<=a.host_port_start<=a.host_port_end<=9998):raise SystemExit('target host ports must stay within 9000..9998; 9999 is reserved for SSRF callback')
    root=Path(a.sources_root).resolve();out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True);diagdir=out.parent/'diagnostics';diagdir.mkdir(parents=True,exist_ok=True)
    jobs=[json.loads(x) for x in Path(a.screened_jobs).read_text().splitlines() if x.strip() and json.loads(x).get('preexecution_automatable')]
    if a.groups:
        wanted={x.strip() for x in a.groups.split(',') if x.strip()};jobs=[j for j in jobs if j.get('group_id') in wanted]
    if a.limit:jobs=jobs[:a.limit]
    summary=[]
    for n,j in enumerate(jobs,1):
        gid=j['group_id'];print(f'[{n}/{len(jobs)}] {gid} {j["category"]}',flush=True);base=(root/j['source_name']).resolve();compose=(base/j['compose_path']).resolve();safe_compose=None;callback=None;up_stderr='';ps=[];assigned=[]
        rec={'run_id':a.run_id,'group_id':gid,'category':j['category'],'scenario_kind':j['scenario_kind'],'screen_reason':j['screen_reason'],'status':'RUN_ERROR','capture_validity':'NOT_EVALUATED','started_at':now()}
        try:
            unsafe=[];fidelity=[]
            for spec in j.get('selected_requests',[]):
                ok,reason=proof_only_safe(spec)
                if not ok:unsafe.append({'url':spec.get('url'),'method':spec.get('method'),'reason':reason})
                fok,freason=replay_fidelity_precheck(spec)
                if not fok:fidelity.append({'url':spec.get('url'),'method':spec.get('method'),'reason':freason})
            if unsafe:
                rec.update({'status':'EXCLUDED_UNSAFE_RECIPE','capture_validity':'NOT_EXECUTED','completed_at':now(),'unsafe_requests':unsafe});raise RuntimeError('__RFC_EXPECTED_EXCLUSION__')
            if fidelity:
                rec.update({'status':'REPLAY_FIDELITY_FAILURE','capture_validity':'REPLAY_FIDELITY_FAILURE','completed_at':now(),'replay_fidelity_failures':fidelity});raise RuntimeError('__RFC_EXPECTED_EXCLUSION__')
            if not _inside(compose,base) or not compose.is_file():raise ValueError('compose path missing or escapes source root')
            pool=PortPool(a.host_port_start,a.host_port_end);safe_compose,assigned=prepare_safe_compose(compose,pool,return_assignments=True,run_tag=f'{a.run_id}_{gid}')
            up=run(['docker','compose','-f',str(safe_compose),'up','-d'],safe_compose.parent,600);up_stderr=up.stderr
            if up.returncode:
                cls=classify_runtime_failure(up.stdout+'\n'+up.stderr);raise RuntimeError(f'{cls}: docker compose up failed: '+up.stderr[-1500:])
            ports=[]
            for _ in range(60):
                ps=compose_ps(safe_compose.parent,safe_compose);ports=published_ports(ps)
                if ports:break
                time.sleep(1)
            if not ports:raise RuntimeError('no published Docker ports discovered')
            if any(not 9000<=p<=9998 for _,p in ports):raise RuntimeError(f'published target host ports outside 9000..9998 range: {ports}')
            ready,readiness=wait_for_readiness(j['selected_requests'],ports,a.readiness_timeout);rec['readiness']=readiness
            if not ready:
                c='APPLICATION_PRECONDITION_FAILED' if readiness.get('explicit_application_precondition') else ('APPLICATION_NOT_FULLY_READY' if readiness.get('warmup_responses') else 'TARGET_NOT_READY')
                reason='benchmark application is still at installer/setup precondition' if c=='APPLICATION_PRECONDITION_FAILED' else 'target did not become application-ready before timeout'
                rec.update({'status':c,'capture_validity':c,'capture_validity_reason':reason,'completed_at':now(),'ports':ports,'runtime_metadata':runtime_metadata(up_stderr,ps,assigned),'error':reason})
            else:
                fixture_ready,fixture_meta=wait_for_fixture_readiness(j['category'],j['selected_requests'],ports,a.readiness_timeout);rec['fixture_readiness']=fixture_meta
                if not fixture_ready:
                    c='APPLICATION_PRECONDITION_FAILED' if fixture_meta.get('explicit_missing_fixture') else 'APPLICATION_NOT_FULLY_READY'
                    rec.update({'status':c,'capture_validity':c,'completed_at':now(),'ports':ports,'runtime_metadata':runtime_metadata(up_stderr,ps,assigned),'error':'benchmark fixture did not become ready before timeout'})
                    raise RuntimeError('__RFC_EXPECTED_FIXTURE_EXCLUSION__')
                effective_specs=copy.deepcopy(j['selected_requests'][:6]);callback_meta=None;callback_changes=[]
                if j['category']=='ssrf':
                    gateway=docker_gateway(safe_compose.parent,safe_compose)
                    if gateway:
                        avoid=[p for _,p in ports];cbport=free_callback_port(gateway,9999,9999,avoid);nonce=hashlib.sha256(f'{a.run_id}:{gid}'.encode()).hexdigest()[:20];callback=CallbackRecorder(gateway,cbport,nonce).start();cburl=f'http://{gateway}:{cbport}/rfc/{nonce}'
                        rewritten=[]
                        for spec in effective_specs:
                            x,changes=_replace_ssrf_values(spec,cburl);rewritten.append(x);callback_changes.extend(changes)
                        effective_specs=rewritten;callback_meta={'bind_ip':gateway,'port':cbport,'nonce':nonce,'url':cburl,'substitutions':callback_changes,'adapter_version':'v5.1.4'}
                    else:rec['callback_setup_warning']='Docker bridge gateway not discovered; SSRF callback substitution unavailable'
                sessions={};observations=[]
                for spec in effective_specs:
                    key=spec.get('session_key','anonymous');sessions.setdefault(key,requests.Session())
                    try:observations.append(request_from_spec(spec,ports,sessions[key],category=j['category']))
                    except Exception as e:observations.append({'request_error':f'{type(e).__name__}: {e}','status_code':0,'body_sha256':'','body_length':0,'body_preview':'','path':'','redirected_to_login':False,'protected_marker':False,'internal_marker':False,'db_backend_error':False,'application_parser_error':False,'warmup_marker':False,'tls_required_marker':False,'application_precondition_marker':False,'attempts':3})
                time.sleep(0.4 if callback else 0);receipts=list(callback.receipts) if callback else []
                ev=[evidence(j['category'],x,i+1) for i,x in enumerate(observations) if not x.get('request_error')]
                for receipt in receipts:ev.append(callback_evidence(receipt,len(ev)+1,callback_meta['nonce']))
                valid=[(s,x) for s,x in zip(effective_specs,observations) if not x.get('request_error')];valid_specs=[x[0] for x in valid];valid_obs=[x[1] for x in valid]
                cstate,creason,scientific=capture_validity(j['category'],j['scenario_kind'],effective_specs,observations,ev)
                status,mapping,limits=evaluate(j['category'],valid_specs,valid_obs,ev,j['scenario_kind'],receipts);vid='V-'+hashlib.sha256(gid.encode()).hexdigest()[:12]
                if not scientific:limits=list(limits)+['capture_invalid_infrastructure_precondition_or_fidelity']
                validator={'validation_id':vid,'candidate_id':'C-'+gid,'status':status,'confidence':0.9 if status=='confirmed' else 0.35,'evidence_ids':[e['id'] for e in ev],'proof_obligation_evidence':mapping,'limitations':limits,'created_at':now()}
                result={'status':'ok' if scientific else 'capture_invalid','rfc_capture':{'evidences':ev,'candidates':[{'candidate_id':'C-'+gid,'category':j['category'],'title':f'External {j["category"]} candidate'}],'validator_results':[validator],'validation_records':[{'candidate':{'candidate_id':'C-'+gid,'category':j['category']},'validator_result':validator,'lifecycle_finding':{'title':f'External documented {j["category"]} finding','status':'probable' if status=='confirmed' else 'manual_review'}}],'trace_events':[]}}
                rec.update({'status':'OK' if scientific else 'CAPTURE_INVALID','transport_validity':'TRANSPORT_OK' if all(not x.get('request_error') for x in observations) else 'TRANSPORT_PARTIAL','capture_validity':cstate,'capture_validity_reason':creason,'completed_at':now(),'ports':ports,'runtime_metadata':runtime_metadata(up_stderr,ps,assigned),'observations':observations,'callback':callback_meta,'callback_receipts':receipts,'result':result})
        except RuntimeError as e:
            if str(e) in {'__RFC_EXPECTED_EXCLUSION__','__RFC_EXPECTED_FIXTURE_EXCLUSION__'}:pass
            else:
                msg=str(e);rec.update({'status':'RUN_ERROR','capture_validity':'CAPTURE_INVALID','completed_at':now(),'error':msg,'failure_class':classify_runtime_failure(msg)})
        except Exception as e:
            msg=f'{type(e).__name__}: {e}';rec.update({'status':'RUN_ERROR','capture_validity':'CAPTURE_INVALID','completed_at':now(),'error':msg,'failure_class':classify_runtime_failure(msg)})
        finally:
            if callback:
                try:callback.close()
                except Exception:pass
            if safe_compose:
                diagnostics=collect_diagnostics(safe_compose.parent,safe_compose);(diagdir/f'{gid}.json').write_text(json.dumps({'run_id':a.run_id,'group_id':gid,'diagnostics':diagnostics},indent=2,sort_keys=True));rec['diagnostics_file']=str((diagdir/f'{gid}.json').relative_to(out.parent))
                try:run(['docker','compose','-f',str(safe_compose),'down','-v','--remove-orphans'],safe_compose.parent,240)
                except Exception:pass
                try:safe_compose.unlink()
                except Exception:pass
        (out/f'{gid}.json').write_text(json.dumps(rec,indent=2,sort_keys=True));summary.append({'run_id':a.run_id,'group_id':gid,'category':j['category'],'status':rec['status'],'capture_validity':rec.get('capture_validity'),'failure_class':rec.get('failure_class'),'validator_status':((rec.get('result',{}).get('rfc_capture',{}).get('validation_records') or [{}])[0].get('validator_result') or {}).get('status')})
    from collections import Counter
    valid=sum(x['status']=='OK' for x in summary);invalid=sum(x['status'] in {'CAPTURE_INVALID','TARGET_NOT_READY','APPLICATION_NOT_FULLY_READY','APPLICATION_PRECONDITION_FAILED','REPLAY_FIDELITY_FAILURE'} for x in summary);errors=sum(x['status']=='RUN_ERROR' for x in summary);excluded=sum(x['status'].startswith('EXCLUDED_') for x in summary)
    state='PASS' if valid and not (invalid or errors) else ('PARTIAL' if valid else 'FAIL')
    rep={'run_id':a.run_id,'status':state,'scheduled':len(jobs),'valid_captures':valid,'invalid_captures':invalid,'run_errors':errors,'preexecution_excluded':excluded,'capture_validity':dict(Counter(x.get('capture_validity') for x in summary)),'failure_class':dict(Counter(x.get('failure_class') for x in summary if x.get('failure_class'))),'validator_status':dict(Counter(x.get('validator_status') for x in summary if x.get('validator_status'))),'host_port_policy':{'start':a.host_port_start,'end':a.host_port_end,'loopback_only':True},'rows':summary};(out/'acquisition_summary.json').write_text(json.dumps(rep,indent=2,sort_keys=True));print(json.dumps({k:v for k,v in rep.items() if k!='rows'},indent=2))
    if not jobs or not valid:raise SystemExit(2)
if __name__=='__main__':main()
