# Independent External Scenario Guide — Main-V2 Formal Patch

The internal Docker benchmark remains **mechanism validation only**. Formal risk calibration/certification requires independently verifiable external/public scenarios. Repetitions, timestamp mutations, artifact mutations, or renamed copies never increase formal N.

## 1. Recommended acquisition target

The included `external_group_plan_120.csv` preregisters 120 acquisition slots across the six current vulnerability families:

- 48 tune groups;
- 48 certify groups;
- 24 held-out test groups;
- 36 planned positive-confirmable groups in the certify split, giving a modest buffer over the 30-confirmation minimum for primary `alpha=.10`.

The CSV is a **collection plan, not experiment data**. Every `FILL_ME` field must be replaced by a real scenario identity and independently verifiable oracle before import. Recompute `scenario_fingerprint` from the real product/version/target-state identity rather than retaining the placeholder-derived value.

## 2. Independence-eligible oracle fields

Every independence-eligible oracle row must include:

```json
{
  "capture_id": "unique-capture-id",
  "case_id": "scenario-name",
  "category": "idor",
  "pair_id": "idor",
  "group_id": "globally-unique-independent-group",
  "source_class": "public_benchmark",
  "independence_eligible": true,
  "split_role": "certify",
  "oracle_source": "known-vulnerable-image-or-independent-advisory",
  "oracle_independent_of_validator": true,
  "scenario_fingerprint": "sha256-of-real-scenario-identity",
  "independence_basis": "why this is not a repeat/mutation of another group",
  "software_product": "product name",
  "software_version": "pinned version",
  "target_state_id": "unique deployment/state identifier",
  "vulnerable": true,
  "ideal_decision": "confirm"
}
```

The blinded capture must not contain `vulnerable`, `ideal_decision`, or oracle-source information.

## 3. Evidence-bound proof obligations

External adapters may satisfy canonical proof obligations that the internal safe analyzer cannot collect, but only by binding each obligation to direct evidence IDs:

```json
{
  "validator_result": {
    "evidence_ids": ["E-auth-control", "E-unauth", "E-resource"],
    "proof_obligation_evidence": {
      "pre_post_auth_comparison": ["E-auth-control", "E-unauth"],
      "protected_resource_access": ["E-resource"],
      "no_valid_session_used": ["E-unauth", "E-resource"]
    }
  }
}
```

A token is ignored if it is not canonical for the vulnerability family or if any referenced evidence ID is absent from the direct ProofBundle evidence set. This is intended to expand confirmable SQLi/IDOR/auth-bypass scenarios without treating a free-floating annotation as proof.

## 4. Pre-import audit

Run:

```bash
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/validate_external_bundle.py \
  --captures external/captures_blinded.jsonl \
  --oracle external/oracle.jsonl \
  --report external/validation_report.json
```

Then import only after reviewing warnings:

```bash
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/import_external_captures.py \
  --captures external/captures_blinded.jsonl \
  --oracle external/oracle.jsonl \
  --skip-readiness-warnings
```

## 5. Formal readiness audit

After `build_records.py`, run:

```bash
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/formal_readiness.py
```

Primary `.10` certification should not be interpreted as ready unless the report shows enough structurally confirmable, independent certify groups and the independent-oracle checks pass.

## 6. Independence rules

A formal group must not be:

- another repetition of the same target state;
- a controlled timestamp/artifact/provenance mutation;
- a renamed copy of the same benchmark;
- a sample whose oracle is produced by the same validator used as evidence;
- the same underlying scenario under a different `group_id` or `scenario_fingerprint`.

Prefer distinct pinned applications/CVE states/products or independently instantiated scenarios with independently verifiable truth.
