from __future__ import annotations
from typing import Any

from orchestrator.proof_obligations import obligations_for

CATEGORY_TO_VTYPE={'sqli':'sql_injection','idor':'idor','ssrf':'ssrf','auth_bypass':'auth_bypass','ssti':'ssti','xss':'xss'}


def _explicit_evidence_bound_obligations(category: str, evidences: list[dict], validator_result: dict | None) -> list[str]:
    """Return explicit obligation tokens only when bound to direct evidence IDs.

    External/public benchmark adapters may provide:

      validator_result["proof_obligation_evidence"] = {
          "control_request_compared": ["E-control", "E-payload"],
          ...
      }

    A token is accepted only if it is canonical for the vulnerability type and
    every referenced evidence ID is present in the *direct* evidence set used by
    the ProofBundle. This prevents a free-floating label/token from silently
    satisfying a proof obligation.
    """
    if not validator_result:
        return []
    vtype = CATEGORY_TO_VTYPE.get(category)
    if not vtype:
        return []
    required = set(obligations_for(vtype))
    direct_ids = {str(e.get('id')) for e in evidences if e.get('id') is not None}
    mapping = validator_result.get('proof_obligation_evidence') or {}
    if not isinstance(mapping, dict):
        return []
    out = []
    for token, refs in mapping.items():
        if token not in required or not isinstance(refs, list) or not refs:
            continue
        normalized = [str(x) for x in refs]
        if all(x in direct_ids for x in normalized):
            out.append(token)
    return out


def derive_obligations(category:str,evidences:list[dict], validator_result: dict | None = None)->list[str]:
    vals=[e.get('value',{}) for e in evidences]
    inferred=[]
    if category=='sqli' and any(v.get('boolean_signal_detected') for v in vals):
        inferred += ['control_request_compared','differential_response_or_error','target_endpoint_match','reproduction_request']
    if category=='idor':
        if any(v.get('baseline_status')==200 for v in vals): inferred.append('authorized_control_request')
        # Same-principal adjacent-ID probing cannot establish distinct identity/ownership.
    if category=='ssrf' and any(v.get('callback_received') for v in vals):
        inferred += ['server_side_outbound_interaction','callback_or_internal_response','not_client_side_request']
    if category=='auth_bypass':
        admins=[v for v in vals if v.get('kind')=='admin']
        if any(v.get('status_code')==200 and not v.get('redirected_to_login',False) for v in admins):
            inferred += ['protected_resource_access','no_valid_session_used']
        # The internal safe analyzer does not synthesize an authenticated control.

    explicit = _explicit_evidence_bound_obligations(category, evidences, validator_result)
    vtype = CATEGORY_TO_VTYPE.get(category)
    canonical = obligations_for(vtype) if vtype else []
    satisfied = set(inferred) | set(explicit)
    # Preserve canonical order for reproducibility.
    return [x for x in canonical if x in satisfied]


def direct_evidences(category:str,validator_result:dict,evidence_by_id:dict[str,dict])->list[dict]:
    out=[]
    for eid in validator_result.get('evidence_ids',[]):
        e=evidence_by_id.get(eid)
        if not e: continue
        if e.get('type') in {'context_claim','tool_error'}: continue
        out.append(e)
    return out
