#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PLAN="$HERE/external_group_plan_120.csv"
SRC="$HERE/external/sources"
CAT="$HERE/external/candidate_catalog.csv"
OUT="$HERE/external/populated_group_plan_120.csv"
REC="$HERE/external/acquisition_recipes.jsonl"
python "$HERE/fetch_public_sources.py" --dest "$SRC" "$@"
python "$HERE/discover_public_candidates.py" --sources-root "$SRC" --output "$CAT"
python "$HERE/populate_external_plan.py" --plan "$PLAN" --catalog "$CAT" --output-plan "$OUT" --recipes "$REC"
python "$HERE/acquisition_status.py" --plan "$OUT"
