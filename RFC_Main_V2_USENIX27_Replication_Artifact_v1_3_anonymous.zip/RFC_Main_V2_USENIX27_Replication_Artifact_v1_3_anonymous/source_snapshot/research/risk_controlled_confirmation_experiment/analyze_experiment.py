#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
from common import HERE, load_json


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--results-dir',default=str(HERE/'work/results')); a=ap.parse_args(); d=Path(a.results_dir)
    s=load_json(d/'summary.json'); f=load_json(d/'formal_certificates.json'); ins=load_json(d/'formal_input_summary.json')
    print('=== Main-v2 mechanism summary ===')
    for k,v in s.items():
        print(f"{k:28s} coverage={v['coverage']} FCR={v['fcr']} unsafe={v['unsafe_confirmations']} ideal_recall={v['ideal_confirm_recall']}")
    print('\n=== Formal independent-group calibration ===')
    print(f"eligible={ins['formal_eligible_groups']} tune={ins['tune_groups']} certify={ins['certify_groups']} test={ins['test_groups']}")
    for x in f:
        if x.get('threshold') is None:
            print(f"alpha={x['alpha']} status={x['status']} threshold=None")
        else:
            ce=x['certificate_exact']
            print(f"alpha={x['alpha']} threshold={x['threshold']} upper={ce['upper']:.4f} confirms={ce['confirmations']} status={x['status']}")

if __name__=='__main__': main()
