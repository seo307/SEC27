#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, json
from pathlib import Path

from common import HERE, read_jsonl, write_jsonl, dump_json, sha256_file, relative_to_dataset, resolve_dataset_path, iso_shift
from proof_adapter import CATEGORY_TO_VTYPE, derive_obligations, direct_evidences
from provenance import normalize_evidence, duplicate_correlated_evidence, add_soft_conflict
from risk_score import extract_features, score_naive_toolcount, score_provenance_aware
from orchestrator.finding_service import FindingConfirmationService, new_finding
from orchestrator.proof_bundle import ProofBundle
from orchestrator.proof_obligations import obligations_for
from orchestrator.schemas import ExecutionStatus


def _fraction(category, satisfied):
    req = obligations_for(CATEGORY_TO_VTYPE[category])
    return 1.0 if not req else len(set(req) & set(satisfied)) / len(req)


def _artifact_ok(record: dict, dataset_dir: Path) -> bool:
    try:
        p = resolve_dataset_path(record['artifact_ref'], dataset_dir)
        return p.exists() and sha256_file(p) == record['artifact_sha256']
    except Exception:
        return False


def _structural(record: dict, dataset_dir: Path) -> dict:
    vtype = CATEGORY_TO_VTYPE[record['category']]
    finding = new_finding(target_id=record['target_id'], title=record['title'], vulnerability_type=vtype)
    status = {e['id']: ExecutionStatus.SUCCEEDED for e in record['direct_evidences']}
    vr = record['validator_result']
    vr_ref = vr['validation_id']
    artifact_path = resolve_dataset_path(record['artifact_ref'], dataset_dir)
    service = FindingConfirmationService(
        evidence_status_of=lambda eid: status.get(eid),
        validator_status_of=lambda ref: vr.get('status') if ref == vr_ref else None,
        verify_artifacts=lambda refs: all(Path(r).exists() and sha256_file(Path(r)) == record['artifact_sha256'] for r in refs),
    )
    service.register(finding)
    f = record['features']
    bundle = ProofBundle(
        finding_id=finding.finding_id,
        target_id=record['target_id'],
        claim=record['title'],
        vulnerability_type=vtype,
        direct_evidence_refs=[e['id'] for e in record['direct_evidences']],
        validator_result_refs=[vr_ref],
        raw_artifact_refs=[str(artifact_path)],
        contradictions=list(record.get('contradictions') or []),
        proof_obligations=list(record.get('proof_obligations') or []),
        target_continuity_verified=bool(f['target_continuity_verified']),
        artifact_integrity_verified=bool(f['artifact_integrity']),
    )
    # Fair v2 baseline: the structural gate is run with intended target/deployment
    # continuity semantics enabled. The proposed risk layer must beat this baseline.
    res = service.confirm(finding.finding_id, bundle, require_target_continuity=True)
    return {'allowed': res.allowed, 'status': res.resulting_status.value, 'failures': res.failures}


def _finalize(record: dict, dataset_dir: Path) -> dict:
    record['artifact_integrity_observed'] = _artifact_ok(record, dataset_dir)
    record['features'] = extract_features(record)
    record['structural_gate'] = _structural(record, dataset_dir)
    record['risk_score'] = score_provenance_aware(record['features'])
    record['naive_risk_score'] = score_naive_toolcount(record['features'])
    return record


def _shift_evidence(record: dict, hours_back: float) -> None:
    for e in record['direct_evidences']:
        ts = e.get('captured_at') or e.get('timestamp')
        if ts:
            e['captured_at'] = iso_shift(record['decision_context']['decision_time'], hours=-hours_back)
            e['timestamp'] = e['captured_at']


def _variant(base: dict, suffix: str, mutation: str) -> dict:
    x = copy.deepcopy(base)
    x['record_id'] = f"{base['base_capture_id']}.{suffix}"
    x['mutation_log'] = list(base.get('mutation_log') or []) + [mutation]
    x['certificate_eligible'] = False  # challenge transformations never enter formal certificate
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--live-dir', default=str(HERE / 'work/live'))
    ap.add_argument('--output-dir', default=str(HERE / 'work/dataset'))
    args = ap.parse_args()
    live = Path(args.live_dir)
    out = Path(args.output_dir)
    art = out / 'artifacts'
    corrupt_dir = art / 'corrupt'
    art.mkdir(parents=True, exist_ok=True)
    corrupt_dir.mkdir(parents=True, exist_ok=True)

    caps = read_jsonl(live / 'captures_blinded.jsonl')
    live_or = {x['capture_id']: x for x in read_jsonl(live / 'oracle_live.jsonl')}
    records, oracle, meta, invalid = [], [], [], []

    for cap in caps:
        result = cap.get('result', {})
        rc = result.get('rfc_capture') or {}
        vals = rc.get('validation_records') or []
        if result.get('status') != 'ok' or not vals:
            invalid.append(cap['capture_id'])
            continue
        selected = next((v for v in vals if (v.get('candidate') or {}).get('category') == cap['category']), None)
        if not selected:
            invalid.append(cap['capture_id'])
            continue
        vr = selected['validator_result']
        evidence_by_id = {e['id']: e for e in rc.get('evidences', [])}
        direct = [normalize_evidence(e, deployment_id='deployment:T1:v1') for e in direct_evidences(cap['category'], vr, evidence_by_id)]
        snapshot = {
            'capture_id': cap['capture_id'], 'case_id': cap['case_id'],
            'validator_result': vr, 'direct_evidences': direct,
        }
        apath = art / f"{cap['capture_id']}.json"
        apath.write_text(json.dumps(snapshot, sort_keys=True, indent=2))
        obligations = derive_obligations(cap['category'], direct, vr)
        decision_time = vr.get('created_at') or max((e.get('captured_at') for e in direct if e.get('captured_at')), default='2026-01-01T00:00:00Z')
        gt = live_or[cap['capture_id']]
        group_id = gt.get('group_id') or cap.get('group_id') or cap['case_id']
        independence_eligible = bool(gt.get('independence_eligible', False))

        base = {
            'record_id': cap['capture_id'] + '.clean',
            'base_capture_id': cap['capture_id'],
            'case_id': cap['case_id'], 'category': cap['category'], 'pair_id': cap['pair_id'],
            'group_id': group_id,
            'source_class': gt.get('source_class', 'internal_controlled'),
            'independence_eligible': independence_eligible,
            'certificate_eligible': independence_eligible,
            'target_id': 'T1',
            'title': (selected.get('lifecycle_finding') or {}).get('title', 'finding'),
            'validator_result': vr,
            'direct_evidences': direct,
            'proof_obligations': obligations,
            'proof_obligation_fraction': _fraction(cap['category'], obligations),
            'contradictions': [],
            'decision_context': {
                'target_id': 'T1', 'deployment_id': 'deployment:T1:v1', 'decision_time': decision_time,
            },
            'state_context': {
                'observability': 'known', 'known_remediation': False,
                'events': [{'type': 'capture', 'at': decision_time, 'deployment_id': 'deployment:T1:v1'}],
            },
            'artifact_ref': relative_to_dataset(apath, out),
            'artifact_sha256': sha256_file(apath),
            'mutation_log': [],
        }
        base = _finalize(base, out)
        variants = [('clean', base, gt['vulnerable'], gt['ideal_decision'])]

        # Mechanism-level challenge states. These mutate evidence/state/artifacts,
        # never the derived feature vector directly. They are NOT independent samples.
        if gt['vulnerable']:
            fresh = _variant(base, 'age6', 'evidence aged 6h; deployment explicitly unchanged')
            _shift_evidence(fresh, 6.0)
            fresh['state_context']['events'].append({'type': 'no_change_attestation', 'at': fresh['decision_context']['decision_time']})
            fresh = _finalize(fresh, out)
            variants.append(('age_6h_unchanged', fresh, True, gt['ideal_decision']))

            unknown = _variant(base, 'age18_unknown', 'evidence aged 18h; current deployment state unobserved')
            _shift_evidence(unknown, 18.0)
            unknown['state_context']['observability'] = 'unknown'
            unknown['state_context']['events'].append({'type': 'monitoring_gap', 'at': unknown['decision_context']['decision_time']})
            unknown = _finalize(unknown, out)
            variants.append(('age_18h_unknown_state', unknown, gt['vulnerable'], 'abstain'))

            stale = _variant(base, 'remediated72', 'pre-remediation evidence replayed after known remediation at 72h')
            _shift_evidence(stale, 72.0)
            stale['state_context']['known_remediation'] = True
            stale['state_context']['events'].append({'type': 'remediation', 'at': stale['decision_context']['decision_time'], 'deployment_id': 'deployment:T1:v1'})
            stale = _finalize(stale, out)
            variants.append(('post_remediation_72h', stale, False, 'abstain'))

            cont = _variant(base, 'continuity', 'evidence rebound to a prior deployment identity')
            for e in cont['direct_evidences']:
                e['deployment_id'] = 'deployment:T1:prior'
            cont['state_context']['events'].append({'type': 'deployment_replaced', 'at': cont['decision_context']['decision_time'], 'from': 'deployment:T1:prior', 'to': 'deployment:T1:v1'})
            cont = _finalize(cont, out)
            variants.append(('continuity_break', cont, None, 'abstain'))

            soft = _variant(base, 'soft_conflict', 'independent contradictory observation added without hard refutation')
            soft['direct_evidences'] = add_soft_conflict(soft['direct_evidences'])
            soft = _finalize(soft, out)
            variants.append(('soft_conflict', soft, gt['vulnerable'], 'abstain'))

            hard = _variant(base, 'hard_conflict', 'formal unresolved contradiction attached to proof bundle')
            hard['contradictions'] = ['controlled_hard_conflict']
            hard = _finalize(hard, out)
            variants.append(('hard_conflict', hard, None, 'abstain'))

            corrupt = _variant(base, 'artifact', 'raw artifact bytes corrupted after expected hash was frozen')
            corrupt_path = corrupt_dir / f"{cap['capture_id']}.json"
            corrupt_path.write_text(apath.read_text() + '\n{"controlled_corruption":true}\n')
            corrupt['artifact_ref'] = relative_to_dataset(corrupt_path, out)
            # Keep the original expected hash; actual bytes now differ.
            corrupt = _finalize(corrupt, out)
            variants.append(('artifact_corruption', corrupt, None, 'abstain'))

        if base['direct_evidences']:
            corr = _variant(base, 'correlated', 'two derived observations per source share provenance roots')
            corr['direct_evidences'] = duplicate_correlated_evidence(corr['direct_evidences'], copies_per_source=2)
            corr = _finalize(corr, out)
            variants.append(('correlated_duplication', corr, gt['vulnerable'], gt['ideal_decision']))

        for condition, rec, vuln, ideal in variants:
            records.append(rec)
            oracle.append({
                'record_id': rec['record_id'], 'base_capture_id': cap['capture_id'],
                'case_id': cap['case_id'], 'category': cap['category'], 'pair_id': cap['pair_id'],
                'group_id': group_id, 'source_class': rec['source_class'],
                'independence_eligible': rec['independence_eligible'],
                'certificate_eligible': rec['certificate_eligible'],
                # Preserve preregistered external-study metadata through the
                # blinded-build stage. Challenge records remain certificate-ineligible.
                'split_role': gt.get('split_role'),
                'oracle_source': gt.get('oracle_source'),
                'oracle_independent_of_validator': gt.get('oracle_independent_of_validator'),
                'scenario_fingerprint': gt.get('scenario_fingerprint'),
                'environment_fingerprint': gt.get('environment_fingerprint'),
                'finding_fingerprint': gt.get('finding_fingerprint'),
                'independence_basis': gt.get('independence_basis'),
                'software_product': gt.get('software_product'),
                'software_version': gt.get('software_version'),
                'target_state_id': gt.get('target_state_id'),
                'vulnerable': vuln, 'ideal_decision': ideal,
            })
            meta.append({'record_id': rec['record_id'], 'condition': condition, 'mutation_log': rec['mutation_log']})

    write_jsonl(out / 'records_blinded.jsonl', records)
    write_jsonl(out / 'oracle.jsonl', oracle)
    write_jsonl(out / 'analysis_metadata.jsonl', meta)
    dump_json(out / 'build_summary.json', {
        'base_captures': len(caps), 'records': len(records), 'invalid_captures': invalid,
        'oracle_separated': True,
        'formal_independent_groups': len({o['group_id'] for o in oracle if o['certificate_eligible']}),
        'note': 'challenge transformations are excluded from formal certification',
    })
    print(json.dumps({'records': len(records), 'invalid_captures': len(invalid)}, indent=2))

if __name__ == '__main__':
    main()
