# Main-v2 Runbook

## 1. Install experiment dependencies

```bash
python -m pip install -r research/risk_controlled_confirmation_experiment/requirements-experiment.txt
```

## 2. Strict preflight

```bash
PYTHONPATH=. python \
  research/risk_controlled_confirmation_experiment/preflight.py \
  --require-live-deps
```

Do not run the experiment if strict preflight fails.

## 3. Internal mechanism run

```bash
RFC_REPETITIONS=5 \
  research/risk_controlled_confirmation_experiment/run_all.sh
```

The internal benchmark is intentionally ineligible for formal risk certification. Its purpose is mechanism validation and challenge analysis.

## 4. Inspect mandatory audit outputs

```text
work/dataset/AUDIT_REPORT_V2.json
work/results/RESULT_AUDIT_V2.json
```

Both must be `PASS` before interpreting results.

## 5. Add independent external/public scenario groups

Generate RFC-format blinded captures and a separate oracle file, then merge them:

```bash
PYTHONPATH=. python \
  research/risk_controlled_confirmation_experiment/import_external_captures.py \
  --captures /path/to/external_captures_blinded.jsonl \
  --oracle /path/to/external_oracle.jsonl
```

An independence-eligible external group must be genuinely distinct; repeated runs, renamed copies, or controlled derivatives of an existing group must not be marked independent.

After importing, rerun from the record-building stage:

```bash
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/build_records.py
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/audit_experiment.py
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/run_experiment.py
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/audit_results.py
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/analyze_experiment.py
```

## 6. Formal interpretation

For α=.10, `formal_certificates.json` must report `CERTIFIED` before any finite-sample false-confirmation risk claim is made.

`INSUFFICIENT_INDEPENDENT_CONFIRMATIONS`, `NOT_CERTIFIED`, and `NOT_RUN_NO_CALIBRATED_THRESHOLD` are valid scientific outcomes and must not be rewritten as success.

## 7. Files to archive for replication

Archive at minimum:

```text
work/live/captures_blinded.jsonl
work/live/oracle_live.jsonl
work/live/environment.json
work/dataset/records_blinded.jsonl
work/dataset/oracle.jsonl
work/dataset/analysis_metadata.jsonl
work/dataset/AUDIT_REPORT_V2.json
work/results/input_fingerprint.json
work/results/frozen_experiment.json
work/results/summary.json
work/results/risk_coverage_curve.json
work/results/formal_split_assignments.jsonl
work/results/calibration_trace.json
work/results/formal_certificates.json
work/results/formal_input_summary.json
work/results/predictions.jsonl
work/results/RESULT_AUDIT_V2.json
```
