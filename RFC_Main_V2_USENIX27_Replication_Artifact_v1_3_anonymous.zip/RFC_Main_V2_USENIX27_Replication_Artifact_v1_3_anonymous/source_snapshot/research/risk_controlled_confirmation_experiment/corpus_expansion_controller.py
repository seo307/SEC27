#!/usr/bin/env python3
"""V5.2 integrated external-corpus expansion controller.

This controller does not create scientific acceptance and never mutates the
scientifically accepted environment registry.  It coordinates four read-only
or execution-planning tasks around the existing capture pipeline:

1. inventory/rank all preregistered screened environments;
2. exclude already accepted fingerprints and history-derived terminal blockers;
3. generate a review queue after acquisition without auto-admitting any row;
4. report cumulative formal progress using only explicitly accepted registry
   fingerprints joined to immutable run/oracle records.

The controller is intentionally conservative.  A review recommendation is not a
formal scientific decision.  Registry admission remains an explicit operator
step after scientific review.
"""
from __future__ import annotations
import argparse, collections, json, math
from pathlib import Path

HERE=Path(__file__).resolve().parent

TERMINAL_CAPTURE_STATES={
    'APPLICATION_PRECONDITION_FAILED':'APPLICATION_FIXTURE_REQUIRED',
    'AUTH_PRECONDITION_FAILED':'AUTH_FIXTURE_REQUIRED',
    'PROTOCOL_MISMATCH':'PROTOCOL_ADAPTER_REQUIRED',
}


def read_json(path:Path,default=None):
    try:return json.loads(path.read_text())
    except Exception:return {} if default is None else default


def read_jsonl(path:Path):
    if not path.exists():return []
    out=[]
    for line in path.read_text().splitlines():
        if not line.strip():continue
        try:out.append(json.loads(line))
        except Exception:continue
    return out


def write_json(path:Path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")


def write_jsonl(path:Path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))


def registry_entries(path:Path):
    obj=read_json(path,{'entries':{}})
    entries=obj.get('entries') or {}
    return entries if isinstance(entries,dict) else {}


def known_blocker_entries(path:Path|None):
    if not path or not path.exists():return {}
    obj=read_json(path,{'entries':{}});entries=obj.get('entries') or {}
    return entries if isinstance(entries,dict) else {}


def _observations_from_raw(path:Path):
    o=read_json(path,{})
    return o.get('observations') or []


def scan_history(runs_root:Path):
    hist=collections.defaultdict(lambda:{'runs':[],'capture_validity':collections.Counter(),'validator_status':collections.Counter(),'nondifferential_5xx':0})
    if not runs_root.exists():return {}
    for rd in sorted((p for p in runs_root.iterdir() if p.is_dir()),key=lambda p:p.name):
        summ=read_json(rd/'acquired_raw'/'acquisition_summary.json',{})
        for row in summ.get('rows') or []:
            gid=row.get('group_id')
            if not gid:continue
            h=hist[gid];cv=row.get('capture_validity');vs=row.get('validator_status')
            h['runs'].append({'run_id':summ.get('run_id') or rd.name,'capture_validity':cv,'status':row.get('status'),'validator_status':vs})
            if cv:h['capture_validity'][cv]+=1
            if vs:h['validator_status'][vs]+=1
            raw=rd/'acquired_raw'/f'{gid}.json'
            obs=_observations_from_raw(raw)
            good=[x for x in obs if not x.get('request_error')]
            if len(good)>=2:
                codes=[x.get('status_code') for x in good]
                bodies=[x.get('body_sha256') for x in good]
                if all(isinstance(c,int) and c>=500 for c in codes) and len(set(codes))==1 and len(set(bodies))==1:
                    h['nondifferential_5xx']+=1
    out={}
    for gid,h in hist.items():
        blocker=None
        for state,reason in TERMINAL_CAPTURE_STATES.items():
            if h['capture_validity'].get(state):
                blocker=reason;break
        if blocker is None and h['nondifferential_5xx']:
            blocker='NONDIFFERENTIAL_SERVER_ERROR'
        if blocker is None and h['capture_validity'].get('TARGET_NOT_READY',0)>=2:
            blocker='REPEATED_TARGET_READINESS_FAILURE'
        out[gid]={
            'runs':h['runs'],
            'capture_validity':dict(h['capture_validity']),
            'validator_status':dict(h['validator_status']),
            'nondifferential_5xx':h['nondifferential_5xx'],
            'default_blocker':blocker,
        }
    return out


def screen_blocker(row):
    if row.get('preexecution_automatable'):return None
    reason=(row.get('screen_reason') or '').lower()
    cat=row.get('category')
    if cat=='xss':return 'BROWSER_EXECUTION_REQUIRED'
    if row.get('proof_only_rejected_request_count',0)>0 and row.get('proof_only_safe_request_count',0)==0:
        return 'UNSAFE_PROOF_REJECTED'
    if 'same-endpoint control' in reason or 'without authenticated control' in reason:
        return 'CONTROL_PAIR_MISSING'
    if 'dual-identity' in reason:
        return 'DUAL_IDENTITY_CONTROL_MISSING'
    if row.get('parsed_request_count',0)==0:
        return 'NO_CONSERVATIVE_HTTP_RECIPE'
    if 'no conservative documented http reproduction recipe' in reason:
        return 'PARSER_OR_ADAPTER_GAP'
    if 'browser' in reason:return 'BROWSER_EXECUTION_REQUIRED'
    if row.get('documentation_grade')=='partial':return 'PARTIAL_EVIDENCE_ONLY'
    return 'UNSUPPORTED_SAFE_AUTOMATION'


def _priority(row,accepted_category_counts):
    role=row.get('split_role');scenario=row.get('scenario_kind');cat=row.get('category')
    score={'certify':1000,'test':500,'tune':100}.get(role,0)
    score += {'positive_confirmable':250,'ambiguous_positive':80,'negative_lookalike':0}.get(scenario,0)
    score -= 12*accepted_category_counts.get(cat,0)
    # Prefer category diversity when otherwise tied.
    score += {'idor':35,'xss':30,'ssti':25,'ssrf':20,'auth_bypass':15,'sqli':10}.get(cat,0)
    return score


def cmd_plan(a):
    rows=read_jsonl(Path(a.screened));reg=registry_entries(Path(a.registry));known=set(reg)
    hist=scan_history(Path(a.runs_root));seed=known_blocker_entries(Path(a.known_blockers) if a.known_blockers else None)
    accepted_cats=collections.Counter((e or {}).get('category') for e in reg.values())
    inventory=[];ready=[];blocked=[]
    for r in rows:
        fp=r.get('environment_fingerprint');gid=r.get('group_id')
        state='BLOCKED';blocker=None
        if fp and fp in known:
            state='REGISTERED';blocker='SCIENTIFICALLY_ACCEPTED_ALREADY_REGISTERED'
        elif r.get('split_role')!='certify' and not a.include_noncertify:
            state='OUT_OF_PRIMARY_SCOPE';blocker='NON_CERTIFY_SPLIT'
        elif r.get('scenario_kind')!='positive_confirmable' and not a.include_ambiguous:
            state='OUT_OF_PRIMARY_SCOPE';blocker='NON_PRIMARY_SCENARIO'
        else:
            sb=screen_blocker(r)
            hb=(hist.get(gid) or {}).get('default_blocker')
            kb=(seed.get(gid) or {}).get('reason')
            if sb:blocker=sb
            elif kb and not a.retry_blockers:blocker='KNOWN_'+kb
            elif hb and not a.retry_blockers:blocker='HISTORY_'+hb
            else:state='READY'
        item={
            'group_id':gid,'category':r.get('category'),'split_role':r.get('split_role'),'scenario_kind':r.get('scenario_kind'),
            'environment_fingerprint':fp,'source_name':r.get('source_name'),'source_relative_path':r.get('source_relative_path'),
            'preexecution_automatable':bool(r.get('preexecution_automatable')),'documentation_grade':r.get('documentation_grade'),
            'screen_reason':r.get('screen_reason'),'controller_state':state,'blocker':blocker,
            'known_blocker':seed.get(gid) or None,'history':hist.get(gid) or None,'priority':_priority(r,accepted_cats),
        }
        inventory.append(item)
        if state=='READY':ready.append(item)
        elif state=='BLOCKED':blocked.append(item)
    ready.sort(key=lambda x:(-x['priority'],x.get('category') or '',x.get('group_id') or ''))
    if a.max_batch and a.max_batch>0:ready=ready[:a.max_batch]
    ready_ids=[x['group_id'] for x in ready]
    counts=collections.Counter(x.get('blocker') for x in blocked)
    cert_positive=[x for x in inventory if x.get('split_role')=='certify' and x.get('scenario_kind')=='positive_confirmable' and x.get('controller_state')!='REGISTERED']
    exhaustion='EXPANSION_READY' if ready else ('CURRENT_CORPUS_EXHAUSTED_UNDER_SAFE_AUTOMATION' if cert_positive else 'NO_UNREGISTERED_PRIMARY_CERTIFY_ROWS')
    rep={
        'status':'PASS','controller_version':'5.2','input_rows':len(rows),'registry_known_environments':len(known),
        'ready_count':len(ready),'ready_groups':ready_ids,'blocked_count':len(blocked),'blocker_counts':dict(sorted(counts.items())),
        'out_of_primary_scope_count':sum(x['controller_state']=='OUT_OF_PRIMARY_SCOPE' for x in inventory),
        'registered_count':sum(x['controller_state']=='REGISTERED' for x in inventory),'exhaustion_status':exhaustion,
        'retry_blockers':bool(a.retry_blockers),'include_noncertify':bool(a.include_noncertify),'include_ambiguous':bool(a.include_ambiguous),
        'known_blocker_seed_count':len(seed),'scientific_acceptance_automatic':False,
    }
    write_json(Path(a.output),rep)
    if a.inventory:write_jsonl(Path(a.inventory),inventory)
    if a.blocked:write_jsonl(Path(a.blocked),blocked)
    if a.ready_groups:
        Path(a.ready_groups).parent.mkdir(parents=True,exist_ok=True);Path(a.ready_groups).write_text('\n'.join(ready_ids)+('\n' if ready_ids else ''))
    print(json.dumps(rep,indent=2));return 0


def _capture_index(run_dir:Path):
    return {r.get('group_id'):r for r in read_jsonl(run_dir/'captures_blinded.jsonl') if r.get('group_id')}


def _oracle_index(run_dir:Path):
    return {r.get('group_id'):r for r in read_jsonl(run_dir/'oracle.jsonl') if r.get('group_id')}


def _validator_info(capture):
    try:
        vals=capture['result']['rfc_capture'].get('validator_results') or []
        return vals[0] if vals else {}
    except Exception:return {}


def _evidence_values(capture):
    try:return [(e.get('value') or {}) for e in capture['result']['rfc_capture'].get('evidences') or []]
    except Exception:return []


def _serious_review_flags(category,vals,validator):
    flags=[]
    obs=[v for v in vals if v.get('kind') not in {'server_side_callback'} and v.get('status_code') is not None]
    if any(v.get('application_precondition_marker') for v in obs):flags.append('application_precondition_marker')
    if len(obs)>=2:
        codes=[v.get('status_code') for v in obs];bodies=[v.get('body_sha256') for v in obs]
        if all(isinstance(c,int) and c>=500 for c in codes) and len(set(codes))==1 and len(set(bodies))==1:
            flags.append('nondifferential_same_5xx_response')
    if category=='auth_bypass':
        controls=[v for v in obs if v.get('auth_probe_role')=='control']
        if any((v.get('status_code') or 0)>=500 for v in controls):flags.append('auth_control_5xx_requires_diagnostics')
    if validator.get('limitations'):flags.append('validator_limitations_present')
    return flags


def cmd_review(a):
    rd=Path(a.run_dir);ledger=read_json(rd/'acquisition_ledger.json',{'rows':[]});caps=_capture_index(rd);ora=_oracle_index(rd)
    queue=[];registry_candidates=[]
    serious={'application_precondition_marker','nondifferential_same_5xx_response'}
    for l in ledger.get('rows') or []:
        gid=l.get('group_id');o=ora.get(gid,{ });c=caps.get(gid,{});v=_validator_info(c);vals=_evidence_values(c)
        method='confirm' if v.get('status')=='confirmed' else 'abstain'
        ideal=o.get('ideal_decision')
        flags=_serious_review_flags(o.get('category') or c.get('category'),vals,v)
        base_ok=(l.get('status')=='EXPORTED' and l.get('capture_validity')=='CAPTURE_OK_EVIDENTIARY' and o.get('independence_eligible') is True and o.get('oracle_independent_of_validator') is True)
        candidate=bool(base_ok and not serious.intersection(flags))
        formal_confirmation=bool(candidate and o.get('split_role')=='certify' and ideal=='confirm' and method=='confirm')
        risk_event=bool(candidate and method=='confirm' and ideal!='confirm')
        row={
            'group_id':gid,'environment_fingerprint':o.get('environment_fingerprint') or l.get('environment_fingerprint'),'category':o.get('category') or c.get('category'),
            'split_role':o.get('split_role'),'scenario_kind':l.get('scenario_kind'),'capture_validity':l.get('capture_validity'),'ledger_status':l.get('status'),
            'oracle_ideal_decision':ideal,'oracle_vulnerable':o.get('vulnerable'),'oracle_independence_eligible':o.get('independence_eligible'),
            'validator_status':v.get('status') or l.get('validator_status'),'validator_confidence':v.get('confidence'),'method_decision':method,
            'decision_match':(ideal==method) if ideal else None,'proof_obligation_evidence':v.get('proof_obligation_evidence') or {},'limitations':v.get('limitations') or [],
            'review_flags':flags,'registry_review_candidate':candidate,'formal_confirmation_candidate':formal_confirmation,'risk_event_candidate':risk_event,
            'suggested_action':('REVIEW_FOR_ACCEPTANCE' if candidate else ('EXCLUDE_PRECONDITION_OR_INVALID' if not base_ok else 'MANUAL_DIAGNOSTIC_REVIEW')),
            'scientific_acceptance_automatic':False,
        }
        queue.append(row)
        if candidate:registry_candidates.append(row)
    rep={'status':'PASS','run_id':ledger.get('run_id') or rd.name,'rows':len(queue),'registry_review_candidates':sum(x['registry_review_candidate'] for x in queue),'formal_confirmation_candidates':sum(x['formal_confirmation_candidate'] for x in queue),'risk_event_candidates':sum(x['risk_event_candidate'] for x in queue),'scientific_acceptance_automatic':False}
    write_jsonl(Path(a.output),queue)
    if a.registry_candidates:write_jsonl(Path(a.registry_candidates),registry_candidates)
    if a.summary:write_json(Path(a.summary),rep)
    print(json.dumps(rep,indent=2));return 0


def _all_run_evidence(runs_root:Path):
    by_fp=collections.defaultdict(list)
    if not runs_root.exists():return by_fp
    for rd in sorted((p for p in runs_root.iterdir() if p.is_dir()),key=lambda p:p.name):
        oracle=_oracle_index(rd);ledger=read_json(rd/'acquisition_ledger.json',{'rows':[]})
        for l in ledger.get('rows') or []:
            gid=l.get('group_id');o=oracle.get(gid) or {};fp=o.get('environment_fingerprint') or l.get('environment_fingerprint')
            if fp:
                by_fp[fp].append({'run_id':ledger.get('run_id') or rd.name,'ledger':l,'oracle':o})
    return by_fp


def cp_upper_zero_or_exact(k:int,n:int,delta:float):
    if n<=0:return 1.0
    if k>=n:return 1.0
    if k==0:return 1.0-delta**(1.0/n)
    try:
        from risk_statistics import cp_upper
        return float(cp_upper(k,n,delta))
    except Exception:
        # Exact non-zero CP requires a beta quantile.  Do not silently claim an
        # exact certificate if scipy/current project implementation is absent.
        return None


def cmd_progress(a):
    reg=registry_entries(Path(a.registry));runs=_all_run_evidence(Path(a.runs_root));cfg=read_json(Path(a.config),{})
    resolved=[];missing=[]
    for fp,e in reg.items():
        candidates=runs.get(fp) or []
        chosen=None
        target=e.get('first_accepted_run_id')
        if target:chosen=next((x for x in candidates if x['run_id']==target),None)
        if chosen is None:
            chosen=next((x for x in candidates if (x['ledger'].get('status')=='EXPORTED')),None)
        if chosen is None:
            missing.append({'environment_fingerprint':fp,'group_id':e.get('group_id'),'reason':'accepted registry entry not resolved to exported run/oracle metadata'})
            continue
        o=chosen['oracle'];l=chosen['ledger'];method='confirm' if l.get('validator_status')=='confirmed' else 'abstain'
        resolved.append({**e,'run_id':chosen['run_id'],'ideal_decision':o.get('ideal_decision'),'vulnerable':o.get('vulnerable'),'method_decision':method,'validator_status':l.get('validator_status')})
    cert=[x for x in resolved if x.get('split_role')=='certify']
    confirmations=[x for x in cert if x.get('method_decision')=='confirm']
    errors=[x for x in confirmations if x.get('ideal_decision')!='confirm']
    n=len(confirmations);k=len(errors);delta=float(cfg.get('confidence_delta',0.05));threshold=float(cfg.get('primary_alpha',0.1))
    upper=cp_upper_zero_or_exact(k,n,delta)
    req=int((cfg.get('formal_min_confirmations') or {}).get(str(cfg.get('primary_alpha')), (cfg.get('formal_min_confirmations') or {}).get(f'{threshold:g}',0)) or 0)
    certificate=bool(not missing and n>=req and upper is not None and upper<=threshold)
    cat=collections.Counter(x.get('category') for x in resolved);role=collections.Counter(x.get('split_role') for x in resolved)
    rep={
        'status':'PASS','controller_version':'5.2','accepted_unique_environments':len(reg),'resolved_accepted_metadata':len(resolved),'missing_accepted_metadata':missing,
        'accepted_by_category':dict(sorted(cat.items())),'accepted_by_split_role':dict(sorted(role.items())),
        'certify_environments':len(cert),'certification_confirmations':n,'false_confirmations':k,'empirical_fcr':(k/n if n else None),
        'configured_primary_alpha':threshold,'confidence_delta':delta,'one_sided_cp_upper':upper,'configured_min_confirmations':req,
        'formal_certificate_ready':certificate,'certificate_rule_note':'registry acceptance is explicit; repeated runs do not create new environment N',
    }
    write_json(Path(a.output),rep);print(json.dumps(rep,indent=2));return 0


def cmd_render(a):
    plan=read_json(Path(a.plan),{});review=read_json(Path(a.review_summary),{});prog=read_json(Path(a.progress),{})
    lines=[
        '# RFC/Main-V2 V5.2 Corpus Expansion Summary','',
        f"- Controller status: `{plan.get('status','UNKNOWN')}`",
        f"- Registry known before run: **{plan.get('registry_known_environments','?')}**",
        f"- Ready groups scheduled/planned: **{plan.get('ready_count','?')}**",
        f"- Blocked groups: **{plan.get('blocked_count','?')}**",
        f"- Exhaustion status: `{plan.get('exhaustion_status','?')}`",'',
        '## Post-run review queue','',
        f"- Review rows: **{review.get('rows',0)}**",
        f"- Registry review candidates: **{review.get('registry_review_candidates',0)}**",
        f"- Formal confirmation candidates: **{review.get('formal_confirmation_candidates',0)}**",
        f"- Potential risk events: **{review.get('risk_event_candidates',0)}**",
        '- Registry admission remains manual after scientific review.','',
        '## Cumulative formal progress','',
        f"- Accepted unique environments: **{prog.get('accepted_unique_environments','?')}**",
        f"- Certification confirmations: **{prog.get('certification_confirmations','?')}**",
        f"- False confirmations: **{prog.get('false_confirmations','?')}**",
        f"- One-sided CP upper bound: **{prog.get('one_sided_cp_upper','?')}**",
        f"- Configured risk threshold: **{prog.get('configured_primary_alpha','?')}**",
        f"- Formal certificate ready: **{prog.get('formal_certificate_ready',False)}**",'',
        '## Blockers','',
    ]
    for k,v in sorted((plan.get('blocker_counts') or {}).items()):lines.append(f'- `{k}`: {v}')
    Path(a.output).write_text('\n'.join(lines)+'\n');return 0


def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('plan');p.add_argument('--screened',required=True);p.add_argument('--registry',required=True);p.add_argument('--runs-root',required=True);p.add_argument('--known-blockers',default=str(HERE/'config/controller_known_blockers_v52.json'));p.add_argument('--output',required=True);p.add_argument('--inventory');p.add_argument('--blocked');p.add_argument('--ready-groups');p.add_argument('--max-batch',type=int,default=0);p.add_argument('--retry-blockers',action='store_true');p.add_argument('--include-noncertify',action='store_true');p.add_argument('--include-ambiguous',action='store_true');p.set_defaults(func=cmd_plan)
    p=sub.add_parser('review');p.add_argument('--run-dir',required=True);p.add_argument('--output',required=True);p.add_argument('--registry-candidates');p.add_argument('--summary');p.set_defaults(func=cmd_review)
    p=sub.add_parser('progress');p.add_argument('--registry',required=True);p.add_argument('--runs-root',required=True);p.add_argument('--config',default=str(HERE/'config/experiment.json'));p.add_argument('--output',required=True);p.set_defaults(func=cmd_progress)
    p=sub.add_parser('render');p.add_argument('--plan',required=True);p.add_argument('--review-summary',required=True);p.add_argument('--progress',required=True);p.add_argument('--output',required=True);p.set_defaults(func=cmd_render)
    a=ap.parse_args();raise SystemExit(a.func(a))

if __name__=='__main__':main()
