#!/usr/bin/env python3
"""Export blinded external capture/oracle JSONL from one immutable acquisition run.

V5.1 binds export to acquisition_summary.run_id and refuses stale raw files from
other runs.  Only evidentiary-valid captures are exported.
"""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path

def b(v):return str(v).strip().lower() in {'1','true','yes','y'}
VALID_EVIDENCE={'CAPTURE_OK_EVIDENTIARY','CAPTURE_PARTIAL_EVIDENTIARY'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',required=True);ap.add_argument('--screened-jobs',required=True);ap.add_argument('--raw-dir',required=True);ap.add_argument('--run-summary',required=True);ap.add_argument('--captures',required=True);ap.add_argument('--oracle',required=True);ap.add_argument('--ledger',required=True);a=ap.parse_args()
    with open(a.plan,newline='') as f:plan={r['group_id']:r for r in csv.DictReader(f)}
    screened={x['group_id']:x for x in (json.loads(l) for l in Path(a.screened_jobs).read_text().splitlines() if l.strip())}
    summary=json.loads(Path(a.run_summary).read_text());run_id=summary.get('run_id')
    if not run_id:raise SystemExit('run summary lacks run_id')
    scheduled={r['group_id'] for r in summary.get('rows',[])}
    caps=[];oracle=[];ledger=[]
    for gid in sorted(scheduled):
        j=screened.get(gid);row=plan.get(gid)
        if not j or not row:
            ledger.append({'run_id':run_id,'group_id':gid,'status':'MISSING_PLAN_OR_SCREEN'});continue
        p=Path(a.raw_dir)/f'{gid}.json'
        if not p.exists():ledger.append({'run_id':run_id,'group_id':gid,'status':'MISSING_CAPTURE'});continue
        raw=json.loads(p.read_text())
        if raw.get('run_id')!=run_id:
            ledger.append({'run_id':run_id,'group_id':gid,'status':'STALE_RUN_REJECTED','raw_run_id':raw.get('run_id')});continue
        if raw.get('status')!='OK' or raw.get('capture_validity') not in VALID_EVIDENCE:
            ledger.append({'run_id':run_id,'group_id':gid,'status':'INVALID_OR_EXECUTION_FAILURE','runtime_status':raw.get('status'),'capture_validity':raw.get('capture_validity'),'failure_class':raw.get('failure_class'),'reason':raw.get('error') or raw.get('capture_validity_reason')});continue
        result=raw.get('result') or {}
        if result.get('status')!='ok':
            ledger.append({'run_id':run_id,'group_id':gid,'status':'INVALID_RESULT_ENVELOPE'});continue
        capture={'capture_id':gid,'case_id':row['case_id'],'category':row['category'],'pair_id':row['pair_id'],'group_id':gid,'source_class':row['source_class'],'run_id':run_id,'result':result}
        caps.append(capture)
        oracle.append({'capture_id':gid,'case_id':row['case_id'],'category':row['category'],'pair_id':row['pair_id'],'group_id':gid,'source_class':row['source_class'],'independence_eligible':True,'split_role':row['split_role'],'oracle_source':row['oracle_source'],'oracle_independent_of_validator':b(row['oracle_independent_of_validator']),'scenario_fingerprint':row['scenario_fingerprint'],'environment_fingerprint':row.get('environment_fingerprint') or row['scenario_fingerprint'],'finding_fingerprint':row.get('finding_fingerprint') or row['scenario_fingerprint'],'independence_basis':row['independence_basis'],'software_product':row['software_product'],'software_version':row['software_version'],'target_state_id':row['target_state_id'],'vulnerable':b(row['planned_vulnerable']),'ideal_decision':row['planned_ideal_decision']})
        vr=result['rfc_capture']['validation_records'][0]['validator_result'];ledger.append({'run_id':run_id,'group_id':gid,'status':'EXPORTED','validator_status':vr.get('status'),'scenario_kind':row['scenario_kind'],'capture_validity':raw.get('capture_validity'),'preexecution_grade':j.get('documentation_grade'),'environment_fingerprint':row.get('environment_fingerprint')})
    for path,rows in [(Path(a.captures),caps),(Path(a.oracle),oracle)]:
        path.parent.mkdir(parents=True,exist_ok=True);path.write_text('\n'.join(json.dumps(x,sort_keys=True) for x in rows)+('\n' if rows else ''))
    Path(a.ledger).write_text(json.dumps({'run_id':run_id,'rows':ledger},indent=2,sort_keys=True))
    counts={}
    for x in ledger:counts[x['status']]=counts.get(x['status'],0)+1
    print(json.dumps({'status':'PASS','run_id':run_id,'captures':len(caps),'oracle_rows':len(oracle),'ledger_status':counts},indent=2))
if __name__=='__main__':main()
