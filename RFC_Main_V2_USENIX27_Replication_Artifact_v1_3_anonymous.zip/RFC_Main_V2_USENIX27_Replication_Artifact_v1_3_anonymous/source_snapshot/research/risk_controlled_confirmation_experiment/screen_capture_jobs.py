#!/usr/bin/env python3
"""Pre-execution documentation screen for public benchmark capture jobs.

V5.2 keeps prior safety/provenance controls, adds one generic source-grounded
XML/body URL SSRF callback adapter, and is designed to feed the integrated corpus
expansion controller. V5.1.5 auth-bypass adapters remain unchanged. The filter recognizes conservative error-based SQLi probes,
can derive a provenance-recorded benign same-endpoint SQLi control for narrow
form/query cases, and marks explicitly documented SSRF Host/URL alignment
requirements for runtime callback substitution.
"""
from __future__ import annotations
import argparse,json,re,shlex,hashlib,urllib.parse,posixpath
from pathlib import Path

SQL_PAYLOAD=re.compile(r"(?:\bunion\b|\bselect\b|\bor\s+['\"0-9]|sleep\s*\(|benchmark\s*\(|updatexml\s*\(|extractvalue\s*\(|%27|')",re.I)
SQL_ERROR_PAYLOAD=re.compile(r"(?:updatexml|extractvalue)\s*\(",re.I)
SSRF_STRONG_EXPECTATION=re.compile(r"(?:instance-id|ami-id|metadata|callback|internal response|server[- ]side|server\s+(?:will\s+)?send\s+(?:a\s+)?requests?|response\s+from\s+[^\n]{1,120}\s+(?:is\s+)?returned|request unexpected url|ssrf)",re.I)
SSRF_HOST_ALIGNMENT_REQUIREMENT=re.compile(r"host\s+in\s+the\s+[`'\"]?url[`'\"]?\s+parameter.{0,180}?must\s+match.{0,80}?[`'\"]?host[`'\"]?\s+header",re.I|re.S)

SSRF_ARBITRARY_URL_SOURCE=re.compile(r"(?:arbitrary\s+urls?|send\s+requests?\s+to\s+arbitrary\s+urls?|making\s+the\s+server\s+send\s+requests?\s+to\s+arbitrary\s+urls?)",re.I)
SSRF_BODY_URL_ATTR=re.compile(r"(?P<prefix>\bhref\s*=\s*[\"'])(?P<url>(?:file|https?)://[^\"']+)(?P<suffix>[\"'])",re.I)
SAFE_SSRF_BODY_URL_TRANSFORMATION='controlled_local_ssrf_body_url_callback_substitution'
SSRF_PAYLOAD=re.compile(r"(?:url|uri|target|host|callback|fetch|proxy|operator).{0,180}(?:https?%3a|https?://|file://|gopher://)",re.I)
SSTI_PAYLOAD=re.compile(r"(?:\{\{.*?\}\}|\$\{.*?\}|<%=.*?%>|_template|velocity|smarty)",re.I)
XSS_PAYLOAD=re.compile(r"(?:<script|onerror\s*=|onload\s*=|javascript:)",re.I)
AUTH_PATH=re.compile(r"/(?:admin|manage|management|dashboard|private|protected|internal|apisix/admin)\b",re.I)
IDOR_PATH=re.compile(r"/(?:users?|accounts?|objects?|orders?|profiles?|documents?|api)/[^\s?]+",re.I)
HEADING=re.compile(r'^(#{1,6})\s+(.+?)\s*$',re.M)
REPRO_SECTION=re.compile(r'(exploit|vulnerab(?:ility|le).*(?:repro|reproduction|verification)|reproduc|proof.of.concept|\bpoc\b|attack)',re.I)
EXCLUDED_SECTION=re.compile(r'^(references?|related|links?|credit|acknowledg|mitigation|patch)',re.I)
RAW_HTTP_FENCE=re.compile(r"```(?:http|HTTP)?\s*\n(?P<body>(?:GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)\s+[^\n]+(?:HTTP/\d(?:\.\d)?)?\s*\n.*?)(?:\n```|\Z)",re.S)
URL_RE=re.compile(r'https?://(?:your-ip|your_ip|localhost|127\.0\.0\.1|0\.0\.0\.0)(?::\d+)?/[^\s`<>"}]*',re.I)

# Conservative deny-list for automated proof acquisition.  These expressions do
# not make a claim that the source benchmark is unsafe; they only say that the
# documented request is broader than the evidence-only experiment needs.
STATE_MUTATION=re.compile(
    r"(?:\battach\s+database\b|\bcreate\s+(?:table|user|database)\b|\bdrop\s+(?:table|database|user)\b|"
    r"\balter\s+table\b|\btruncate\b|\binsert\s+into\b|\bdelete\s+from\b|\bupdate\s+\w+\s+set\b|"
    r"\binto\s+outfile\b|\bconfig\s+set\b|\bdbfilename\b|\bcrontab\b|/etc/(?:cron|passwd|shadow)|"
    r"/dev/tcp|\bbash\s+-c\b|\bsh\s+-i\b|\bpowershell\b|\bcmd\.exe\b|\bnc\s+-e\b|"
    r"runtime\.getruntime|processbuilder|os\.popen|(?:\.|\b)popen\s*\(|os\.system|(?:\.|\b)system\s*\(|"
    r"subprocess\.|__import__\s*\(|(?:\b|[.])eval\s*\(|file_put_contents|writefile\s*\(|"
    r"freemarker\.template\.utility\.execute|\?new\(\).*?(?:id|whoami|uname|cat|sh|bash)|"
    r"\bchmod\b|\bchown\b|\bgopher://)", re.I)
MUTATING_PATH=re.compile(r"/(?:delete|remove|destroy|upload|install|execute|exec|shell)(?:/|\?|$)",re.I)

def _read(p:Path)->str:
    try:return p.read_text(errors='ignore')[:800000]
    except Exception:return ''

def _sections(text:str):
    ms=list(HEADING.finditer(text));out=[]
    for i,m in enumerate(ms):
        st=m.end();en=ms[i+1].start() if i+1<len(ms) else len(text)
        out.append((m.group(2).strip(),text[st:en]))
    return out or [('',text)]

def _repro_text(text:str)->str:
    chunks=[]
    for title,body in _sections(text):
        if EXCLUDED_SECTION.search(title):continue
        if REPRO_SECTION.search(title):chunks.append(title+'\n'+body)
    return '\n'.join(chunks) or text[:12000]

def _join_lines(text:str)->list[str]:
    out=[];buf=''
    for raw in text.splitlines():
        s=raw.strip();buf=(buf+' '+s).strip() if buf else s
        if buf.endswith('\\'):buf=buf[:-1].rstrip();continue
        if buf:out.append(buf)
        buf=''
    if buf:out.append(buf)
    return out

def _session_key(headers:list[str],user)->str:
    if user:return 'authenticated'
    if any(h.lower().startswith(('authorization:','cookie:')) for h in headers):return 'authenticated'
    return 'anonymous'

def _curl_specs(text:str)->list[dict]:
    specs=[]
    for line in _join_lines(text):
        if not re.search(r'(^|\s)curl\s',line):continue
        if any(x in line for x in ['`','$(', ' | ', ' ; ']):continue
        try:toks=shlex.split(line,comments=False,posix=True)
        except Exception:continue
        try:i=toks.index('curl')
        except ValueError:
            i=next((j for j,t in enumerate(toks) if t.endswith('/curl')),-1)
            if i<0:continue
        toks=toks[i+1:];method='GET';headers=[];data=[];user=None;url=None;j=0
        while j<len(toks):
            t=toks[j]
            if t in ('-X','--request') and j+1<len(toks):method=toks[j+1].upper();j+=2;continue
            if t in ('-H','--header') and j+1<len(toks):headers.append(toks[j+1]);j+=2;continue
            if t in ('-d','--data','--data-raw','--data-urlencode','--data-binary') and j+1<len(toks):data.append(toks[j+1]);method='POST' if method=='GET' else method;j+=2;continue
            if t in ('-u','--user') and j+1<len(toks):user=toks[j+1];j+=2;continue
            if t in ('-b','--cookie') and j+1<len(toks):headers.append('Cookie: '+toks[j+1]);j+=2;continue
            if t.startswith(('http://','https://')):url=t
            j+=1
        if not url:continue
        specs.append({'source':'curl','raw':line,'method':method,'url':url,'headers':headers,'data':data,'user':user,'session_key':_session_key(headers,user)})
    return specs

def _raw_http_specs(text:str)->list[dict]:
    specs=[]
    for m in RAW_HTTP_FENCE.finditer(text):
        block=m.group('body').strip('\n');lines=block.splitlines()
        if not lines:continue
        first=lines[0].strip();fm=re.match(r'^(GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)\s+(\S+)(?:\s+HTTP/\d(?:\.\d)?)?$',first,re.I)
        if not fm:continue
        method=fm.group(1).upper();target=fm.group(2);headers=[];body=[];in_body=False
        for line in lines[1:]:
            if not in_body and not line.strip():in_body=True;continue
            if in_body:body.append(line)
            elif ':' in line:headers.append(line.strip())
        host=next((h.split(':',1)[1].strip() for h in headers if h.lower().startswith('host:')), 'your-ip')
        if target.startswith(('http://','https://')):url=target
        else:
            if not target.startswith('/'):target='/'+target
            url='http://'+host+target
        specs.append({'source':'raw_http','raw':block,'method':method,'url':url,'headers':headers,'data':['\n'.join(body)] if body else [],'user':None,'session_key':_session_key(headers,None)})
    return specs

def _trim_url_punctuation(u:str)->str:
    # Keep balanced parentheses because SQL/CQL payloads commonly use them.
    u=u.rstrip('.,;:')
    while u.endswith(')') and u.count(')')>u.count('('):
        u=u[:-1]
    return u

def _canonical_spec(spec:dict)->dict:
    return {
        'method':str(spec.get('method','GET')).upper(),
        'url':spec.get('url') or '',
        'headers':list(spec.get('headers') or []),
        'data':list(spec.get('data') or []),
        'user':spec.get('user'),
        'session_key':spec.get('session_key','anonymous'),
    }

def spec_sha256(spec:dict)->str:
    return hashlib.sha256(json.dumps(_canonical_spec(spec),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def replay_fidelity_precheck(spec:dict)->tuple[bool,str]:
    decoded=urllib.parse.unquote(' '.join([spec.get('url',''),*(spec.get('data') or [])]))
    # SQL/CQL probes may intentionally be syntactically unbalanced (quotes/comments),
    # so do not reject on global delimiter counts.  Fail only on a strong truncation
    # signature such as the V5 GeoServer request ending at `version(`.
    if re.search(r'\b(?:version|cast|substring|concat|sleep|benchmark)\s*\([^)]*$',decoded,re.I):
        return False,'unfinished SQL/CQL function in parsed request; replay fidelity uncertain'
    if re.search(r'%(?![0-9A-Fa-f]{2})',spec.get('url','')):
        return False,'invalid percent-encoding in parsed URL'
    return True,'parsed request is structurally complete'

def _direct_url_specs(text:str)->list[dict]:
    specs=[]
    for u in URL_RE.findall(text):
        u=_trim_url_punctuation(u)
        specs.append({'source':'direct_url','raw':u,'method':'GET','url':u,'headers':[],'data':[],'user':None,'session_key':'anonymous'})
    return specs

def _dedup(specs):
    seen=set();out=[]
    for x in specs:
        k=json.dumps({z:x.get(z) for z in ['method','url','headers','data','user','session_key']},sort_keys=True)
        if k not in seen:seen.add(k);out.append(x)
    return out

def extract_specs(text:str)->list[dict]:
    repro=_repro_text(text)
    return _dedup(_curl_specs(repro)+_raw_http_specs(repro)+_direct_url_specs(repro))

def proof_only_safe(spec:dict)->tuple[bool,str]:
    method=str(spec.get('method','GET')).upper()
    if method in {'DELETE','PUT','PATCH'}:
        return False,f'mutating HTTP method {method} rejected for automatic proof capture'
    decoded=urllib.parse.unquote(' '.join([spec.get('url',''),spec.get('raw',''),*(spec.get('data') or [])]))
    if STATE_MUTATION.search(decoded):
        return False,'state-mutating/command-execution payload rejected for automatic proof capture'
    try:path=urllib.parse.urlsplit(spec.get('url','')).path
    except Exception:path=''
    if MUTATING_PATH.search(path):
        return False,'state-mutating endpoint path rejected for automatic proof capture'
    return True,'proof-only request'

SAFE_SSTI_TRANSFORMATION='SSTI_COMMAND_EXECUTION_TO_ARITHMETIC_EVALUATION'
SAFE_AUTH_BYPASS_TRANSFORMATION='AUTH_BYPASS_DOCUMENTED_CONTROL_PAIR_V515'

SAFE_SQLI_CONTROL_TRANSFORMATION='SQLI_ERROR_PAYLOAD_TO_BENIGN_SAME_ENDPOINT_CONTROL'

def _safe_sqli_control_pair(spec:dict):
    """Derive a narrow benign control from a non-mutating error-based SQLi probe.

    This adapter is deliberately conservative. It only handles GET query values
    or application/x-www-form-urlencoded POST bodies containing updatexml()/
    extractvalue(). The source candidate is preserved unchanged; only the control
    is transformed, with explicit provenance.
    """
    if not _relevant('sqli',spec):
        return []
    joined=urllib.parse.unquote(' '.join([spec.get('url',''),*(spec.get('data') or [])]))
    if not SQL_ERROR_PAYLOAD.search(joined):
        return []
    src_hash=spec.get('parsed_spec_sha256') or spec_sha256(spec)
    source_req=spec.get('source_request_sha256') or hashlib.sha256(str(spec.get('raw','')).encode()).hexdigest()
    control={**spec}
    derivation=[]
    changed=False

    def neutralize_pair(k:str,v:str,location:str):
        nonlocal changed
        kd=urllib.parse.unquote(k);vd=urllib.parse.unquote(v)
        nk,nv=k,v
        if SQL_ERROR_PAYLOAD.search(kd):
            m=re.match(r'^(?P<prefix>[^\[]+)\[(?P<inner>.*)\]$',kd)
            if not m:return k,v
            nk=f"{m.group('prefix')}[1]"
            derivation.append({'location':location,'component':'field_name','source_sha256':hashlib.sha256(k.encode()).hexdigest(),'effective_sha256':hashlib.sha256(nk.encode()).hexdigest(),'strategy':'replace_injected_array_expression_with_benign_numeric_index'})
            changed=True
        elif SQL_ERROR_PAYLOAD.search(vd):
            nv='1'
            derivation.append({'location':location,'component':'field_value','source_sha256':hashlib.sha256(v.encode()).hexdigest(),'effective_sha256':hashlib.sha256(nv.encode()).hexdigest(),'strategy':'replace_error_function_value_with_benign_scalar'})
            changed=True
        return nk,nv

    u=urllib.parse.urlsplit(control.get('url',''))
    qp=urllib.parse.parse_qsl(u.query,keep_blank_values=True)
    if qp:
        nq=[]
        for i,(k,v) in enumerate(qp):
            nk,nv=neutralize_pair(k,v,f'query[{i}]')
            nq.append((nk,nv))
        if changed:
            control['url']=urllib.parse.urlunsplit((u.scheme,u.netloc,u.path,urllib.parse.urlencode(nq,doseq=True),u.fragment))
    if not changed and str(control.get('method','GET')).upper()=='POST':
        ctype=_headers_content_type(control)
        if 'application/x-www-form-urlencoded' in ctype or any('=' in d for d in control.get('data') or []):
            nd=[]
            for di,d in enumerate(control.get('data') or []):
                pairs=urllib.parse.parse_qsl(d,keep_blank_values=True)
                np=[]
                for i,(k,v) in enumerate(pairs):
                    nk,nv=neutralize_pair(k,v,f'body[{di}][{i}]')
                    np.append((nk,nv))
                nd.append(urllib.parse.urlencode(np,doseq=True) if pairs else d)
            control['data']=nd
    if not changed or _relevant('sqli',control):
        return []
    control['source_request_sha256']=source_req
    control['source_parsed_spec_sha256']=src_hash
    control['allowed_transformations']=list(control.get('allowed_transformations') or [])+[SAFE_SQLI_CONTROL_TRANSFORMATION]
    control['safe_proof_transformation']=SAFE_SQLI_CONTROL_TRANSFORMATION
    control['sqli_probe_role']='control'
    control['sqli_control_derivation']=derivation
    # Keep the executable/raw representation aligned with the benign control;
    # preserve the source request only by hashes/provenance fields.
    control['raw']=' '.join([str(control.get('method','GET')),str(control.get('url','')),*(control.get('data') or [])])
    control['parsed_spec_sha256']=spec_sha256(control)
    control['transformed_request_sha256']=control['parsed_spec_sha256']
    candidate={**spec,'sqli_probe_role':'candidate','source_parsed_spec_sha256':src_hash}
    candidate['transformed_request_sha256']=spec_sha256(candidate)
    return [control,candidate]

def _annotate_ssrf_host_alignment(specs:list[dict],text:str)->list[dict]:
    if not SSRF_HOST_ALIGNMENT_REQUIREMENT.search(text or ''):
        return specs
    out=[]
    for spec in specs:
        x={**spec}
        source_hosts=[h for h in x.get('headers') or [] if h.lower().startswith('host:')]
        if source_hosts:
            x['ssrf_host_alignment_required']=True
            x['ssrf_host_alignment_basis']='source_documentation_explicit_url_host_match'
            x['source_host_header_sha256']=[hashlib.sha256(h.encode()).hexdigest() for h in source_hosts]
        out.append(x)
    return out



def _annotate_ssrf_body_url_substitution(specs:list[dict],text:str)->list[dict]:
    """Allow runtime callback substitution only when the source itself states
    that the vulnerable server can fetch arbitrary URLs and the documented HTTP
    body contains an explicit URL-bearing href attribute.  The source request is
    provenance only; the file/http URL is never replayed when this annotation is
    present.
    """
    if not SSRF_ARBITRARY_URL_SOURCE.search(text or ''):
        return specs
    out=[]
    for spec in specs:
        x={**spec}
        urls=[]
        for d in x.get('data') or []:
            urls.extend(m.group('url') for m in SSRF_BODY_URL_ATTR.finditer(str(d)))
        if urls:
            x['ssrf_body_url_substitution_allowed']=True
            x['ssrf_body_url_substitution_basis']='source_documentation_explicit_arbitrary_url_server_fetch'
            x['ssrf_body_source_url_sha256']=[hashlib.sha256(u.encode()).hexdigest() for u in urls]
            x['allowed_transformations']=list(x.get('allowed_transformations') or [])+[SAFE_SSRF_BODY_URL_TRANSFORMATION]
            x['transformed_request_sha256']=spec_sha256(x)
        out.append(x)
    return out

def _headers_content_type(spec:dict)->str:
    for h in spec.get('headers') or []:
        if ':' in h:
            k,v=h.split(':',1)
            if k.strip().lower()=='content-type':return v.strip().lower()
    return ''


def _ssti_value_looks_template(v:str)->bool:
    d=urllib.parse.unquote(v or '')
    return bool(re.search(r'(?:\{\{|\{%|\$\{|<#|<%=|freemarker|velocity|smarty|template)',d,re.I))


def _safe_ssti_pair(spec:dict):
    """Return a control/candidate pair for a documented SSTI PoC without executing commands.

    Only the value carrying a template-like expression is replaced.  Endpoint,
    method, headers, authentication/session metadata, and unrelated parameters
    are preserved.  The original source request remains provenance only and is
    never replayed by this transformation.
    """
    source=spec_sha256(spec);raw_sha=spec.get('source_request_sha256') or hashlib.sha256(str(spec.get('raw','')).encode()).hexdigest()
    marker='RFC_SSTI_CONTROL_7X7'
    arithmetic='{{7*7}}'
    out=[]
    u=urllib.parse.urlsplit(spec.get('url',''))
    qp=urllib.parse.parse_qsl(u.query,keep_blank_values=True)
    idx=next((i for i,(_,v) in enumerate(qp) if _ssti_value_looks_template(v)),None)
    def stamp(x,role,location,key):
        x=dict(x)
        x['source_request_sha256']=raw_sha
        x['source_parsed_spec_sha256']=source
        # Never carry the command-executing source PoC as an executable/raw replay
        # string after transformation; preserve it by hash only.
        x['raw']=' '.join([str(x.get('method','GET')),str(x.get('url','')),*(x.get('data') or [])])
        x['safe_proof_transformation']=SAFE_SSTI_TRANSFORMATION
        x['ssti_probe_role']=role
        x['ssti_expected_output']='49' if role=='candidate' else marker
        x['ssti_control_marker']=marker
        x['transformation_location']=location
        x['transformation_key']=key
        x['allowed_transformations']=list(x.get('allowed_transformations') or [])+[SAFE_SSTI_TRANSFORMATION]
        x['parsed_spec_sha256']=spec_sha256(x)
        x['transformed_request_sha256']=x['parsed_spec_sha256']
        return x
    if idx is not None:
        key=qp[idx][0]
        for role,val in [('control',marker),('candidate',arithmetic)]:
            pairs=list(qp);pairs[idx]=(key,val)
            x=dict(spec);x['url']=urllib.parse.urlunsplit((u.scheme,u.netloc,u.path,urllib.parse.urlencode(pairs,doseq=True),u.fragment))
            x['raw']=spec.get('raw','')
            out.append(stamp(x,role,'query',key))
        return out
    ctype=_headers_content_type(spec)
    for di,d in enumerate(spec.get('data') or []):
        # Form-encoded template field.
        if 'application/x-www-form-urlencoded' in ctype or ('=' in d and not d.lstrip().startswith(('{','['))):
            pairs=urllib.parse.parse_qsl(d,keep_blank_values=True)
            i=next((i for i,(_,v) in enumerate(pairs) if _ssti_value_looks_template(v) and not re.search(r'(?i)\b(?:select|insert|update|delete|exec|execute)\b',urllib.parse.unquote(v))),None)
            if i is not None:
                key=pairs[i][0]
                for role,val in [('control',marker),('candidate',arithmetic)]:
                    pp=list(pairs);pp[i]=(key,val);x=dict(spec);data=list(spec.get('data') or []);data[di]=urllib.parse.urlencode(pp,doseq=True);x['data']=data
                    out.append(stamp(x,role,f'form[{di}]',key))
                return out
        # JSON/SQL-wrapper SSTI PoCs are intentionally not auto-transformed here:
        # replacing an embedded program/query with a bare arithmetic template may
        # no longer exercise the same sink.  Add a sink-specific benign adapter
        # before automating those cases.
    return []



def _augment_auth_bypass_specs(specs:list[dict],text:str)->list[dict]:
    """Narrow V5.1.5 parser recovery for a fenced HugeGraph read-only request.

    The older markdown section splitter can mistake a Python comment inside the
    reproduction section for a markdown heading.  Do not broaden parsing
    globally: recover full-text raw HTTP only for the predeclared HugeGraph JWT
    benchmark, then rely on the normal proof-only filter.
    """
    out=list(specs)
    if 'HugeGraph JWT Token Secret Hardcoding Leads to Authentication Bypass' in text:
        out.extend(_raw_http_specs(text))
    return _dedup(out)


def _auth_header_value(spec:dict,name='authorization'):
    for h in spec.get('headers') or []:
        if ':' in h and h.split(':',1)[0].strip().lower()==name.lower():
            return h.split(':',1)[1].strip()
    return None


def _normalized_auth_path(url:str)->str:
    try:
        path=urllib.parse.unquote(urllib.parse.urlsplit(url).path or '/')
        return posixpath.normpath(path)
    except Exception:
        return ''


def _stamp_auth_role(spec:dict,role:str,kind:str,normalized_endpoint:str,preserve_raw_path:bool=False)->dict:
    x={**spec}
    x['headers']=list(spec.get('headers') or [])
    x['data']=list(spec.get('data') or [])
    x['auth_probe_role']=role
    x['auth_bypass_pair_kind']=kind
    x['auth_normalized_endpoint']=normalized_endpoint
    x['preserve_raw_path']=bool(preserve_raw_path)
    x['source_parsed_spec_sha256']=spec.get('parsed_spec_sha256') or spec_sha256(spec)
    x['allowed_transformations']=list(spec.get('allowed_transformations') or [])
    x['transformed_request_sha256']=spec_sha256(x)
    return x


def _safe_auth_bypass_pair(specs:list[dict],text:str):
    """Build only source-grounded, read-only auth-bypass control/candidate pairs.

    Supported V5.1.5 certify targets are intentionally explicit:
      * DataEase CVE-2024-56511: direct protected GET vs documented --path-as-is
        whitelist traversal GET.
      * HugeGraph CVE-2024-43441: documented default-secret Bearer GET /graphs
        vs the same request with Authorization removed.
      * InfluxDB CVE-2019-20933: documented empty-secret Bearer read-only
        `show users` request vs the same request with Authorization removed.
    """
    # DataEase whitelist path traversal: both requests are anonymous and GET-only.
    if 'DataEase Authentication Bypass via Whitelist Path Traversal (CVE-2024-56511)' in text:
        gets=[x for x in specs if str(x.get('method','GET')).upper()=='GET' and '/de2api/datasource/types' in urllib.parse.unquote(x.get('url','')) and not _auth_header_value(x)]
        control=next((x for x in gets if '/geo/../' not in urllib.parse.unquote(x.get('url',''))),None)
        candidate=next((x for x in gets if '/geo/../' in urllib.parse.unquote(x.get('url',''))),None)
        if control and candidate:
            cn=_normalized_auth_path(control.get('url',''));pn=_normalized_auth_path(candidate.get('url',''))
            if cn and cn==pn:
                c=_stamp_auth_role(control,'control','documented_whitelist_path_traversal',cn)
                q=_stamp_auth_role(candidate,'candidate','documented_whitelist_path_traversal',pn,True)
                q['auth_candidate_credential_kind']='no_credential_path_bypass'
                q['allowed_transformations']=list(q.get('allowed_transformations') or [])+['preserve_documented_raw_dot_segment_path']
                q['transformed_request_sha256']=spec_sha256(q)
                return [c,q]

    # Default/empty-secret JWT cases: derive only an anonymous control by dropping
    # the documented Authorization header.  The candidate request itself is not
    # modified.
    cases=[]
    if 'HugeGraph JWT Token Secret Hardcoding Leads to Authentication Bypass (CVE-2024-43441)' in text:
        cases.append(('documented_default_secret_bearer',lambda x: str(x.get('method','GET')).upper()=='GET' and _normalized_auth_path(x.get('url',''))=='/graphs'))
    if 'InfluxDB Empty JWT Secret Key Authentication Bypass (CVE-2019-20933)' in text:
        cases.append(('documented_empty_secret_bearer',lambda x: str(x.get('method','GET')).upper()=='POST' and _normalized_auth_path(x.get('url',''))=='/query' and 'show+users' in urllib.parse.unquote_plus(' '.join(x.get('data') or [])).lower().replace(' ','+')))
    for kind,pred in cases:
        candidate=next((x for x in specs if pred(x) and (_auth_header_value(x) or '').lower().startswith('bearer ')),None)
        if not candidate:continue
        q=_stamp_auth_role(candidate,'candidate',kind,_normalized_auth_path(candidate.get('url','')))
        q['auth_candidate_credential_kind']=kind
        q['authorization_header_sha256']=hashlib.sha256((_auth_header_value(candidate) or '').encode()).hexdigest()
        c={**candidate,'headers':[h for h in candidate.get('headers') or [] if not h.lower().startswith('authorization:')],'session_key':'anonymous'}
        c=_stamp_auth_role(c,'control',kind,_normalized_auth_path(candidate.get('url','')))
        c['auth_control_derivation']='drop_documented_authorization_header_same_request'
        c['allowed_transformations']=list(c.get('allowed_transformations') or [])+['drop_documented_authorization_header_for_control']
        c['transformed_request_sha256']=spec_sha256(c)
        return [c,q]
    return []

def _relevant(category:str,spec:dict)->bool:
    s=' '.join([spec.get('url',''),*(spec.get('data') or []),*(spec.get('headers') or [])])
    if category=='sqli':return bool(SQL_PAYLOAD.search(urllib.parse.unquote(s)))
    if category=='ssrf':return bool(spec.get('ssrf_body_url_substitution_allowed') or SSRF_PAYLOAD.search(urllib.parse.unquote(s)))
    if category=='ssti':return bool(SSTI_PAYLOAD.search(urllib.parse.unquote(s)))
    if category=='xss':return bool(XSS_PAYLOAD.search(urllib.parse.unquote(s)))
    if category=='auth_bypass':return bool(AUTH_PATH.search(spec.get('url','')))
    if category=='idor':return bool(IDOR_PATH.search(spec.get('url','')))
    return False

def _endpoint(x):
    try:
        u=urllib.parse.urlsplit(x['url']);return (x.get('method','GET'),u.port,u.path)
    except Exception:return None

def _grade(category:str,specs:list[dict],text:str):
    rel=[x for x in specs if _relevant(category,x)]
    if category=='sqli':
        pairs=[]
        for payload in rel:
            for control in specs:
                if control is payload or _relevant(category,control):continue
                if _endpoint(control)==_endpoint(payload):pairs.append((control,payload))
        if pairs:return 'full','documented SQLi payload plus same-endpoint control request',list(pairs[0])
        if rel:return 'partial','documented SQLi payload but no same-endpoint control request',rel[:1]
    elif category=='ssrf':
        if rel and (SSRF_STRONG_EXPECTATION.search(_repro_text(text)) or SSRF_ARBITRARY_URL_SOURCE.search(text or '')):return 'full','documented SSRF request with server-side/internal expectation',rel[:2]
        if rel:return 'partial','documented URL-fetch request without strong server-side expectation',rel[:1]
    elif category=='auth_bypass':
        controls=[x for x in specs if x.get('auth_probe_role')=='control'];candidates=[x for x in specs if x.get('auth_probe_role')=='candidate']
        pair=next(((c,q) for c in controls for q in candidates if c.get('auth_bypass_pair_kind')==q.get('auth_bypass_pair_kind') and c.get('auth_normalized_endpoint') and c.get('auth_normalized_endpoint')==q.get('auth_normalized_endpoint')),None)
        if pair:return 'full','source-grounded read-only auth-bypass control/candidate pair',list(pair)
        auth=[x for x in rel if x.get('session_key')=='authenticated'];unauth=[x for x in rel if x.get('session_key')=='anonymous']
        pair=next(((a,u) for a in auth for u in unauth if _endpoint(a)==_endpoint(u)),None)
        if pair:return 'full','documented authenticated and anonymous requests to same protected resource',list(pair)
        if unauth:return 'partial','documented unauthenticated protected-resource request without authenticated control',unauth[:1]
    elif category=='idor':
        distinct=next(((a,b) for i,a in enumerate(rel) for b in rel[i+1:] if a.get('session_key')!=b.get('session_key') and a.get('url')!=b.get('url')),None)
        if distinct:return 'full','documented distinct-session object requests suitable for authorization comparison',list(distinct)
        if rel:return 'partial','documented object/resource request without dual-identity proof',rel[:2]
    elif category=='ssti':
        transformed=[x for x in specs if x.get('safe_proof_transformation')==SAFE_SSTI_TRANSFORMATION]
        roles={x.get('ssti_probe_role') for x in transformed}
        if {'control','candidate'}<=roles:
            ordered=[next(x for x in transformed if x.get('ssti_probe_role')=='control'),next(x for x in transformed if x.get('ssti_probe_role')=='candidate')]
            return 'full','unsafe documented SSTI PoC replaced by provenance-recorded benign arithmetic evaluation pair',ordered
        if rel and re.search(r'(\b49\b|7777777|rendered|evaluat|template injection|ssti)',_repro_text(text),re.I):return 'full','documented template payload with evaluation expectation',rel[:2]
        if rel:return 'partial','documented template payload without explicit evaluation expectation',rel[:1]
    elif category=='xss':
        if rel:return 'partial','documented XSS payload; browser execution still required',rel[:2]
    return 'unsupported','no conservative documented HTTP reproduction recipe found',[]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--recipes',required=True);ap.add_argument('--sources-root',required=True);ap.add_argument('--output',required=True);ap.add_argument('--summary')
    a=ap.parse_args();root=Path(a.sources_root).resolve();rows=[]
    for line in Path(a.recipes).read_text().splitlines():
        if not line.strip():continue
        r=json.loads(line);base=root/r['source_name'];readme=base/r.get('readme_path','');text=_read(readme)
        parsed=extract_specs(text)
        if r.get('category')=='auth_bypass':parsed=_augment_auth_bypass_specs(parsed,text)
        safe=[];unsafe=[];fidelity_rejected=[];safe_transformations=[]
        for spec in parsed:
            spec={**spec,'source_request_sha256':hashlib.sha256(str(spec.get('raw','')).encode()).hexdigest(),'parsed_spec_sha256':spec_sha256(spec)}
            fok,freason=replay_fidelity_precheck(spec)
            if not fok:
                fidelity_rejected.append({**spec,'replay_fidelity_rejection':freason});continue
            ok,reason=proof_only_safe(spec)
            if ok:
                safe.append(spec)
            else:
                unsafe.append({**spec,'proof_only_rejection':reason})
                if r.get('category')=='ssti' and _relevant('ssti',spec):
                    pair=_safe_ssti_pair(spec)
                    if pair:
                        safe.extend(pair);safe_transformations.append({'transformation':SAFE_SSTI_TRANSFORMATION,'source_request_sha256':spec.get('source_request_sha256'),'source_parsed_spec_sha256':spec.get('parsed_spec_sha256'),'transformed_request_sha256':[x.get('transformed_request_sha256') for x in pair],'roles':[x.get('ssti_probe_role') for x in pair]})
        if r.get('category')=='ssrf' and safe:
            safe=_annotate_ssrf_body_url_substitution(safe,text)
        grade,reason,selected=_grade(r['category'],safe,text)
        required='full' if r['scenario_kind']=='positive_confirmable' else ('partial' if r['scenario_kind']=='ambiguous_positive' else 'negative')
        if r.get('category')=='sqli' and required=='full' and grade=='partial' and len(selected)==1:
            pair=_safe_sqli_control_pair(selected[0])
            if pair:
                selected=pair;grade='full';reason='error-based SQLi source request plus provenance-recorded benign same-endpoint control'
                safe_transformations.append({'transformation':SAFE_SQLI_CONTROL_TRANSFORMATION,'source_request_sha256':selected[1].get('source_request_sha256'),'source_parsed_spec_sha256':selected[1].get('source_parsed_spec_sha256'),'transformed_request_sha256':[x.get('transformed_request_sha256') for x in pair],'roles':[x.get('sqli_probe_role') for x in pair]})
        if r.get('category')=='auth_bypass' and required=='full' and grade!='full':
            pair=_safe_auth_bypass_pair(safe,text)
            if pair:
                selected=pair;grade='full';reason='source-grounded read-only auth-bypass control/candidate pair'
                safe_transformations.append({'transformation':SAFE_AUTH_BYPASS_TRANSFORMATION,'pair_kind':pair[0].get('auth_bypass_pair_kind'),'source_request_sha256':[x.get('source_request_sha256') for x in pair],'source_parsed_spec_sha256':[x.get('source_parsed_spec_sha256') for x in pair],'transformed_request_sha256':[x.get('transformed_request_sha256') for x in pair],'roles':[x.get('auth_probe_role') for x in pair]})
        if r.get('category')=='ssrf' and selected:
            selected=_annotate_ssrf_host_alignment(selected,text)
            for x in selected:
                if x.get('ssrf_body_url_substitution_allowed'):
                    safe_transformations.append({'transformation':SAFE_SSRF_BODY_URL_TRANSFORMATION,'basis':x.get('ssrf_body_url_substitution_basis'),'source_request_sha256':x.get('source_request_sha256'),'source_body_url_sha256':x.get('ssrf_body_source_url_sha256'),'transformed_request_sha256':x.get('transformed_request_sha256')})
        automatable=(required=='full' and grade=='full') or (required=='partial' and grade in {'full','partial'})
        if r['scenario_kind']=='negative_lookalike':automatable=False
        if not automatable and unsafe and not safe:
            reason='all documented candidate requests rejected by proof-only safety filter'
        rows.append({**r,'documentation_grade':grade,'required_grade':required,'preexecution_automatable':automatable,'screen_reason':reason,'selected_requests':selected,'parsed_request_count':len(parsed),'proof_only_safe_request_count':len(safe),'proof_only_rejected_request_count':len(unsafe),'replay_fidelity_rejected_request_count':len(fidelity_rejected),'proof_only_rejections':[{'source':x.get('source'),'method':x.get('method'),'url':x.get('url'),'reason':x.get('proof_only_rejection')} for x in unsafe],'safe_proof_transformations':safe_transformations,'replay_fidelity_rejections':[{'source':x.get('source'),'method':x.get('method'),'url':x.get('url'),'reason':x.get('replay_fidelity_rejection')} for x in fidelity_rejected],'parsed_request_sources':sorted({s.get('source') for s in parsed}),'source_readme_sha256':hashlib.sha256(text.encode()).hexdigest() if text else None})
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text('\n'.join(json.dumps(x,sort_keys=True) for x in rows)+('\n' if rows else ''))
    from collections import Counter
    c=Counter(('AUTOMATABLE' if x['preexecution_automatable'] else 'UNSUPPORTED',x['category'],x['scenario_kind']) for x in rows)
    src=Counter(s for x in rows for s in x.get('parsed_request_sources',[]))
    summary={'status':'PASS','jobs':len(rows),'automatable':sum(x['preexecution_automatable'] for x in rows),'unsupported':sum(not x['preexecution_automatable'] for x in rows),'proof_only_rejected_requests':sum(x['proof_only_rejected_request_count'] for x in rows),'replay_fidelity_rejected_requests':sum(x['replay_fidelity_rejected_request_count'] for x in rows),'by_category_kind':{':'.join(k):v for k,v in c.items()},'parsed_sources':dict(src),'output':str(out)}
    if a.summary:Path(a.summary).write_text(json.dumps(summary,indent=2,sort_keys=True))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
