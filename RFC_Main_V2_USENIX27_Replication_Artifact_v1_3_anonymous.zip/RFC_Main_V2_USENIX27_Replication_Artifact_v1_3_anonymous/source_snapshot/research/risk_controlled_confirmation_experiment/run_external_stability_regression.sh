#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
EXT="$HERE/external"
SOURCES="$EXT/sources"
RECIPES="$EXT/acquisition_recipes.jsonl"
REPS=3
LIMIT=5
while [[ $# -gt 0 ]]; do
  case "$1" in
    --repetitions) REPS="${2:?repetitions required}"; shift 2;;
    --limit) LIMIT="${2:?limit required}"; shift 2;;
    *) echo "unknown argument: $1" >&2; exit 2;;
  esac
done
if [[ "$REPS" -lt 2 ]]; then echo "stability regression requires at least 2 repetitions" >&2; exit 2; fi
SERIES_ID="${RFC_STABILITY_ID:-$(date -u +%Y%m%dT%H%M%SZ)-stability-$$}"
SERIES="$EXT/stability/$SERIES_ID"
SCREENED="$SERIES/screened_capture_jobs.jsonl"
mkdir -p "$SERIES"
PYTHONPATH="$ROOT" python "$HERE/network_preflight.py" --output "$SERIES/network_preflight.json" || true
PYTHONPATH="$ROOT" python "$HERE/screen_capture_jobs.py" --recipes "$RECIPES" --sources-root "$SOURCES" --output "$SCREENED" --summary "$SERIES/screen_summary.json"
rc=0
for i in $(seq 1 "$REPS"); do
  idx=$(printf '%02d' "$i")
  REP="$SERIES/rep-$idx"
  RAW="$REP/acquired_raw"
  RUN_ID="${SERIES_ID}-r${idx}"
  mkdir -p "$RAW"
  set +e
  PYTHONPATH="$ROOT" python "$HERE/run_local_documented_capture.py" \
    --screened-jobs "$SCREENED" --sources-root "$SOURCES" --output-dir "$RAW" \
    --run-id "$RUN_ID" --limit "$LIMIT"
  rep_rc=$?
  set -e
  printf '{"run_id":"%s","capture_returncode":%s,"regression_only":true,"formal_n_contribution":0}\n' "$RUN_ID" "$rep_rc" > "$REP/regression_manifest.json"
  if [[ "$rep_rc" -ne 0 ]]; then rc="$rep_rc"; fi
done
# IMPORTANT: this regression path intentionally does NOT invoke
# export_external_bundle.py and does NOT create oracle/formal bundle files.
set +e
PYTHONPATH="$ROOT" python "$HERE/analyze_stability_regression.py" --series-dir "$SERIES" --output "$SERIES/stability_summary.json"
analysis_rc=$?
set -e
python - <<PY
import json
from pathlib import Path
p=Path(r'''$SERIES''')/'stability_summary.json'
obj=json.loads(p.read_text()) if p.exists() else {'status':'INCOMPLETE'}
print(json.dumps({'series_id':r'''$SERIES_ID''','series_dir':r'''$SERIES''','status':obj.get('status'),'formal_n_contribution':obj.get('formal_n_contribution'),'unstable_groups':obj.get('unstable_groups',[])},indent=2))
PY
if [[ "$analysis_rc" -ne 0 ]]; then exit "$analysis_rc"; fi
exit "$rc"
