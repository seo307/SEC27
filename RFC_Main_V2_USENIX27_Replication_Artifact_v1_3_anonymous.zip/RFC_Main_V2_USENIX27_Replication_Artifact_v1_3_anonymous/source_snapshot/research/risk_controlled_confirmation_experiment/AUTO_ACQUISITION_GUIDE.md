# Main-V2 Automated External Acquisition Bootstrap

This patch automates the **candidate discovery and preregistered-slot assignment** phase. It intentionally does **not** fabricate oracle truth or count synthetic mutations as independent N.

## Why the previous commands showed PASS + zero rows

The earlier `validate_external_bundle.py` checked consistency but did not reject an empty pair of JSONL files. This patch changes the default: empty capture/oracle bundles now fail. Use `--allow-empty` only when checking a newly created scaffold.

`formal_readiness.py` was already correct: zero eligible groups must be `NOT_READY`.

## One-command bootstrap

Dry run (shows clone commands only):

```bash
research/risk_controlled_confirmation_experiment/run_external_bootstrap.sh
```

Fetch the preregistered public repositories and populate every slot that can be supported automatically:

```bash
research/risk_controlled_confirmation_experiment/run_external_bootstrap.sh --execute
```

Outputs:

- `external/candidate_catalog.csv`
- `external/populated_group_plan_120.csv`
- `external/acquisition_recipes.jsonl`

The scanner is conservative and currently uses preregistered repositories only. Vulhub CVE/container directories are preferred as formal candidates because they provide distinct scenario paths and local Docker environments. Shared-codebase applications (WebGoat, Juice Shop, crAPI) are discovered but are not automatically recommended as multiple independent formal groups.

## Important limitation

The bootstrap can automatically assign **unique vulnerable scenarios** to `positive_confirmable` and `ambiguous_positive` slots. For ambiguous-positive slots it records `partial_evidence` mode; the underlying public scenario itself remains unique and is never reused by another formal group.

A `negative_lookalike` slot is assigned only when the candidate catalog explicitly contains an independently supported negative control. The default discovery pass does not invent such controls, so some or all negative slots may remain `SHORTFALL_NEEDS_INDEPENDENT_SOURCE`. That is intentional: inventing a safe clone of a vulnerable image and counting it as an independent external group would invalidate the formal-N argument.

The next automation layer should consume `acquisition_recipes.jsonl`, start only the listed local Docker environments, and construct category-specific direct evidence. It should never send probes to arbitrary Internet hosts.
