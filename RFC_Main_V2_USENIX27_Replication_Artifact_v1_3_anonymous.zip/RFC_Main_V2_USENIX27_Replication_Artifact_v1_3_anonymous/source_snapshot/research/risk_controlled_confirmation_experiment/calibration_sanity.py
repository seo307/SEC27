#!/usr/bin/env python3
from __future__ import annotations
import json
from run_experiment import select_threshold_exact, decision, stats


def synthetic_fixture():
    rows=[]; oracle={}
    # Safe confirmations occupy lower risk; false candidates overlap the fixed
    # 0.35 threshold but sit above the exact-calibrated low-risk region.
    for i in range(60):
        score=round(0.10 + (i % 13)*0.01, 3)  # 0.10..0.22
        rid=f'safe-{i:03d}'
        rows.append({'record_id':rid,'risk_score':score,'naive_risk_score':score,'structural_gate':{'allowed':True},'validator_result':{'status':'confirmed'}})
        oracle[rid]={'vulnerable':True,'ideal_decision':'confirm'}
    for i in range(20):
        score=round(0.26 + (i % 13)*0.01, 3)  # 0.26..0.38
        rid=f'false-{i:03d}'
        rows.append({'record_id':rid,'risk_score':score,'naive_risk_score':score,'structural_gate':{'allowed':True},'validator_result':{'status':'confirmed'}})
        oracle[rid]={'vulnerable':False,'ideal_decision':'abstain'}
    return rows,oracle


def run():
    rows,oracle=synthetic_fixture()
    t,trace=select_threshold_exact(rows,oracle,0.10,0.05)
    fixed={r['record_id']:decision('fixed_provenance',r,0.35) for r in rows}
    cal={r['record_id']:decision('calibrated',r,t) for r in rows}
    fs=stats(rows,oracle,fixed); cs=stats(rows,oracle,cal)
    differing=sum(fixed[k]!=cal[k] for k in fixed)
    out={'status':'PASS' if t is not None and abs(t-0.35)>1e-9 and differing>0 and cs['fcr']<=0.10 else 'FAIL',
         'alpha':0.10,'calibrated_threshold':t,'fixed_threshold':0.35,'differing_decisions':differing,
         'fixed':fs,'calibrated':cs,'trace_points':len(trace)}
    return out

if __name__=='__main__':
    out=run(); print(json.dumps(out,indent=2)); raise SystemExit(0 if out['status']=='PASS' else 2)
