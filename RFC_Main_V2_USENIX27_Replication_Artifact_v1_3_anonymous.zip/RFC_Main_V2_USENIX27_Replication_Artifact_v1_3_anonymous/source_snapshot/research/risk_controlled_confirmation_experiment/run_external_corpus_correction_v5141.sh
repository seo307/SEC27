#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
exec research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh \
  --only-new \
  --groups RFCEXT-sqli-013,RFCEXT-ssrf-010 "$@"
