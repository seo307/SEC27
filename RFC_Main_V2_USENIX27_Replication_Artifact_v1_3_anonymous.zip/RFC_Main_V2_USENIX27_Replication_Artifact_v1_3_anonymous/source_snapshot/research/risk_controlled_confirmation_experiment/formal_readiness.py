#!/usr/bin/env python3
"""Publication-oriented readiness audit for formal independent-group analysis."""
from __future__ import annotations
import argparse, json
from collections import Counter, defaultdict
from pathlib import Path
from common import HERE, read_jsonl, dump_json, load_json


def evaluate(dataset_dir: Path, config_path: Path) -> dict:
    oracle=read_jsonl(dataset_dir/'oracle.jsonl')
    records={r['record_id']:r for r in read_jsonl(dataset_dir/'records_blinded.jsonl')}
    cfg=load_json(config_path)
    clean=[o for o in oracle if o.get('certificate_eligible') and o.get('independence_eligible')]
    by_gid={}
    duplicates=[]
    for o in clean:
        gid=o.get('group_id')
        if gid in by_gid: duplicates.append(gid)
        by_gid[gid]=o
    groups=list(by_gid.values())
    roles=Counter(o.get('split_role') for o in groups)
    cats=Counter(o.get('category') for o in groups)
    ideals=defaultdict(Counter)
    structurally_confirmable=defaultdict(int)
    for o in groups:
        ideals[o.get('split_role')][o.get('ideal_decision')]+=1
        r=records.get(o['record_id'])
        if r and r.get('structural_gate',{}).get('allowed') and o.get('ideal_decision')=='confirm':
            structurally_confirmable[o.get('split_role')]+=1

    primary=str(cfg['primary_alpha'])
    required=int(cfg['formal_min_confirmations'][primary])
    cert_potential=structurally_confirmable['certify']
    checks={
        'no_duplicate_independent_groups': not duplicates,
        'all_groups_predeclared_split': bool(groups) and all(o.get('split_role') in {'tune','certify','test'} for o in groups),
        'oracle_independent': bool(groups) and all(o.get('oracle_independent_of_validator') is True for o in groups),
        'scenario_fingerprints_present_unique': bool(groups) and all(o.get('scenario_fingerprint') for o in groups) and len({o.get('scenario_fingerprint') for o in groups})==len(groups),
        'environment_fingerprints_present_unique': bool(groups) and all(o.get('environment_fingerprint') for o in groups) and len({o.get('environment_fingerprint') for o in groups})==len(groups),
        'all_splits_nonempty': all(roles[x]>0 for x in ['tune','certify','test']),
        'primary_certify_confirmable_capacity': cert_potential >= required,
    }
    warnings=[]
    if groups and any(cats[c]<10 for c in ['sqli','idor','ssrf','auth_bypass','ssti','xss']): warnings.append('one or more categories have <10 independent groups')
    if cert_potential==required: warnings.append('certify confirmable capacity has no buffer above the primary minimum; abstention may prevent certification')
    return {
        'status':'READY' if all(checks.values()) else 'NOT_READY',
        'primary_alpha':cfg['primary_alpha'],'required_primary_confirmations':required,
        'independent_groups':len(groups),'by_role':dict(roles),'by_category':dict(cats),
        'ideal_decision_by_role':{k:dict(v) for k,v in ideals.items()},
        'structurally_confirmable_ideal_confirm_by_role':dict(structurally_confirmable),
        'checks':checks,'warnings':warnings,'duplicate_groups':sorted(set(duplicates))[:20],
    }


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--dataset-dir',default=str(HERE/'work/dataset')); ap.add_argument('--output')
    a=ap.parse_args(); rep=evaluate(Path(a.dataset_dir),HERE/'config/experiment.json')
    if a.output: dump_json(Path(a.output),rep)
    print(json.dumps(rep,indent=2)); raise SystemExit(0 if rep['status']=='READY' else 4)

if __name__=='__main__': main()
