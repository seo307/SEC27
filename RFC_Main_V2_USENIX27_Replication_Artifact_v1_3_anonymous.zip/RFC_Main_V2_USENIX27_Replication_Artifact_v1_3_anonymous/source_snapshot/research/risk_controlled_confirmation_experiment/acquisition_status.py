#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from collections import Counter,defaultdict

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--plan',required=True);a=ap.parse_args()
 with open(a.plan,newline='') as f: rows=list(csv.DictReader(f))
 st=Counter(r['status'] for r in rows); by=defaultdict(Counter)
 for r in rows:by[r['category']][r['status']]+=1
 print(json.dumps({'rows':len(rows),'by_status':dict(st),'by_category':{k:dict(v) for k,v in by.items()},'ready_for_capture':st['ASSIGNED_PENDING_CAPTURE'],'shortfall':st['SHORTFALL_NEEDS_INDEPENDENT_SOURCE']},indent=2))
if __name__=='__main__':main()
