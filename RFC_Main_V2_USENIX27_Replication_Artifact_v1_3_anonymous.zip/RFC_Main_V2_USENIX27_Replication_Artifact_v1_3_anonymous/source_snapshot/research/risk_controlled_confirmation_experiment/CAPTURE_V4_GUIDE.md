# Main-V2 Auto-Capture V4 Guide

V4 fixes three issues observed in the first public-source smoke test:

1. full-README keyword contamination in candidate classification;
2. duplicate formal allocation of the same underlying public environment;
3. poor documentation coverage caused by curl-only screening.

## What changed

- Candidate classification now weights README title/path and exploit/reproduction sections. References and incidental chaining mentions cannot independently create a formal category.
- Every public target has a category-independent `environment_fingerprint` and a category-specific `finding_fingerprint`.
- Formal slot allocation uses `environment_fingerprint`; one underlying environment can occupy at most one independent formal group.
- Screening parses documented curl commands, fenced raw HTTP requests, and direct `http://your-ip...`/localhost URLs.
- Authenticated and anonymous documented requests are assigned isolated `requests.Session` instances. Sessions persist across sequential requests with the same session key.
- Arbitrary PoC scripts remain forbidden. XSS browser execution and IDOR without documented dual identity remain conservative/manual-review paths.

## Rebuild the catalog and plan

After applying V4, rerun the existing bootstrap against the already fetched sources:

```bash
research/risk_controlled_confirmation_experiment/run_external_bootstrap.sh --execute
```

Then inspect:

```text
external/candidate_catalog.csv
external/populated_group_plan_120.csv
external/acquisition_recipes.jsonl
```

## Smoke capture

```bash
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh --limit 5
```

Expected progression is no longer `automatable=0`. The exact number depends on the checked-out public-source revisions and is therefore not hard-coded.

## Formal independence

`validate_external_bundle.py` now rejects repeated `environment_fingerprint` among independence-eligible oracle rows even when category/finding fingerprints differ.
