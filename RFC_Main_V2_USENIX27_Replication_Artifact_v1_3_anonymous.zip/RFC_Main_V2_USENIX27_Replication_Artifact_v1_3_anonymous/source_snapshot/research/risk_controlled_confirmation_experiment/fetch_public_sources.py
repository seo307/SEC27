#!/usr/bin/env python3
"""Fetch only preregistered public vulnerable benchmark repositories.

This helper never scans or attacks Internet hosts. It clones source code into a local
workspace so scenario candidates can be discovered and later executed only in local
containers by the experiment operator.
"""
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--registry',default=str(HERE/'source_registry.json'))
    ap.add_argument('--dest',default=str(HERE/'external/sources'))
    ap.add_argument('--execute',action='store_true',help='Actually run git clone/fetch. Default is dry-run.')
    a=ap.parse_args()
    reg=json.loads(Path(a.registry).read_text())
    dest=Path(a.dest); dest.mkdir(parents=True,exist_ok=True)
    report=[]
    for src in reg['sources']:
        target=dest/src['name']
        if target.exists() and (target/'.git').exists():
            cmd=['git','-C',str(target),'fetch','--depth','1','origin']
            action='fetch'
        elif target.exists():
            report.append({'source':src['name'],'status':'BLOCKED_NON_GIT_PATH','path':str(target)})
            continue
        else:
            cmd=['git','clone','--depth','1',src['repo_url'],str(target)]
            action='clone'
        row={'source':src['name'],'action':action,'path':str(target),'command':cmd,'status':'DRY_RUN'}
        if a.execute:
            cp=subprocess.run(cmd,text=True,capture_output=True)
            row['returncode']=cp.returncode
            row['status']='OK' if cp.returncode==0 else 'ERROR'
            if cp.returncode: row['stderr']=cp.stderr[-1500:]
        report.append(row)
    print(json.dumps({'status':'PASS' if all(r['status'] in {'DRY_RUN','OK'} for r in report) else 'FAIL','sources':report},indent=2))

if __name__=='__main__': main()
