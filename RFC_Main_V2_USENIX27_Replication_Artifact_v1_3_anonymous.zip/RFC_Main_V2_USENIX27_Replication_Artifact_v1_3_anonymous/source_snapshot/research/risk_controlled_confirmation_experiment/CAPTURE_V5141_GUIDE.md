# RFC/Main-V2 Auto-Capture v5.1.4.1 — Runtime/Evidence Correction

This patch is deliberately narrow. It does **not** change the structural ProofBundle gate, risk gate, oracle labels, FCR definition, split assignments, environment-level independence rules, or existing data.

## Why this correction exists

The v5.1.4 targeted expansion run `20260811T011449Z-12712` exposed three runtime/evidence issues:

1. `RFCEXT-sqli-013` received persistent `302 -> /install.php` responses but was structurally exported as evidentiary. Persistent installer/setup redirects are now treated as `APPLICATION_PRECONDITION_FAILED` before vulnerability replay.
2. `RFCEXT-ssrf-010` published container ports 5005 and 8080. When the source URL omitted a logical port, the old fallback chose the first sorted mapping (JDWP 5005). The new fallback prefers likely HTTP(S) application ports and records the selection reason; the exact documented logical port still wins when present.
3. `RFCEXT-sqli-016` directly returned `XPATH syntax error: 'root@...'`, but the SQLi backend-evidence regex did not recognize this MySQL error-based signal. `XPATH syntax error` is now a SQLi-only backend-database marker through the existing category gate.

## Scientific status before rerun

Following read-only scientific review of `20260811T011449Z-12712`:

- `RFCEXT-sqli-016`: scientifically acceptable as an **ambiguous-positive / certify / ideal ABSTAIN** environment. It may be explicitly added to the scientific registry after review. It does not increase the certification-confirmation count because the ideal decision is ABSTAIN.
- `RFCEXT-sqli-013`: do not register from that run; application precondition failed.
- `RFCEXT-ssrf-010`: do not register from that run; HTTP/JDWP port selection was invalid.

To register SQLi-016 explicitly (only after confirming the run path exists locally):

```bash
REG=research/risk_controlled_confirmation_experiment/external/scientifically_accepted_environment_registry.json
python research/risk_controlled_confirmation_experiment/environment_registry.py record \
  --registry "$REG" \
  --oracle research/risk_controlled_confirmation_experiment/external/runs/20260811T011449Z-12712/oracle.jsonl \
  --ledger research/risk_controlled_confirmation_experiment/external/runs/20260811T011449Z-12712/acquisition_ledger.json \
  --accept-group RFCEXT-sqli-016
python research/risk_controlled_confirmation_experiment/environment_registry.py show --registry "$REG"
```

Expected unique accepted environments after that explicit registration: `7`.

## Patch validation

```bash
python -m pytest -q \
  research/risk_controlled_confirmation_experiment/tests/test_environment_registry_v513.py \
  research/risk_controlled_confirmation_experiment/tests/test_capture_v513_family_adapters.py \
  research/risk_controlled_confirmation_experiment/tests/test_capture_v514_corpus_expansion.py \
  research/risk_controlled_confirmation_experiment/tests/test_capture_v5141_runtime_corrections.py
```

Expected targeted result: `24 passed`.

For the full experiment suite:

```bash
python -m pytest -q research/risk_controlled_confirmation_experiment/tests
```

The audited build used for this patch passed `89` tests.

## Targeted correction rerun

Do not rerun SQLi-016 merely to increase N. Rerun only the two environments whose prior acquisitions were scientifically invalid because of adapter/precondition behavior:

```bash
research/risk_controlled_confirmation_experiment/run_external_corpus_correction_v5141.sh
```

Equivalent command:

```bash
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh \
  --only-new \
  --groups RFCEXT-sqli-013,RFCEXT-ssrf-010
```

### Expected SQLi-013 behavior

If Drupal still redirects to `/install.php` or another installer/setup endpoint, the run should stop at readiness with:

```text
APPLICATION_PRECONDITION_FAILED
formal N += 0
```

The exploit candidate should not be replayed merely to obtain an output row.

### Expected SSRF-010 behavior

With published mappings corresponding to container ports 5005 and 8080, a source URL without an explicit port should select the HTTP application mapping for 8080 rather than the JDWP mapping for 5005. The rewrite metadata should include a `port_selection_reason` and indicate when a known debug port was avoided. Normal SSRF callback substitution, Host alignment provenance, nonce correlation, and scientific review remain required.

## Data policy

Existing runs are immutable. Do not rewrite `20260811T011449Z-12712`. This patch changes future acquisition behavior only. Any retrospective interpretation of the prior run remains a read-only audit.
