#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
EXP=research/risk_controlled_confirmation_experiment
PYTHONPATH=. python "$EXP/preflight.py" --require-live-deps
PYTHONPATH=. python "$EXP/capture_live.py" --repetitions "${RFC_REPETITIONS:-5}"
PYTHONPATH=. python "$EXP/build_records.py"
PYTHONPATH=. python "$EXP/audit_experiment.py"
PYTHONPATH=. python "$EXP/run_experiment.py"
PYTHONPATH=. python "$EXP/audit_results.py"
PYTHONPATH=. python "$EXP/analyze_experiment.py"
