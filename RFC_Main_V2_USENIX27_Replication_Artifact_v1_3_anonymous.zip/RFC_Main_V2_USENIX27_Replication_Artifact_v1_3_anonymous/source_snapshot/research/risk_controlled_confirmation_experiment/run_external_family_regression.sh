#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
EXT="$HERE/external"
SOURCES="$EXT/sources"
RECIPES="$EXT/acquisition_recipes.jsonl"
TARGET_GROUPS=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --groups) TARGET_GROUPS="${2:?comma-separated group IDs required}"; shift 2 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done
if [[ -z "$TARGET_GROUPS" ]]; then echo "family regression requires --groups" >&2; exit 2; fi
RUN_ID="${RFC_FAMILY_REGRESSION_ID:-$(date -u +%Y%m%dT%H%M%SZ)-family-$$}"
RUN="$EXT/family_regression/$RUN_ID"
SCREENED="$RUN/screened_capture_jobs.jsonl"
RAW="$RUN/acquired_raw"
mkdir -p "$RAW"
PYTHONPATH="$ROOT" python "$HERE/network_preflight.py" --output "$RUN/network_preflight.json" || true
PYTHONPATH="$ROOT" python "$HERE/screen_capture_jobs.py" --recipes "$RECIPES" --sources-root "$SOURCES" --output "$SCREENED" --summary "$RUN/screen_summary.json"
set +e
PYTHONPATH="$ROOT" python "$HERE/run_local_documented_capture.py" --screened-jobs "$SCREENED" --sources-root "$SOURCES" --output-dir "$RAW" --run-id "$RUN_ID" --groups "$TARGET_GROUPS"
RC=$?
set -e
python - <<PY
import json
from pathlib import Path
run=Path(r'''$RUN''');summary=run/'acquired_raw'/'acquisition_summary.json'
obj=json.loads(summary.read_text()) if summary.exists() else {}
manifest={'run_id':r'''$RUN_ID''','groups':r'''$TARGET_GROUPS'''.split(','),'capture_returncode':$RC,'regression_only':True,'formal_n_contribution':0,'formal_export_invoked':False,'summary_status':obj.get('status')}
(run/'regression_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
print(json.dumps({'run_id':manifest['run_id'],'run_dir':str(run),'capture_returncode':manifest['capture_returncode'],'formal_n_contribution':0,'formal_export_invoked':False},indent=2))
PY
# Intentionally no export_external_bundle.py / oracle output on this path.
exit "$RC"
