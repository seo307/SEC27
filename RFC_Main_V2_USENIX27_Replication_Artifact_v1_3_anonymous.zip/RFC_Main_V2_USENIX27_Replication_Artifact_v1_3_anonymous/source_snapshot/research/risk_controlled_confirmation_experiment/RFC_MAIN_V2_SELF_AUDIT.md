# RFC Main-v2 Self-Audit

**Audit date:** 2026-08-10  
**Artifact:** Risk-Controlled Finding Confirmation — Main Experiment v2  
**Target:** USENIX Security 2027 Cycle 2

## 1. Audit scope

This audit was performed before release of Main-v2. The audit covered:

- Main-v1 findings identified during result review;
- strict structural confirmation semantics;
- evidence/state-level challenge construction;
- provenance dependence representation;
- intermediate-risk score support;
- independent-group calibration guardrails;
- oracle separation;
- relative artifact paths and archive portability;
- exact calibration sanity;
- experiment-specific regression tests;
- broader repository regression sampling;
- release-package hygiene and secret scanning.

---

## 2. Main-v1 defects addressed

### 2.1 Record-level certification inflation

**Main-v1 problem:** repeated runs and challenge derivatives could contribute to the nominal confirmation count used in the confidence-bound calculation.

**Main-v2 correction:** formal calibration accepts at most one predeclared natural record per `independence_eligible` `group_id`. Repetitions and challenge transformations are excluded from formal certification.

**Status:** FIXED.

### 2.2 Fixed and calibrated methods were identical

**Main-v1 problem:** all calibrated α values selected threshold `0.16`, producing exactly the same decisions as the fixed provenance-aware method.

**Main-v2 correction:** intermediate-risk states were added, and the formal calibration routine now selects a threshold using an exact one-sided risk upper bound rather than an empirical-FCR-only rule.

A preregistered synthetic calibration sanity fixture produced:

```text
alpha                  0.10
fixed threshold        0.35
calibrated threshold   0.26
differing decisions    15
fixed FCR              0.2208
calibrated FCR         0.0323
```

This fixture is a software sanity check only and is not publication evidence.

**Status:** FIXED AS ALGORITHM/TEST PROPERTY. Live external divergence remains an empirical result to be measured.

### 2.3 Binary/easy challenge score distribution

**Main-v1 problem:** structurally admissible records were concentrated near two risk-score values, making threshold calibration trivial.

**Main-v2 correction:** state/evidence-level conditions add intermediate states. Replay of the previous 60 live captures produced structurally allowed risk values:

```text
0.16, 0.18, 0.19, 0.28, 0.342, 0.804
```

**Status:** FIXED for mechanism evaluation.

### 2.4 Feature-level synthetic mutation

**Main-v1 problem:** some challenge conditions directly changed derived feature values.

**Main-v2 correction:** derived features are never mutated directly. Main-v2 changes underlying objects/state:

- evidence timestamps;
- deployment identity;
- actual artifact bytes;
- evidence provenance roots and `derived_from` links;
- actual contradictory evidence objects;
- explicit state-event metadata.

The dataset audit recomputes features and risk scores from raw record state and fails on drift.

**Status:** FIXED.

### 2.5 Correlated evidence was not true provenance dependence

**Main-v1 problem:** correlated duplication changed only nominal tool count.

**Main-v2 correction:** duplicate evidence objects are created with unique observation IDs, shared `provenance_root`, and explicit `derived_from` edges. Nominal tool count and independent-root count therefore diverge naturally.

**Status:** FIXED.

### 2.6 Target-continuity baseline semantics

**Main-v1 finding:** `ProofBundle.target_continuity_verified` existed but the structural `FindingConfirmationService` did not enforce it.

**Main-v2 correction:** `FindingConfirmationService.confirm()` now accepts `require_target_continuity`. Main-v2 invokes the structural baseline with this strict option enabled. A continuity-break challenge must therefore fail at the structural gate; the proposed risk method is not credited for a baseline implementation omission.

**Status:** FIXED.

### 2.7 Absolute artifact paths

**Main-v1 problem:** result records stored machine-specific absolute artifact paths, causing archive re-audit to fail after relocation.

**Main-v2 correction:** only dataset-relative artifact references are stored. Resolution is constrained to the dataset directory.

**Status:** FIXED.

---

## 3. Internal replay audit

Main-v2 was exercised offline using the 60 previously captured live Main-v1 runs. This replay was used only for software and mechanism audit; it is not a new independent experiment.

### Build

```text
base captures     60
invalid captures   0
records           305
```

### Dataset audit

`AUDIT_REPORT_V2.json`: **PASS**

Checks passing:

- oracle leak free;
- record/oracle IDs match;
- artifact paths are relative;
- expected valid/corrupted artifact semantics match actual hashes;
- derived features reproduce exactly from raw state/evidence;
- risk scores reproduce exactly from features;
- strict structural target continuity is enforced;
- correlated support is represented at evidence/provenance-object level;
- soft conflict is represented as evidence rather than a direct score mutation;
- challenge rows are excluded from formal certification;
- at most one formal row exists per independent group;
- intermediate risk values are present;
- calibration implementation can differ from a fixed threshold.

### Results audit

`RESULT_AUDIT_V2.json`: **PASS**

The replay correctly reports:

```text
formal_eligible_groups = 0
```

because internal controlled benchmarks are intentionally marked `independence_eligible=false`. No formal α certificate is produced from repeated internal cases.

---

## 4. Mechanism replay observations

These are audit observations, not publication-level claims.

Using the prior 60 captures:

```text
validator_accept     FCR 0.2105   unsafe 235
strict structural    FCR 0.1667   unsafe 45
fixed naive          FCR 0.1667   unsafe 45
fixed provenance     FCR 0.0000   unsafe 30
```

The remaining fixed-provenance unsafe promotions are concentrated in intermediate epistemic states such as `age_18h_unknown_state` and `soft_conflict`, which is intentional: Main-v2 needs nontrivial threshold-selection regimes rather than a perfectly separable challenge set.

---

## 5. Test audit

### Experiment-focused regression

```text
90 passed
```

This set included:

- Main-v2 experiment tests;
- FindingConfirmationService tests;
- proof obligations;
- evidence quality/alignment;
- ProofBundle validation;
- SQLi/IDOR/SSRF/auth-bypass/SSTI/XSS validator tests;
- release-secret-scanner tests.

### Broader repository regression

A broader repository run reached pre-existing/unrelated failures:

1. `tests/test_pentest_ai_cli.py` — conflicting `run` subparser registration.
2. `tests/test_run_benchmark.py` — test hard-codes exactly 10 benchmark directories, while the repository contains 16 after negative-control expansion.
3. `tests/test_smb_posture_check.py` — expected `null_session_allowed` key is absent in the closed-port result schema.

After excluding these known unrelated failures, the broader run progressed through approximately 80% of the suite without another failure before the execution time limit.

These failures were not modified or hidden because they are outside Main-v2's research path.

---

## 6. Environment limitation

Strict live preflight could not pass in the audit container because the container does not provide:

```text
docker
flask
selenium
```

The strict preflight correctly fails closed in that environment. The user must obtain a `PASS` from `preflight.py --require-live-deps` before a new live experiment.

---

## 7. Formal-risk audit rule

Main-v2 may report `CERTIFIED` only when:

- formal groups are explicitly independence-eligible;
- each formal group contributes at most one natural record;
- tune/certify/test group roles do not overlap;
- the exact one-sided upper risk bound on the certification split is ≤ α;
- the number of independent promoted certification groups meets the configured minimum.

For primary α=.10, the minimum is 30 independent certification confirmations. Since tuning requires a separate adequate set, approximately 80–100+ independent groups should be planned, depending on confirmation coverage.

---

## 8. Audit conclusion

**Main-v2 release decision: PASS WITH DOCUMENTED ENVIRONMENT LIMITATION.**

The research-specific package is suitable for the next experiment stage. It does **not** yet contain publication-level external independent scenarios and therefore must not be interpreted as providing a formal α=.10 guarantee until those groups are added and `formal_certificates.json` reports `CERTIFIED`.
