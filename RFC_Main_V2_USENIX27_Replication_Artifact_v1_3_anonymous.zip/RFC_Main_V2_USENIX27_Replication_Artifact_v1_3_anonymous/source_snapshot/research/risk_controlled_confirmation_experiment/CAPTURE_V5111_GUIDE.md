# RFC Main-V2 Auto-Capture V5.1.1 Correction Guide

V5.1.1 is a small correction layer on top of audited V5.1. It does not change
candidate discovery, split assignment, formal calibration, oracle semantics, or
existing experimental data.

## Corrections

1. **Benchmark fixture preconditions**
   Explicit responses such as `Feature type ... unknown`, `No such workspace`,
   or `workspace ... not found` are classified as
   `APPLICATION_PRECONDITION_FAILED`. Such captures are infrastructure-invalid
   and are not exported into the external formal bundle.

2. **Category-scoped DB-error features**
   `db_backend_error` / `db_error` are populated only while replaying SQLi
   scenarios. Non-SQLi categories can no longer acquire a database-error feature
   merely because unrelated application HTML contains database vocabulary.

3. **Reserved SSRF callback port**
   Target Docker host ports are restricted to `127.0.0.1:9000-9998`.
   Port `9999` is reserved exclusively for the local nonce-correlated SSRF
   callback service. If 9999 cannot be bound on the Docker gateway, the SSRF job
   fails closed rather than silently using another callback port.

## Apply

From the patch directory:

```bash
python main_v2_capture_patch_v5_1_1/apply_patch.py \
  --repo ~/paper/pentest_Research_GroupA/main_test_V2 \
  --check
```

Then:

```bash
python main_v2_capture_patch_v5_1_1/apply_patch.py \
  --repo ~/paper/pentest_Research_GroupA/main_test_V2
```

## Regression run

Do not change the five smoke scenarios. Re-run the same V5.1 set:

```bash
cd ~/paper/pentest_Research_GroupA/main_test_V2
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh --limit 5
```

Expected qualitative behavior:

- SQLi-010: remains excluded for authentication precondition failure.
- SQLi-011: remains evidentiary-valid if backend SQL evidence reproduces.
- SQLi-012: remains evidentiary-valid if backend PostgreSQL evidence reproduces.
- SQLi-014: missing GeoServer workspace/feature fixture becomes
  `APPLICATION_PRECONDITION_FAILED` and is excluded from export.
- SSRF-002: local callback confirmation remains usable; generic DB-error flags
  must remain false for the SSRF HTTP observation.

The run should report target host-port policy ending at 9998, while SSRF callback
metadata should report port 9999.
