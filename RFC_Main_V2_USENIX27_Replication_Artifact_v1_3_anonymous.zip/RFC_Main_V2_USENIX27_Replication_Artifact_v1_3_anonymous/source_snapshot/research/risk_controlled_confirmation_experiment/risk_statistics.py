from __future__ import annotations
from math import sqrt


def cp_upper(k: int, n: int, delta: float = 0.05) -> float:
    if n <= 0:
        return 1.0
    if k >= n:
        return 1.0
    if k == 0:
        return 1.0 - delta ** (1.0 / n)
    try:
        from scipy.stats import beta
        return float(beta.ppf(1 - delta, k + 1, n - k))
    except Exception:
        z = 1.6448536269514722 if abs(delta - 0.05) < 1e-9 else 1.96
        ph = k / n
        den = 1 + z * z / n
        center = (ph + z * z / (2 * n)) / den
        half = z * sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
        return min(1.0, center + half)


def exact_selective_certificate(errors: int, confirmations: int, *, delta: float = 0.05) -> dict:
    upper = cp_upper(errors, confirmations, delta)
    return {
        'errors': errors,
        'confirmations': confirmations,
        'empirical_risk': (errors / confirmations) if confirmations else None,
        'upper': upper,
        'delta': delta,
    }
