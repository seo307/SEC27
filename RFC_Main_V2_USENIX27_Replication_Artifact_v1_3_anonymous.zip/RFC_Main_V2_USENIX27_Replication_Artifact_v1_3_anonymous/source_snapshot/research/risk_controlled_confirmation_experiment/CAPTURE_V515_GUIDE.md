# RFC/Main-V2 V5.1.5 — Independent Certify Batch Expansion

## Scope

This patch does not change the structural ProofBundle gate, risk gate, oracle labels, split assignments, FCR definition, formal independence rule, or accepted-environment registry semantics.

It opens exactly three predeclared **certify / positive-confirmable** public-benchmark environments using read-only evidence:

1. `RFCEXT-auth_bypass-009` — DataEase CVE-2024-56511
   - control: direct anonymous GET to the protected datasource-types endpoint;
   - candidate: the source-documented `--path-as-is` whitelist-traversal GET;
   - runtime preserves the literal `/geo/../...` request path instead of letting the HTTP client normalize it;
   - the source's post-auth RCE chaining example remains rejected by the proof-only safety filter.

2. `RFCEXT-auth_bypass-011` — HugeGraph CVE-2024-43441
   - candidate: source-documented read-only `GET /graphs` with the public benchmark default-secret JWT;
   - control: the exact same request with the documented Authorization header removed;
   - no command execution or graph mutation is performed.

3. `RFCEXT-auth_bypass-013` — InfluxDB CVE-2019-20933
   - candidate: source-documented empty-secret JWT request executing read-only `show users`;
   - control: the exact same request with Authorization removed;
   - no database mutation is performed.

## Scientific acceptance rule

A positive-confirmable auth-bypass row can be confirmed only when:

- control and candidate are bound to the same normalized protected endpoint;
- the control is denied/non-successful;
- the candidate reaches a 2xx result without login/precondition failure;
- the candidate credential provenance is one of the predeclared benchmark bypass kinds, or the DataEase candidate uses no credential and the literal traversal path is observed on the wire;
- proof obligations remain evidence-bound.

A target startup failure, application precondition failure, protocol mismatch, or incomplete pair contributes formal N += 0.

## Run

First ensure the scientifically accepted registry contains all groups already approved by manual scientific review. Do not auto-register structural exports.

Then run:

```bash
research/risk_controlled_confirmation_experiment/run_external_certify_batch_v515.sh
```

The wrapper invokes the normal immutable pipeline with:

```text
--only-new
--groups RFCEXT-auth_bypass-009,RFCEXT-auth_bypass-011,RFCEXT-auth_bypass-013
```

After completion, review each exported row scientifically before using `environment_registry.py record --accept-group ...`.
