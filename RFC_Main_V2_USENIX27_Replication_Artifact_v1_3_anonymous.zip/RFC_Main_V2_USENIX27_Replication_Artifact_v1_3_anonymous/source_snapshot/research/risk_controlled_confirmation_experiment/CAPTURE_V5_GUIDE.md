# RFC Main-V2 Auto-Capture v5 — Runtime Reliability

V5 keeps the V4 catalog/classification and formal-independence rules and changes
only the local capture runtime.

## Host-port policy

All Docker-published host ports are remapped to **127.0.0.1:9000–9999**. The
container-side target port is preserved. The runner scans upward from 9000 and
skips host ports already in use. Port ranges outside 9000–9999 are rejected.

Optional explicit bounds (still within the 9000s):

```bash
PYTHONPATH=. python research/risk_controlled_confirmation_experiment/run_local_documented_capture.py \
  --screened-jobs research/risk_controlled_confirmation_experiment/external/screened_capture_jobs.jsonl \
  --sources-root research/risk_controlled_confirmation_experiment/external/sources \
  --output-dir research/risk_controlled_confirmation_experiment/external/acquired_raw \
  --limit 5 \
  --host-port-start 9000 \
  --host-port-end 9999
```

The normal pipeline uses these defaults automatically:

```bash
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh --limit 5
```

## Scientific capture validity

V5 distinguishes:

- `CAPTURE_OK`: required documented observations were acquired.
- `CAPTURE_PARTIAL`: an ambiguous-positive scenario acquired at least one direct
  observation but some optional/documented requests failed.
- `CAPTURE_INVALID`: evidence was absent or a positive-confirmable recipe was
  incomplete.
- `TARGET_NOT_READY`: the Docker port existed but the HTTP service did not become
  responsive before the readiness deadline.
- `RUN_ERROR`: Docker/runner failure.
- `EXCLUDED_UNSAFE_RECIPE`: the documented request exceeded proof-only scope.

Only top-level `status=OK` records are exported into the formal external bundle.

## Proof-only execution

The automatic runner does not execute documented requests that write files,
change database/schema state, install/persist code, execute shell commands, use
`gopher://`, or otherwise exceed evidence-only verification. Such recipes stay
available as documentation provenance but are not executed automatically.

## Reproducibility metadata

Each raw result records the assigned 9000-range host ports, host architecture,
Docker server architecture when available, Compose service state/health, and
whether Docker reported a platform mismatch/emulation warning.
