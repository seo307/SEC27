from __future__ import annotations
from common import parse_ts
from provenance import provenance_features


def _decision_time(record: dict):
    return parse_ts(record['decision_context']['decision_time'])


def _age_hours(record: dict, evs: list[dict]) -> float:
    if not evs:
        return 1e9
    decision = _decision_time(record)
    ages = []
    for e in evs:
        ts = e.get('captured_at') or e.get('timestamp')
        if ts:
            ages.append(max(0.0, (decision - parse_ts(ts)).total_seconds() / 3600.0))
    return max(ages) if ages else 1e9


def _continuity(record: dict, evs: list[dict]) -> bool:
    ctx = record['decision_context']
    target = ctx['target_id']
    deployment = ctx['deployment_id']
    return all(e.get('target_id') == target and e.get('deployment_id') == deployment for e in evs)


def extract_features(record: dict) -> dict:
    evs = record['direct_evidences']
    vr = record['validator_result']
    prov = provenance_features(evs)
    redirect_to_login = any(bool(e.get('value', {}).get('redirected_to_login')) for e in evs)
    redirect_count = sum(len(e.get('value', {}).get('redirect_chain') or []) for e in evs)
    state = record.get('state_context') or {}
    return {
        'validator_confidence': float(vr.get('confidence', 0.0)),
        'validator_status': vr.get('status', 'unknown'),
        'limitation_count': len(vr.get('limitations') or []),
        'direct_evidence_count': len(evs),
        **prov,
        'redirect_to_login': redirect_to_login,
        'redirect_count': redirect_count,
        'evidence_age_hours': round(_age_hours(record, evs), 6),
        'target_continuity_verified': _continuity(record, evs),
        'artifact_integrity': bool(record.get('artifact_integrity_observed', True)),
        'formal_contradiction_count': len(record.get('contradictions') or []),
        'soft_conflict_count': prov['contradictory_root_count'],
        'proof_obligation_fraction': float(record.get('proof_obligation_fraction', 1.0)),
        'state_observability': state.get('observability', 'known'),
        'known_remediation': bool(state.get('known_remediation', False)),
    }


def score_provenance_aware(f: dict) -> float:
    r = max(0.0, 1.0 - f['validator_confidence'])
    r += min(0.24, 0.08 * f['limitation_count'])
    if f['validator_status'] == 'probable':
        r += 0.12
    elif f['validator_status'] not in {'confirmed', 'validated', 'pass'}:
        r += 0.30

    # Provenance independence, not tool-name count.
    if f['independent_root_count'] < 1:
        r += 0.22
    elif f['independent_root_count'] == 1:
        r += 0.06
    if f['dependency_edge_count'] and f['independent_root_count'] <= 1:
        r += 0.02

    age = f['evidence_age_hours']
    if age > 48:
        r += min(0.45, 0.20 + 0.006 * (age - 48))
    elif age > 24:
        r += min(0.24, 0.12 + 0.005 * (age - 24))
    elif age > 1:
        r += min(0.14, 0.006 * (age - 1))

    if not f['target_continuity_verified']:
        r += 0.45
    if not f['artifact_integrity']:
        r += 0.60
    if f['formal_contradiction_count']:
        r += min(0.7, 0.35 * f['formal_contradiction_count'])
    if f['soft_conflict_count']:
        r += min(0.30, 0.18 * f['soft_conflict_count'])
    if f['redirect_to_login']:
        r += 0.35
    if f['state_observability'] == 'unknown':
        r += 0.08
    if f['known_remediation']:
        r += 0.30
    r += max(0.0, 1.0 - f['proof_obligation_fraction']) * 0.25
    return round(min(1.0, r), 6)


def score_naive_toolcount(f: dict) -> float:
    r = max(0.0, 1.0 - f['validator_confidence']) + min(0.2, 0.06 * f['limitation_count'])
    r -= min(0.18, 0.06 * max(0, f['nominal_tool_count'] - 1))
    return round(max(0.0, min(1.0, r)), 6)
