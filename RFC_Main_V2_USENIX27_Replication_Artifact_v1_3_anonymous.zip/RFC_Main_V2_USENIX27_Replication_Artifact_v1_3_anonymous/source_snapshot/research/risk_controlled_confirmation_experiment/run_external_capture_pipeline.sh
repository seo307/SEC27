#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
EXT="$HERE/external"
SOURCES="$EXT/sources"
RECIPES="$EXT/acquisition_recipes.jsonl"
PLAN="$EXT/populated_group_plan_120.csv"
RUN_ID="${RFC_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-$$}"
RUN="$EXT/runs/$RUN_ID"
SCREENED="$RUN/screened_capture_jobs.jsonl"
RAW="$RUN/acquired_raw"
CAP="$RUN/captures_blinded.jsonl"
ORA="$RUN/oracle.jsonl"
LEDGER="$RUN/acquisition_ledger.json"
SUMMARY="$RAW/acquisition_summary.json"
LIMIT_ARGS=()
if [[ "${1:-}" == "--limit" ]]; then LIMIT_ARGS=(--limit "${2:?limit value required}"); fi
mkdir -p "$RUN" "$RAW"
python - <<PY
import json
from pathlib import Path
p=Path(r'''$EXT''')/'latest_run.json'
p.parent.mkdir(parents=True,exist_ok=True)
run_id=r'''$RUN_ID'''
p.write_text(json.dumps({'run_id':run_id,'path':'runs/'+run_id},indent=2))
PY
# Informational only: a blocked corporate egress path must not be counted as a
# model/validator failure.  Capture the state before launching benchmark jobs.
PYTHONPATH="$ROOT" python "$HERE/network_preflight.py" --output "$RUN/network_preflight.json" || true
PYTHONPATH="$ROOT" python "$HERE/screen_capture_jobs.py" --recipes "$RECIPES" --sources-root "$SOURCES" --output "$SCREENED" --summary "$RUN/screen_summary.json"
set +e
PYTHONPATH="$ROOT" python "$HERE/run_local_documented_capture.py" --screened-jobs "$SCREENED" --sources-root "$SOURCES" --output-dir "$RAW" --run-id "$RUN_ID" "${LIMIT_ARGS[@]}"
CAPTURE_RC=$?
set -e
# Export only if a summary was produced; exporter itself is manifest/run-id bound
# and will refuse stale raw files.
if [[ -f "$SUMMARY" ]]; then
  PYTHONPATH="$ROOT" python "$HERE/export_external_bundle.py" --plan "$PLAN" --screened-jobs "$SCREENED" --raw-dir "$RAW" --run-summary "$SUMMARY" --captures "$CAP" --oracle "$ORA" --ledger "$LEDGER"
  # Empty bundles still fail validation by design.  Preserve that signal but keep
  # all run diagnostics under the immutable RUN directory.
  set +e
  PYTHONPATH="$ROOT" python "$HERE/validate_external_bundle.py" --captures "$CAP" --oracle "$ORA" > "$RUN/bundle_validation.json"
  VALIDATE_RC=$?
  set -e
else
  VALIDATE_RC=2
fi
python - <<PY
import hashlib,json,platform
from pathlib import Path
run=Path(r'''$RUN''')
def sha(p):
    p=Path(p)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
obj={
 'run_id':r'''$RUN_ID''',
 'capture_returncode':$CAPTURE_RC,
 'validation_returncode':$VALIDATE_RC,
 'host_machine':platform.machine(),
 'inputs':{
   'recipes_sha256':sha(r'''$RECIPES'''),
   'plan_sha256':sha(r'''$PLAN'''),
   'screened_jobs_sha256':sha(r'''$SCREENED'''),
 },
 'outputs':{
   'acquisition_summary_sha256':sha(r'''$SUMMARY'''),
   'captures_sha256':sha(r'''$CAP'''),
   'oracle_sha256':sha(r'''$ORA'''),
   'ledger_sha256':sha(r'''$LEDGER'''),
 }
}
(run/'run_manifest.json').write_text(json.dumps(obj,indent=2,sort_keys=True))
print(json.dumps({'run_id':obj['run_id'],'run_dir':str(run),'capture_returncode':obj['capture_returncode'],'validation_returncode':obj['validation_returncode']},indent=2))
PY
if [[ "$CAPTURE_RC" -ne 0 ]]; then exit "$CAPTURE_RC"; fi
exit "$VALIDATE_RC"
