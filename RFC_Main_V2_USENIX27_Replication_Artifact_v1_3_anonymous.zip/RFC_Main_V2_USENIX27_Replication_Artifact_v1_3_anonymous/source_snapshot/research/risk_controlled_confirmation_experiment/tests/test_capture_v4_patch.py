from __future__ import annotations
import csv,json,sys,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))

import discover_public_candidates as disc
import screen_capture_jobs as screen
from validate_external_bundle import validate


def test_classification_ignores_reference_chaining_contamination():
    text='''# CMS Made Simple Unauthenticated SQL Injection (CVE-2019-9053)\n\nAffected by SQL injection. Combining the authenticated SSTI issue CVE-2021-26120 could lead to RCE.\n\nReferences:\n- https://example.invalid/ssti\n\n## Exploit\nUse SQL injection to expose the administrator password.\n'''
    cats=disc.classify('cmsms/CVE-2019-9053',text)
    by={x['category']:x for x in cats}
    assert 'sqli' in by
    assert by['sqli']['primary_category'] is True
    assert 'ssti' not in by or by['ssti']['primary_category'] is False


def test_primary_category_for_auth_bypass_leading_to_secondary_ssrf():
    text='''# Apache Dashboard Unauthenticated Access Leads to RCE (CVE-2021-45232)\nAuthentication middleware can be bypassed. This can lead to request unexpected URL (SSRF).\n## Exploit\nUnauthenticated migrate endpoints permit importing configuration and can lead to SSRF.\n'''
    cats=disc.classify('apisix/CVE-2021-45232',text)
    by={x['category']:x for x in cats}
    assert by['auth_bypass']['primary_category'] is True
    if 'ssrf' in by:
        assert by['ssrf']['primary_category'] is False


def test_direct_url_sql_pair_parser():
    text='''# Django SQL Injection\n## Vulnerability Reproduction\nVisit http://your-ip:8000/?date=minute as the control.\nThen use http://your-ip:8000/?date=xxxx'xxxx to trigger a SQL error.\n'''
    specs=screen.extract_specs(text)
    assert len(specs)>=2
    grade,_,selected=screen._grade('sqli',specs,text)
    assert grade=='full'
    assert len(selected)==2
    assert {s['source'] for s in selected}=={'direct_url'}


def test_raw_http_parser_and_auth_session_labels():
    text='''# Auth bypass\n## Exploit\n```http\nGET /admin HTTP/1.1\nHost: your-ip:8080\nCookie: session=abc\n\n```\n```http\nGET /admin HTTP/1.1\nHost: your-ip:8080\n\n```\n'''
    specs=screen.extract_specs(text)
    assert len(specs)==2
    assert {s['session_key'] for s in specs}=={'authenticated','anonymous'}
    grade,_,selected=screen._grade('auth_bypass',specs,text)
    assert grade=='full' and len(selected)==2


def test_environment_fingerprint_is_category_independent():
    env=disc.sha('repo','apisix/CVE','CVE-2021-45232')
    assert disc.sha(env,'ssrf') != disc.sha(env,'auth_bypass')
    assert env==disc.sha('repo','apisix/CVE','CVE-2021-45232')


def test_external_validator_rejects_reused_environment_fingerprint():
    captures=[];oracle=[]
    for i,cat in enumerate(['sqli','ssrf'],1):
        cid=f'C{i}';captures.append({'capture_id':cid,'case_id':cid,'category':cat,'pair_id':cat,'group_id':cid,'source_class':'public_cve_container','result':{}})
        oracle.append({'capture_id':cid,'case_id':cid,'category':cat,'pair_id':cat,'group_id':cid,'source_class':'public_cve_container','independence_eligible':True,'vulnerable':True,'ideal_decision':'confirm','split_role':'certify','oracle_source':'public advisory','oracle_independent_of_validator':True,'scenario_fingerprint':f's{i}','environment_fingerprint':'same-env','independence_basis':'distinct public env claimed'})
    rep=validate(captures,oracle)
    assert rep['status']=='FAIL'
    assert any('environment_fingerprint repeated' in e for e in rep['errors'])
