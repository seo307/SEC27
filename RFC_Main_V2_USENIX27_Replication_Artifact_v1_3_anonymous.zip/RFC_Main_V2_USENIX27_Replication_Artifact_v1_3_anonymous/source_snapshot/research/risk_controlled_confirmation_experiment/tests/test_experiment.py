from pathlib import Path
import json, sys
HERE=Path(__file__).resolve().parents[1]; ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE)); sys.path.insert(0,str(ROOT))
from risk_statistics import cp_upper, exact_selective_certificate
from risk_score import score_provenance_aware, score_naive_toolcount, extract_features
from proof_adapter import derive_obligations
from provenance import duplicate_correlated_evidence, normalize_evidence
from calibration_sanity import run as calibration_sanity


def _features(**kw):
    f={'validator_confidence':.9,'validator_status':'confirmed','limitation_count':0,'direct_evidence_count':1,
       'nominal_tool_count':1,'distinct_family_count':1,'independent_root_count':1,'independent_support_score':1.0,
       'dependency_edge_count':0,'contradictory_root_count':0,'duplicate_observation_count':0,
       'redirect_to_login':False,'redirect_count':0,'evidence_age_hours':0,'target_continuity_verified':True,
       'artifact_integrity':True,'formal_contradiction_count':0,'soft_conflict_count':0,'proof_obligation_fraction':1.0,
       'state_observability':'known','known_remediation':False}
    f.update(kw); return f


def test_cp_zero_error_needs_many_independent_confirmations():
    assert cp_upper(0,10,0.05)>0.2
    assert cp_upper(0,30,0.05)<0.1


def test_exact_certificate_reports_empirical_and_upper():
    c=exact_selective_certificate(0,30,delta=.05)
    assert c['empirical_risk']==0
    assert c['upper']<.1


def test_intermediate_staleness_is_monotonic():
    b=_features(evidence_age_hours=0); six=_features(evidence_age_hours=6); eighteen=_features(evidence_age_hours=18,state_observability='unknown'); stale=_features(evidence_age_hours=72,known_remediation=True)
    assert score_provenance_aware(b)<score_provenance_aware(six)<score_provenance_aware(eighteen)<score_provenance_aware(stale)


def test_correlated_duplication_is_object_level_and_fools_naive_only():
    ev=normalize_evidence({'id':'E1','source_tool':'curl','timestamp':'2026-01-01T00:00:00Z','target_id':'T1','value':{}})
    dup=duplicate_correlated_evidence([ev],copies_per_source=2)
    rec={'direct_evidences':dup,'validator_result':{'confidence':.9,'status':'confirmed','limitations':[]},'decision_context':{'decision_time':'2026-01-01T00:00:00Z','target_id':'T1','deployment_id':'deployment:T1'},'state_context':{'observability':'known','known_remediation':False},'artifact_integrity_observed':True,'contradictions':[],'proof_obligation_fraction':1.0}
    for e in rec['direct_evidences']: e['deployment_id']='deployment:T1'
    f=extract_features(rec)
    assert f['nominal_tool_count']==3
    assert f['independent_root_count']==1
    assert f['dependency_edge_count']==2
    base=_features()
    naive_dup=dict(base,nominal_tool_count=3)
    assert score_naive_toolcount(naive_dup)<score_naive_toolcount(base)


def test_auth_redirect_does_not_satisfy_protected_access():
    ev=[{'value':{'kind':'admin','status_code':200,'redirected_to_login':True}}]
    assert derive_obligations('auth_bypass',ev)==[]


def test_ssrf_callback_obligations():
    ev=[{'value':{'callback_received':True}}]
    assert len(derive_obligations('ssrf',ev))==3


def test_calibration_sanity_differs_from_fixed():
    r=calibration_sanity()
    assert r['status']=='PASS'
    assert r['calibrated_threshold'] != r['fixed_threshold']
    assert r['differing_decisions']>0


def test_blinded_config_has_no_oracle():
    cfg=json.loads((HERE/'config/experiment.json').read_text())
    assert 'vulnerable' not in json.dumps(cfg)
