from __future__ import annotations
import importlib.util,json,socket,threading,tempfile,sys
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
import yaml

HERE=Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))
import run_local_documented_capture as cap
import screen_capture_jobs as screen


def test_port_pool_stays_in_9000_range_and_skips_occupied():
    s=socket.socket();s.bind(('127.0.0.1',9000));s.listen(1)
    try:
        pool=cap.PortPool(9000,9003)
        assert pool.next()==9001
        assert pool.next()==9002
    finally:s.close()


def test_safe_compose_rewrites_host_ports_into_9000s(tmp_path):
    src=tmp_path/'docker-compose.yml'
    src.write_text(yaml.safe_dump({'services':{'a':{'image':'x','ports':['8000:80']},'b':{'image':'y','ports':['127.0.0.1:8080:8080']}}}))
    out,assigned=cap.prepare_safe_compose(src,cap.PortPool(9000,9010),return_assignments=True)
    data=yaml.safe_load(out.read_text())
    ports=[p for svc in data['services'].values() for p in svc['ports']]
    assert all(p.startswith('127.0.0.1:90') for p in ports)
    assert {x['target_port'] for x in assigned}=={80,8080}
    assert all(9000<=x['host_port']<=9999 for x in assigned)


def test_rewrite_url_uses_9000_host_port():
    u=cap.rewrite_url('http://your-ip:8000/admin?q=1',[(8000,9007)])
    assert u=='http://127.0.0.1:9007/admin?q=1'


def test_proof_only_rejects_state_mutating_sqli():
    spec={'method':'POST','url':'http://your-ip:10086/api/search','raw':'orderBy=3; ATTACH DATABASE /tmp/a AS x; CREATE TABLE x.t(a text)','data':[]}
    ok,reason=screen.proof_only_safe(spec)
    assert not ok and 'state-mutating' in reason


def test_proof_only_rejects_ssrf_gopher_post_exploitation():
    spec={'method':'GET','url':'http://localhost/?url=gopher://127.0.0.1:6379/_config%20set%20dir%20/etc','raw':'','data':[]}
    ok,_=screen.proof_only_safe(spec)
    assert not ok


def test_proof_only_keeps_read_only_sqli_pair():
    control={'method':'GET','url':'http://your-ip:8000/?date=minute','raw':'','data':[]}
    payload={'method':'GET','url':"http://your-ip:8000/?date=xxxx'xxxx",'raw':'','data':[]}
    assert screen.proof_only_safe(control)[0]
    assert screen.proof_only_safe(payload)[0]


def test_capture_validity_error_only_is_invalid():
    obs=[{'request_error':'connection refused'}]
    state,_,ok=cap.capture_validity('ambiguous_positive',[{}],obs,[])
    assert state=='CAPTURE_INVALID' and not ok


def test_capture_validity_positive_requires_all_requests():
    specs=[{},{}];obs=[{'status_code':200},{'request_error':'reset'}];ev=[{'id':'E1'}]
    state,reason,ok=cap.capture_validity('positive_confirmable',specs,obs,ev)
    assert state=='CAPTURE_INVALID' and not ok and '1/2' in reason


def test_capture_validity_ambiguous_one_success_is_partial():
    specs=[{},{}];obs=[{'status_code':200},{'request_error':'reset'}];ev=[{'id':'E1'}]
    state,_,ok=cap.capture_validity('ambiguous_positive',specs,obs,ev)
    assert state=='CAPTURE_PARTIAL' and ok


class H(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(404);self.end_headers();self.wfile.write(b'ready')
    def log_message(self,*args):pass


def test_readiness_accepts_any_http_response_on_documented_path():
    # Bind a free 9000-range port for a local HTTP fixture.
    port=None
    for p in range(9100,9200):
        try:
            srv=HTTPServer(('127.0.0.1',p),H);port=p;break
        except OSError:continue
    assert port is not None
    th=threading.Thread(target=srv.serve_forever,daemon=True);th.start()
    try:
        ok,meta=cap.wait_for_readiness([{'url':'http://your-ip:8000/some/path'}],[(8000,port)],timeout=3)
        assert ok and meta['responding']>=1
    finally:srv.shutdown();srv.server_close()
