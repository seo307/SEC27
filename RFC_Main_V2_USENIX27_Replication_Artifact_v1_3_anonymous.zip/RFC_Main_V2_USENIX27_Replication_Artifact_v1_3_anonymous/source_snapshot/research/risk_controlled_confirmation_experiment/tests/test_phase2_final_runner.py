from pathlib import Path
import importlib.util,json,tempfile

HERE=Path(__file__).resolve().parents[1]/'phase2'
SPEC=importlib.util.spec_from_file_location('p2final',HERE/'phase2_final_runner.py');m=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(m)

def test_catalog_has_six_p2a_and_stress_zero_n():
    c=json.loads((HERE/'config/phase2_execution_catalog.json').read_text())
    assert len(c['sources'])==6
    assert all(x['formal_n_cap']==1 for x in c['sources'])
    assert c['stress']['formal_n_cap']==0
    assert c['policy']['automatic_registry_mutation'] is False

def test_only_two_curated_live_adapters_are_claimed():
    c=json.loads((HERE/'config/phase2_execution_catalog.json').read_text())
    active=[x['source_id'] for x in c['sources'] if x['driver']!='adapter_gap']
    assert active==['P2-OWASP-JUICE-SHOP','P2-OWASP-WEBGOAT']

def test_agent_and_oracle_are_not_inferred(tmp_path):
    ex=tmp_path/'ex'; ex.mkdir()
    m.write_jsonl(ex/'phase2_execution_rows.jsonl',[{'source_id':'P2-OWASP-JUICE-SHOP','status':'CAPTURE_OK_EVIDENTIARY','environment_fingerprint':'x','method_outputs':{'validator_only_decision':'confirm','proof_gate_only_decision':'confirm','confidence_threshold_decision':'confirm','rfc_full_decision':'confirm'}}])
    class A: pass
    a=A();a.execution_dir=str(ex);a.agent_outputs=None;a.output=str(tmp_path/'out.jsonl')
    assert m.cmd_ablation_materialize(a)==2
    s=json.loads((tmp_path/'out.summary.json').read_text())
    assert s['status']=='FAIL_CLOSED'
    assert {x['field'] for x in s['missing']}=={'agent_raw_decision','oracle'}

def test_juice_driver_uses_same_endpoint_and_non_destructive_payload(monkeypatch):
    seen=[]
    class R:
        def __init__(self,status,obj): self.status_code=status;self._obj=obj;self.content=json.dumps(obj).encode();self.text=self.content.decode();self.headers={'Content-Type':'application/json'}
        def json(self): return self._obj
    class S:
        def post(self,url,json=None,**kw):
            seen.append((url,json)); return R(401,{'error':'bad'}) if len(seen)==1 else R(200,{'authentication':{'token':'t','umail':'admin@juice-sh.op'}})
    monkeypatch.setattr(m.requests,'Session',lambda:S())
    r=m.juice_shop_driver('http://127.0.0.1:9300')
    assert r['proof_valid'] is True
    assert seen[0][0]==seen[1][0]
    assert 'DELETE' not in json.dumps(seen).upper()

def test_stress_parser_never_adds_formal_n(tmp_path):
    root=tmp_path/'bench';root.mkdir();(root/'expectedresults-1.2.csv').write_text('test name,category,real vulnerability\nA,sqli,true\nB,xss,false\n')
    prep=tmp_path/'prep';prep.mkdir();m.write_json(prep/'source_plan.json',{'stress_corpus':{'source_id':'P2-OWASP-BENCHMARK-JAVA','workspace_path':str(root)}})
    class A: pass
    a=A();a.prep=str(prep);a.workspace=str(tmp_path);a.output=str(tmp_path/'s.json');a.max_cases=10
    assert m.cmd_stress(a)==0
    out=json.loads((tmp_path/'s.json').read_text());assert out['formal_n_contribution']==0 and out['sampled_cases']==2

def test_oracle_template_truth_is_blank():
    rows=[{'source_id':'P2-OWASP-JUICE-SHOP','status':'CAPTURE_OK_EVIDENTIARY','environment_fingerprint':'abc','category':'sqli'}]
    out=m.oracle_review_template(rows)
    assert len(out)==1
    assert out[0]['vulnerable'] is None
    assert out[0]['ideal_decision'] is None
    assert out[0]['oracle_source'] is None
    assert 'Do not infer' in out[0]['note']

def test_source_discovery_is_read_only_and_non_decisional(tmp_path):
    root=tmp_path/'src';root.mkdir();(root/'routes.js').write_text("router.get('/profile/:id', handler)\n")
    src={'source_id':'P2-TEST','category':'idor','discovery_terms':['profile']}
    out=m.source_discovery(src,root,max_files=10,max_hits=10)
    assert out['hits']
    assert 'proof_valid' not in out
    assert 'decision' not in out

def test_stress_blinded_output_excludes_oracle(tmp_path):
    root=tmp_path/'bench';root.mkdir();(root/'expectedresults-1.2.csv').write_text('test name,category,real vulnerability\nA,sqli,true\nB,xss,false\n')
    prep=tmp_path/'prep';prep.mkdir();m.write_json(prep/'source_plan.json',{'stress_corpus':{'source_id':'P2-OWASP-BENCHMARK-JAVA','workspace_path':str(root)}})
    class A: pass
    a=A();a.prep=str(prep);a.workspace=str(tmp_path);a.output=str(tmp_path/'s.json');a.blinded_output=str(tmp_path/'blind.jsonl');a.oracle_output=str(tmp_path/'oracle.jsonl');a.max_cases=10
    assert m.cmd_stress(a)==0
    blind=m.read_jsonl(a.blinded_output); oracle=m.read_jsonl(a.oracle_output)
    assert len(blind)==len(oracle)==2
    assert all('expected' not in x for x in blind)
    assert {x['expected'] for x in oracle}=={'true','false'}
