from pathlib import Path
import importlib.util, json

HERE=Path(__file__).resolve().parents[1]/'phase2'
SPEC=importlib.util.spec_from_file_location('fe',HERE/'final_evaluation.py');m=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(m)

def test_agent_sanitizer_removes_validator_oracle_confidence():
    x={'validator_results':[{'status':'confirmed'}],'oracle':{'vulnerable':True},'evidences':[{'confidence':.9,'value':{'status_code':200}}]}
    y=m._sanitize_agent_obj(x)
    assert not m.forbidden_paths(y)
    assert y['evidences'][0]['value']['status_code']==200

def test_proof_gate_requires_bound_evidence_ids():
    c={'result':{'rfc_capture':{'evidences':[{'id':'E1'}],'validator_results':[{'proof_obligation_evidence':{'x':['E1']}}]}}}
    d={'capture_validity':'CAPTURE_OK_EVIDENTIARY'}
    assert m.proof_gate_from_capture(c,d)[0]=='confirm'
    c['result']['rfc_capture']['validator_results'][0]['proof_obligation_evidence']={'x':['E2']}
    assert m.proof_gate_from_capture(c,d)[0]=='abstain'

def test_method_replay_matches_v54_rule_shape():
    c={'result':{'rfc_capture':{'evidences':[{'id':'E1'}],'validator_results':[{'status':'confirmed','confidence':.9,'proof_obligation_evidence':{'x':['E1']}}]}}}
    r=m.method_replay_standard(c,{'capture_validity':'CAPTURE_OK_EVIDENTIARY'},.8)
    assert r['validator_only_decision']=='confirm'
    assert r['proof_gate_only_decision']=='confirm'
    assert r['confidence_threshold_decision']=='confirm'
    assert r['rfc_full_decision']=='confirm'

def test_method_replay_abstains_when_proof_missing_even_high_confidence():
    c={'result':{'rfc_capture':{'evidences':[{'id':'E1'}],'validator_results':[{'status':'confirmed','confidence':.95,'proof_obligation_evidence':{}}]}}}
    r=m.method_replay_standard(c,{'capture_validity':'CAPTURE_OK_EVIDENTIARY'},.8)
    assert r['validator_only_decision']=='confirm' and r['confidence_threshold_decision']=='confirm'
    assert r['proof_gate_only_decision']=='abstain' and r['rfc_full_decision']=='abstain'

def test_metrics_count_ambiguous_overconfirmation():
    rows=[{'agent_raw_decision':'confirm','proof_gate_only_decision':'abstain','ideal_decision':'abstain','vulnerable':True,'scenario_kind':'ambiguous_positive'}]
    z=m._metrics(rows,'agent_raw_decision')
    assert z['false_confirmations']==0
    assert z['unsafe_promotions']==1
    assert z['unsupported_confirmations']==1
    assert z['ambiguous_positive_overconfirmations']==1

def test_join_ablation_fails_without_agent(tmp_path):
    methods=tmp_path/'m.jsonl';oracle=tmp_path/'o.jsonl';agent=tmp_path/'a.jsonl';out=tmp_path/'x.jsonl'
    m.write_jsonl(methods,[{'case_id':'C','validator_only_decision':'confirm','proof_gate_only_decision':'confirm','confidence_threshold_decision':'confirm','rfc_full_decision':'confirm'}])
    m.write_jsonl(oracle,[{'case_id':'C','vulnerable':True,'ideal_decision':'confirm','oracle_independent_of_validator':True}]);m.write_jsonl(agent,[])
    class A: pass
    a=A();a.methods=str(methods);a.oracle=str(oracle);a.agent=str(agent);a.output=str(out)
    assert m.join_ablation(a)==2

def test_exact_upper_zero_7():
    assert abs(m.exact_upper_zero(7)-0.3481636551311609)<1e-12

def test_juice_challenge_block_parser():
    txt="""- name: 'Other'\n  key: other\n- name: 'Login Admin'\n  category: 'Injection'\n  key: loginAdminChallenge\n- name: 'Next'\n"""
    b=m._find_login_challenge_block(txt)
    assert 'Login Admin' in b and 'loginAdminChallenge' in b and 'Injection' in b

def test_rules_file_has_separate_formal_certificate():
    r=json.loads((HERE/'config/final_eval_methods.json').read_text())
    assert r['formal_independence_policy']['ablation_formal_n_contribution']==0
    assert any(x['id']=='rfc_full' and 'corpus-level' in x['rule'] for x in r['methods'])

def test_agent_view_removes_trace_events():
    c={'case_id':'C','category':'sqli','result':{'rfc_capture':{'candidates':[{'candidate_id':'x'}],'evidences':[{'id':'E1','value':{'status_code':200}}],'trace_events':[{'event_type':'validator_result','data':{'status':'confirmed','confidence':.9}}]}}}
    v=m._agent_view_standard(c)
    assert 'trace_events' not in v['candidate_and_observations']
    assert not m.forbidden_paths(v)

def test_internal_stress_selects_one_repetition_and_maps_reject_to_abstain(tmp_path):
    caps=tmp_path/'c.jsonl'; ors=tmp_path/'o.jsonl'
    base={'case_id':'neg','category':'sqli','result':{'rfc_capture':{'candidates':[{'candidate_id':'x'}],'evidences':[{'id':'E1'}],'validator_results':[{'status':'confirmed','confidence':.9,'proof_obligation_evidence':{}}]}}}
    m.write_jsonl(caps,[{**base,'capture_id':'neg.r2','repetition':2},{**base,'capture_id':'neg.r1','repetition':1}])
    m.write_jsonl(ors,[{'capture_id':'neg.r1','case_id':'neg','category':'sqli','vulnerable':False,'ideal_decision':'reject'},{'capture_id':'neg.r2','case_id':'neg','category':'sqli','vulnerable':False,'ideal_decision':'reject'}])
    rows=m.collect_internal_stress(caps,ors,{'confidence_threshold':.8})
    assert len(rows)==1
    assert rows[0]['oracle']['ideal_decision']=='abstain'
    assert rows[0]['methods']['validator_only_decision']=='confirm'
    assert rows[0]['methods']['proof_gate_only_decision']=='abstain'

def test_agent_sanitizer_drops_case_identity_and_title():
    x={'case_id':'auth_bypass_neg_001','source_class':'internal_controlled','candidates':[{'title':'Seeded candidate for auth_bypass_neg_001','candidate_id':'C1'}]}
    y=m._sanitize_agent_obj(x)
    assert 'case_id' not in y and 'source_class' not in y
    assert 'title' not in y['candidates'][0]
    assert y['candidates'][0]['candidate_id']=='C1'


def test_agent_value_guard_rejects_negative_marker():
    x={'case_id':'FE-0123456789abcdef','category':'auth_bypass','evidence':{'note':'auth_bypass_neg_001'}}
    assert m.forbidden_value_paths(x)
