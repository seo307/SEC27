from __future__ import annotations
import json,socket,threading,sys
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))
import run_local_documented_capture as cap
import screen_capture_jobs as screen


def test_direct_url_preserves_balanced_parentheses():
    text="http://your-ip:8080/geoserver/ows?CQL_FILTER=1=(SELECT%20CAST((SELECT%20version())%20AS%20numeric))"
    specs=screen._direct_url_specs(text)
    assert len(specs)==1
    assert specs[0]['url'].endswith('AS%20numeric))')
    assert screen.replay_fidelity_precheck(specs[0])[0]


def test_fidelity_rejects_truncated_geoserver_like_payload():
    s={'method':'GET','url':"http://your-ip:8080/?q=1=(SELECT%20CAST((SELECT%20version(",'headers':[],'data':[]}
    ok,reason=screen.replay_fidelity_precheck(s)
    assert not ok and 'fidelity' in reason


def test_tls_inferred_from_8443_container_port():
    url,meta=cap.rewrite_url('http://your-ip:8443/path',[(8443,9000)],return_meta=True)
    assert url=='https://127.0.0.1:9000/path'
    assert meta['protocol_inferred'] is True


def test_sqli_parser_error_does_not_confirm():
    specs=[{'raw':'control'},{'raw':'payload'}]
    obs=[
        {'db_backend_error':False,'application_parser_error':False},
        {'db_backend_error':False,'application_parser_error':True},
    ]
    ev=[{'id':'E1','value':{}},{'id':'E2','value':{}}]
    st,mp,lim=cap.evaluate('sqli',specs,obs,ev,'positive_confirmable')
    assert st=='needs_manual_review' and not mp
    assert any('parser' in x for x in lim)


def test_sqli_backend_error_confirms():
    specs=[{'raw':'control'},{'raw':'payload'}]
    obs=[
        {'db_backend_error':False,'application_parser_error':False},
        {'db_backend_error':True,'application_parser_error':False},
    ]
    ev=[{'id':'E1','value':{}},{'id':'E2','value':{}}]
    st,mp,lim=cap.evaluate('sqli',specs,obs,ev,'positive_confirmable')
    assert st=='confirmed' and mp['differential_response_or_error']==['E1','E2'] and not lim


def test_auth_precondition_failure_is_not_abstention_capture():
    specs=[{},{}]
    obs=[{'status_code':302,'redirected_to_login':True},{'status_code':302,'redirected_to_login':True}]
    ev=[{'id':'E1'},{'id':'E2'}]
    state,reason,ok=cap.capture_validity('sqli','positive_confirmable',specs,obs,ev)
    assert state=='AUTH_PRECONDITION_FAILED' and not ok


def test_network_failure_classification():
    assert cap.classify_runtime_failure('temporary failure in name resolution')=='NETWORK_DEPENDENCY_UNREACHABLE'
    assert cap.classify_runtime_failure('failed to resolve source metadata for registry-1.docker.io/foo')=='REGISTRY_PULL_FAILED'


def test_ssrf_callback_query_substitution_is_explicit():
    spec={'method':'GET','url':'http://your-ip:7001/a?operator=http%3A%2F%2F127.0.0.1%3A7001','headers':[],'data':[],'raw':'x'}
    out,changes=cap._replace_ssrf_values(spec,'http://172.18.0.1:9999/rfc/abc')
    assert changes and '172.18.0.1%3A9999' in out['url']
    assert 'controlled_local_ssrf_callback_substitution' in out['allowed_transformations']


class Warm(BaseHTTPRequestHandler):
    count=0
    def do_GET(self):
        type(self).count+=1
        self.send_response(200);self.end_headers()
        if type(self).count<3:self.wfile.write(b'<h2>Deploying Application</h2> application is deployed on the first access')
        else:self.wfile.write(b'ready')
    def log_message(self,*args):pass


def test_readiness_does_not_accept_warmup_page():
    port=None
    for p in range(9200,9250):
        try:srv=HTTPServer(('127.0.0.1',p),Warm);port=p;break
        except OSError:continue
    assert port
    th=threading.Thread(target=srv.serve_forever,daemon=True);th.start()
    try:
        ok,meta=cap.wait_for_readiness([{'url':'http://your-ip:8000/x'}],[(8000,port)],timeout=5)
        assert ok and meta['warmup_responses']>=2 and meta['attempts']>=3
    finally:srv.shutdown();srv.server_close()


def test_export_rejects_stale_run(tmp_path):
    import csv,subprocess
    plan=tmp_path/'plan.csv';screened=tmp_path/'screened.jsonl';rawdir=tmp_path/'raw';rawdir.mkdir();summary=rawdir/'acquisition_summary.json'
    fields=['group_id','case_id','category','pair_id','source_class','split_role','oracle_source','oracle_independent_of_validator','scenario_fingerprint','environment_fingerprint','finding_fingerprint','independence_basis','software_product','software_version','target_state_id','planned_vulnerable','planned_ideal_decision','scenario_kind']
    row={k:'' for k in fields};row.update({'group_id':'G1','case_id':'G1','category':'sqli','pair_id':'sqli','source_class':'public','split_role':'test','oracle_source':'fixture','oracle_independent_of_validator':'true','scenario_fingerprint':'s1','environment_fingerprint':'e1','finding_fingerprint':'f1','independence_basis':'fixture','software_product':'x','software_version':'1','target_state_id':'t','planned_vulnerable':'true','planned_ideal_decision':'confirm','scenario_kind':'positive_confirmable'})
    with plan.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerow(row)
    screened.write_text(json.dumps({'group_id':'G1','preexecution_automatable':True,'documentation_grade':'full'})+'\n')
    summary.write_text(json.dumps({'run_id':'RUN-NEW','rows':[{'group_id':'G1'}]}))
    (rawdir/'G1.json').write_text(json.dumps({'run_id':'RUN-OLD','status':'OK','capture_validity':'CAPTURE_OK_EVIDENTIARY','result':{'status':'ok','rfc_capture':{'validation_records':[{'validator_result':{'status':'confirmed'}}]}}}))
    caps=tmp_path/'caps.jsonl';ora=tmp_path/'ora.jsonl';ledger=tmp_path/'ledger.json'
    cmd=[sys.executable,str(HERE/'export_external_bundle.py'),'--plan',str(plan),'--screened-jobs',str(screened),'--raw-dir',str(rawdir),'--run-summary',str(summary),'--captures',str(caps),'--oracle',str(ora),'--ledger',str(ledger)]
    p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0
    assert caps.read_text()=='' and ora.read_text()==''
    assert json.loads(ledger.read_text())['rows'][0]['status']=='STALE_RUN_REJECTED'


def test_local_callback_records_nonce_receipt():
    import requests,hashlib
    port=None
    for p in range(9950,9999):
        try:
            cb=cap.CallbackRecorder('127.0.0.1',p,'nonce123').start();port=p;break
        except OSError:continue
    assert port
    try:
        r=requests.get(f'http://127.0.0.1:{port}/rfc/nonce123',timeout=2)
        assert r.status_code==200 and 'nonce123' in r.text
        for _ in range(20):
            if cb.receipts:break
            import time;time.sleep(.02)
        assert cb.receipts and cb.receipts[0]['nonce_present'] is True
    finally:cb.close()
