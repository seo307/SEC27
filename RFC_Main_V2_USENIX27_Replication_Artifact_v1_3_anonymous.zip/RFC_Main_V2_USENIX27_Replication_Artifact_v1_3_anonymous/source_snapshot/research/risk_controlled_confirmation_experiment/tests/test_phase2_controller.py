import importlib.util, json
from pathlib import Path

P=Path(__file__).resolve().parents[1]/'phase2'/'phase2_controller.py'
spec=importlib.util.spec_from_file_location('p2',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def test_exact_upper_zero():
    assert round(m.exact_upper_zero(7,.05),6)==round(1-.05**(1/7),6)

def test_catalog_caps_independence():
    c=m.read_json(P.parent/'config'/'phase2_source_catalog.json')
    assert len(c['sources'])==6
    assert sum(x['formal_n_cap'] for x in c['sources'])==6
    assert c['stress_corpus']['formal_n_cap']==0

def test_ablation_fails_closed_on_missing(tmp_path):
    inp=tmp_path/'i.jsonl';out=tmp_path/'o.json'
    inp.write_text(json.dumps({'case_id':'x','vulnerable':True,'ideal_decision':'confirm','rfc_full_decision':'confirm'})+'\n')
    class A: pass
    a=A();a.methods=str(P.parent/'config'/'ablation_methods.json');a.input=str(inp);a.output=str(out)
    assert m.cmd_ablation(a)==2
    assert json.loads(out.read_text())['status']=='FAIL_CLOSED'

def test_ablation_metrics(tmp_path):
    inp=tmp_path/'i.jsonl';out=tmp_path/'o.json'
    base={'environment_id':'e','source_ecosystem':'s'}
    rows=[]
    for i,(v,ideal) in enumerate([(True,'confirm'),(False,'abstain')]):
        r={**base,'case_id':str(i),'vulnerable':v,'ideal_decision':ideal,
           'agent_raw_decision':'confirm','validator_only_decision':'confirm',
           'proof_gate_only_decision':ideal,'confidence_threshold_decision':'confirm','rfc_full_decision':ideal}
        rows.append(r)
    inp.write_text(''.join(json.dumps(x)+'\n' for x in rows))
    class A: pass
    a=A();a.methods=str(P.parent/'config'/'ablation_methods.json');a.input=str(inp);a.output=str(out)
    assert m.cmd_ablation(a)==0
    o=json.loads(out.read_text());idx={x['method']:x for x in o['methods']}
    assert idx['rfc_full']['false_confirmations']==0
    assert idx['agent_raw']['false_confirmations']==1
    assert o['formal_n_contribution']==0
