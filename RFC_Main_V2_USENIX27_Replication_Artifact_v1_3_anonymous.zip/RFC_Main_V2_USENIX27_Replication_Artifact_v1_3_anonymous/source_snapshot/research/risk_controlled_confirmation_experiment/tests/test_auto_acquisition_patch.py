import csv, importlib.util, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path: sys.path.insert(0, str(HERE))

def load(name):
 p=HERE/f'{name}.py'; spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def test_empty_bundle_is_fail_by_default():
 m=load('validate_external_bundle'); rep=m.validate([],[]); assert rep['status']=='FAIL'; assert any('empty' in e for e in rep['errors'])

def test_empty_bundle_can_be_allowed_for_scaffold():
 m=load('validate_external_bundle'); rep=m.validate([],[],allow_empty=True); assert rep['status']=='PASS'

def test_registry_only_preregistered_https_github():
 reg=json.loads((HERE/'source_registry.json').read_text()); assert reg['sources']
 for s in reg['sources']:
  assert s['repo_url'].startswith('https://github.com/') and s['repo_url'].endswith('.git')

def test_populator_never_reuses_candidate(tmp_path):
 plan=tmp_path/'plan.csv'; cat=tmp_path/'cat.csv'; out=tmp_path/'out.csv'; rec=tmp_path/'rec.jsonl'
 pf=['group_id','case_id','category','pair_id','split_role','scenario_kind','planned_vulnerable','planned_ideal_decision','source_class','oracle_source','oracle_independent_of_validator','independence_basis','software_product','software_version','target_state_id','scenario_fingerprint','capture_path','oracle_path','status']
 rows=[]
 for i,k in enumerate(['positive_confirmable','ambiguous_positive']):
  rows.append(dict.fromkeys(pf,'')); rows[-1].update(group_id=f'g{i}',case_id=f'g{i}',category='sqli',pair_id='sqli',split_role='tune',scenario_kind=k,planned_vulnerable='true',planned_ideal_decision='confirm' if i==0 else 'abstain')
 with plan.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=pf);w.writeheader();w.writerows(rows)
 cf=['candidate_id','category','source_name','source_url','relative_path','software_product','advisory_or_state','compose_path','readme_path','scenario_fingerprint','classification_hits','confidence','formal_independence_recommended','supports_vulnerable_modes','supports_negative_control']
 cr=[dict(candidate_id='c1',category='sqli',source_name='vulhub',source_url='https://github.com/vulhub/vulhub',relative_path='p/CVE-1',software_product='p',advisory_or_state='CVE-1',compose_path='p/CVE-1/docker-compose.yml',readme_path='p/CVE-1/README.md',scenario_fingerprint='fp1',classification_hits='sqli',confidence='high',formal_independence_recommended='true',supports_vulnerable_modes='true',supports_negative_control='false')]
 with cat.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=cf);w.writeheader();w.writerows(cr)
 import subprocess,sys
 cp=subprocess.run([sys.executable,str(HERE/'populate_external_plan.py'),'--plan',str(plan),'--catalog',str(cat),'--output-plan',str(out),'--recipes',str(rec)],capture_output=True,text=True);assert cp.returncode==0
 rr=list(csv.DictReader(out.open())); assert sum(r['status']=='ASSIGNED_PENDING_CAPTURE' for r in rr)==1; assert sum(r['status'].startswith('SHORTFALL') for r in rr)==1
