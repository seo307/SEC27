from pathlib import Path
import importlib.util,json

HERE=Path(__file__).resolve().parents[1]/'phase2'
SPEC=importlib.util.spec_from_file_location('v541',HERE/'phase2_correction_v541.py');m=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(m)

def test_benchmark_header_normalization_handles_real_file_shape(tmp_path):
    p=tmp_path/'expectedresults-1.2.csv'
    p.write_text('# test name, category, real vulnerability\nBenchmarkTest00192,sqli,true\nBenchmarkTest00193,xss,false\n')
    rows,issues=m.parse_benchmark_expected(p)
    assert not issues
    assert rows[0]['case_id']=='BenchmarkTest00192'
    assert rows[0]['category']=='sqli'
    assert rows[0]['expected'] is True
    assert rows[1]['expected'] is False

def test_stress_fails_closed_on_null_truth(tmp_path):
    root=tmp_path/'bench';root.mkdir();(root/'expectedresults-1.2.csv').write_text('# test name, category, real vulnerability\nA,sqli,\n')
    prep=tmp_path/'prep';prep.mkdir();m.write_json(prep/'source_plan.json',{'stress_corpus':{'source_id':'P2-OWASP-BENCHMARK-JAVA','workspace_path':str(root)}})
    class A: pass
    a=A();a.prep=str(prep);a.workspace=str(tmp_path);a.output=str(tmp_path/'s.json');a.blinded_output=None;a.oracle_output=None;a.max_cases=10
    assert m.cmd_stress(a)==2
    assert json.loads(Path(a.output).read_text())['status']=='FAIL_CLOSED'

def test_stress_blinding_keeps_truth_only_in_oracle(tmp_path):
    root=tmp_path/'bench';root.mkdir();(root/'expectedresults-1.2.csv').write_text('# test name, category, real vulnerability\nA,sqli,true\nB,xss,false\n')
    prep=tmp_path/'prep';prep.mkdir();m.write_json(prep/'source_plan.json',{'stress_corpus':{'source_id':'P2-OWASP-BENCHMARK-JAVA','workspace_path':str(root)}})
    class A: pass
    a=A();a.prep=str(prep);a.workspace=str(tmp_path);a.output=str(tmp_path/'s.json');a.blinded_output=str(tmp_path/'b.jsonl');a.oracle_output=str(tmp_path/'o.jsonl');a.max_cases=10
    assert m.cmd_stress(a)==0
    blind=m.read_jsonl(a.blinded_output); oracle=m.read_jsonl(a.oracle_output)
    assert all('expected' not in x for x in blind)
    assert {x['expected'] for x in oracle}=={True,False}

def test_pygoat_recipe_requires_source_grounded_select_only(tmp_path):
    root=tmp_path/'p';(root/'introduction').mkdir(parents=True)
    (root/'introduction/urls.py').write_text('from django.urls import path\nurlpatterns=[path("sql_lab",views.sql_lab,name="sql_lab")]\n')
    (root/'introduction/views.py').write_text('''def sql_lab(request):\n    name=request.POST.get("name")\n    q="SELECT * FROM users WHERE name='"+name+"'"\n    return render(request,"x.html",{})\n\ndef other(request):\n    pass\n''')
    r=m.pygoat_recipe(root)
    assert r['status']=='PASS' and r['post_fields']==['name'] and r['source_read_only_select'] is True

def test_pygoat_recipe_rejects_mutating_sql(tmp_path):
    root=tmp_path/'p';(root/'introduction').mkdir(parents=True)
    (root/'introduction/urls.py').write_text('urlpatterns=[path("sql_lab",views.sql_lab)]')
    (root/'introduction/views.py').write_text('''def sql_lab(request):\n    name=request.POST.get("name")\n    q="SELECT * FROM users"\n    x="UPDATE users SET x=1"\n''')
    assert m.pygoat_recipe(root)['status']=='FAIL_CLOSED_MUTATING_SQL_PRESENT'

def test_vulnerableapp_source_evidence_is_stress_only(tmp_path):
    p=tmp_path/'src/main/java/org/sasanlabs/service/vulnerability/sqlInjection';p.mkdir(parents=True)
    f=p/'ErrorBasedSQLInjectionVulnerability.java'
    f.write_text('''VulnerabilityType.ERROR_BASED_SQL_INJECTION\n@VulnerableAppRequestMapping(value = LevelConstants.LEVEL_1)\nString id = queryParams.get(Constants.ID);\napplicationJdbcTemplate.query("select * from cars where id=" + id, x);\n''')
    r=m.vulnerableapp_source_evidence(tmp_path)
    assert r['status']=='PASS' and r['formal_n_contribution']==0

def test_ablation_requires_separate_explicit_agent_and_oracle(tmp_path):
    ex=tmp_path/'ex';ex.mkdir()
    m.write_jsonl(ex/'phase2_correction_rows.jsonl',[{'source_id':'S','status':'CAPTURE_OK_EVIDENTIARY','environment_fingerprint':'fp','method_outputs':{'validator_only_decision':'confirm','proof_gate_only_decision':'confirm','confidence_threshold_decision':'confirm','rfc_full_decision':'confirm'}}])
    agent=tmp_path/'a.jsonl'; oracle=tmp_path/'o.jsonl'
    m.write_jsonl(agent,[{'source_id':'S','agent_raw_decision':'confirm'}])
    m.write_jsonl(oracle,[{'source_id':'S','vulnerable':True,'ideal_decision':'confirm','oracle_source':'source','oracle_independent_of_validator':True}])
    class A: pass
    a=A();a.execution_dir=str(ex);a.agent_outputs=str(agent);a.oracle_outputs=str(oracle);a.output=str(tmp_path/'out.jsonl')
    assert m.ablation_materialize(a)==0
    out=m.read_jsonl(a.output)[0]
    assert out['agent_raw_decision']=='confirm' and out['vulnerable'] is True

def test_ablation_fails_if_oracle_not_independent(tmp_path):
    ex=tmp_path/'ex';ex.mkdir();m.write_jsonl(ex/'phase2_correction_rows.jsonl',[{'source_id':'S','status':'CAPTURE_OK_EVIDENTIARY','method_outputs':{'validator_only_decision':'confirm','proof_gate_only_decision':'confirm','confidence_threshold_decision':'confirm','rfc_full_decision':'confirm'}}])
    agent=tmp_path/'a.jsonl';oracle=tmp_path/'o.jsonl';m.write_jsonl(agent,[{'source_id':'S','agent_raw_decision':'confirm'}]);m.write_jsonl(oracle,[{'source_id':'S','vulnerable':True,'ideal_decision':'confirm','oracle_source':'x','oracle_independent_of_validator':False}])
    class A: pass
    a=A();a.execution_dir=str(ex);a.agent_outputs=str(agent);a.oracle_outputs=str(oracle);a.output=str(tmp_path/'out.jsonl')
    assert m.ablation_materialize(a)==2

def test_catalog_caps_only_live_candidates(tmp_path):
    c=json.loads((HERE/'config/phase2_v541_catalog.json').read_text())
    caps={x['source_id']:x['formal_n_cap'] for x in c['sources']}
    assert caps['P2-OWASP-JUICE-SHOP']==1
    assert caps['P2-PYGOAT']==1
    assert caps['P2-OWASP-VULNERABLEAPP']==0
    assert c['policy']['automatic_registry_mutation'] is False

def _init_git(root):
    import subprocess
    subprocess.check_call(['git','init','-q',str(root)])
    subprocess.check_call(['git','-C',str(root),'config','user.email','test@example.invalid'])
    subprocess.check_call(['git','-C',str(root),'config','user.name','test'])
    (root/'tracked.txt').write_text('x')
    subprocess.check_call(['git','-C',str(root),'add','tracked.txt'])
    subprocess.check_call(['git','-C',str(root),'commit','-qm','init'])

def test_source_build_refuses_dirty_frozen_tree(tmp_path):
    root=tmp_path/'repo';root.mkdir();_init_git(root);(root/'tracked.txt').write_text('changed')
    r=m.build_source_image({'source_id':'S','dockerfile':'Dockerfile','build_context':'.'},root,timeout=1)
    assert r['status']=='FAIL_CLOSED_SOURCE_DIRTY'

def test_source_build_requires_explicit_dockerfile(tmp_path):
    root=tmp_path/'repo';root.mkdir();_init_git(root)
    r=m.build_source_image({'source_id':'S','dockerfile':'Dockerfile','build_context':'.'},root,timeout=1)
    assert r['status']=='FAIL_CLOSED_BUILD_RECIPE_MISSING'
