from __future__ import annotations
import json,hashlib
from pathlib import Path

from research.risk_controlled_confirmation_experiment import corpus_expansion_controller as cc
from research.risk_controlled_confirmation_experiment import screen_capture_jobs as sc
from research.risk_controlled_confirmation_experiment import run_local_documented_capture as rl


def _write_jsonl(p:Path,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(json.dumps(x)+'\n' for x in rows))


def test_ssrf_xml_body_annotation_requires_explicit_arbitrary_url_source():
    spec={'method':'POST','url':'http://your-ip:8080/test','headers':['Content-Type: multipart/related; boundary=x','Content-Length: 99'],'data':['<xop:Include href="file:///etc/hosts"></xop:Include>'],'raw':'POST /test','source':'raw_http'}
    spec['source_request_sha256']=hashlib.sha256(spec['raw'].encode()).hexdigest();spec['parsed_spec_sha256']=sc.spec_sha256(spec)
    yes=sc._annotate_ssrf_body_url_substitution([spec],'the server can send requests to arbitrary URLs')[0]
    no=sc._annotate_ssrf_body_url_substitution([spec],'reads a local file only')[0]
    assert yes['ssrf_body_url_substitution_allowed'] is True
    assert yes['ssrf_body_source_url_sha256']
    assert not no.get('ssrf_body_url_substitution_allowed')


def test_ssrf_xml_body_callback_replaces_source_url_and_drops_stale_content_length():
    spec={'method':'POST','url':'http://your-ip:8080/test','headers':['Content-Type: multipart/related; boundary=x','Content-Length: 99'],'data':['<xop:Include href="file:///etc/hosts"></xop:Include>'],'raw':'POST /test','source':'raw_http','ssrf_body_url_substitution_allowed':True,'allowed_transformations':['controlled_local_ssrf_body_url_callback_substitution']}
    out,changes=rl._replace_ssrf_values(spec,'http://172.18.0.1:9999/rfc/NONCE')
    assert 'file:///etc/hosts' not in out['data'][0]
    assert 'http://172.18.0.1:9999/rfc/NONCE' in out['data'][0]
    assert not any(h.lower().startswith('content-length:') for h in out['headers'])
    assert any(x.get('location')=='body_url_attribute' for x in changes)
    assert 'recompute_content_length_after_controlled_body_substitution' in out['allowed_transformations']


def test_controller_plan_excludes_registry_and_history_terminal_blockers(tmp_path:Path):
    screened=tmp_path/'screened.jsonl';registry=tmp_path/'registry.json';runs=tmp_path/'runs'
    rows=[
      {'group_id':'G-REG','category':'sqli','split_role':'certify','scenario_kind':'positive_confirmable','environment_fingerprint':'FP-REG','preexecution_automatable':True,'documentation_grade':'full','screen_reason':'ok'},
      {'group_id':'G-READY','category':'ssrf','split_role':'certify','scenario_kind':'positive_confirmable','environment_fingerprint':'FP-READY','preexecution_automatable':True,'documentation_grade':'full','screen_reason':'ok'},
      {'group_id':'G-HIST','category':'sqli','split_role':'certify','scenario_kind':'positive_confirmable','environment_fingerprint':'FP-HIST','preexecution_automatable':True,'documentation_grade':'full','screen_reason':'ok'},
      {'group_id':'G-PARSE','category':'auth_bypass','split_role':'certify','scenario_kind':'positive_confirmable','environment_fingerprint':'FP-PARSE','preexecution_automatable':False,'documentation_grade':'unsupported','screen_reason':'no conservative documented HTTP reproduction recipe found','parsed_request_count':2},
      {'group_id':'G-TUNE','category':'ssrf','split_role':'tune','scenario_kind':'positive_confirmable','environment_fingerprint':'FP-TUNE','preexecution_automatable':True,'documentation_grade':'full','screen_reason':'ok'},
    ]
    _write_jsonl(screened,rows);registry.write_text(json.dumps({'entries':{'FP-REG':{'category':'sqli'}}}))
    rd=runs/'R1'/'acquired_raw';rd.mkdir(parents=True)
    (rd/'acquisition_summary.json').write_text(json.dumps({'run_id':'R1','rows':[{'group_id':'G-HIST','capture_validity':'APPLICATION_PRECONDITION_FAILED','status':'APPLICATION_PRECONDITION_FAILED'}]}))
    class A:pass
    a=A();a.screened=str(screened);a.registry=str(registry);a.runs_root=str(runs);a.output=str(tmp_path/'plan.json');a.inventory=str(tmp_path/'inventory.jsonl');a.blocked=str(tmp_path/'blocked.jsonl');a.ready_groups=str(tmp_path/'ready.txt');a.max_batch=0;a.retry_blockers=False;a.include_noncertify=False;a.include_ambiguous=False;a.known_blockers=None
    assert cc.cmd_plan(a)==0
    plan=json.loads((tmp_path/'plan.json').read_text());inv={x['group_id']:x for x in cc.read_jsonl(tmp_path/'inventory.jsonl')}
    assert plan['ready_groups']==['G-READY']
    assert inv['G-REG']['controller_state']=='REGISTERED'
    assert inv['G-HIST']['blocker']=='HISTORY_APPLICATION_FIXTURE_REQUIRED'
    assert inv['G-PARSE']['blocker']=='PARSER_OR_ADAPTER_GAP'
    assert inv['G-TUNE']['controller_state']=='OUT_OF_PRIMARY_SCOPE'


def _capture(gid,category,validator_status='confirmed',values=None,limitations=None):
    vals=values or [{'kind':'http','status_code':401,'body_sha256':'a'},{'kind':'http','status_code':200,'body_sha256':'b'}]
    evid=[{'id':f'E{i+1}','value':v} for i,v in enumerate(vals)]
    return {'group_id':gid,'category':category,'result':{'rfc_capture':{'evidences':evid,'validator_results':[{'status':validator_status,'confidence':0.9,'limitations':limitations or [],'evidence_ids':[e['id'] for e in evid],'proof_obligation_evidence':{}}]}}}


def test_review_queue_flags_nondifferential_5xx_but_keeps_clean_confirm_candidate(tmp_path:Path):
    rd=tmp_path/'run';rd.mkdir()
    ledger={'run_id':'R','rows':[
      {'group_id':'GOOD','status':'EXPORTED','capture_validity':'CAPTURE_OK_EVIDENTIARY','validator_status':'confirmed','environment_fingerprint':'FP1','scenario_kind':'positive_confirmable'},
      {'group_id':'BAD','status':'EXPORTED','capture_validity':'CAPTURE_OK_EVIDENTIARY','validator_status':'needs_manual_review','environment_fingerprint':'FP2','scenario_kind':'positive_confirmable'},
    ]}
    (rd/'acquisition_ledger.json').write_text(json.dumps(ledger))
    _write_jsonl(rd/'oracle.jsonl',[
      {'group_id':'GOOD','category':'auth_bypass','environment_fingerprint':'FP1','split_role':'certify','ideal_decision':'confirm','vulnerable':True,'independence_eligible':True,'oracle_independent_of_validator':True},
      {'group_id':'BAD','category':'auth_bypass','environment_fingerprint':'FP2','split_role':'certify','ideal_decision':'confirm','vulnerable':True,'independence_eligible':True,'oracle_independent_of_validator':True},
    ])
    badvals=[{'kind':'http','status_code':500,'body_sha256':'same','auth_probe_role':'control'},{'kind':'http','status_code':500,'body_sha256':'same','auth_probe_role':'candidate'}]
    _write_jsonl(rd/'captures_blinded.jsonl',[_capture('GOOD','auth_bypass'),_capture('BAD','auth_bypass','needs_manual_review',badvals,['incomplete'])])
    class A:pass
    a=A();a.run_dir=str(rd);a.output=str(tmp_path/'review.jsonl');a.registry_candidates=str(tmp_path/'cand.jsonl');a.summary=str(tmp_path/'summary.json')
    cc.cmd_review(a);rows={x['group_id']:x for x in cc.read_jsonl(tmp_path/'review.jsonl')}
    assert rows['GOOD']['registry_review_candidate'] is True
    assert rows['GOOD']['formal_confirmation_candidate'] is True
    assert rows['BAD']['registry_review_candidate'] is False
    assert 'nondifferential_same_5xx_response' in rows['BAD']['review_flags']


def test_progress_uses_only_explicit_registry_and_exact_zero_error_bound(tmp_path:Path):
    reg={'entries':{}}
    runs=tmp_path/'runs';runs.mkdir()
    for i in range(30):
        gid=f'G{i:02d}';fp=f'FP{i:02d}';rid=f'R{i:02d}'
        reg['entries'][fp]={'environment_fingerprint':fp,'group_id':gid,'category':'sqli','split_role':'certify','first_accepted_run_id':rid,'scientific_status':'accepted'}
        rd=runs/rid;rd.mkdir()
        (rd/'acquisition_ledger.json').write_text(json.dumps({'run_id':rid,'rows':[{'group_id':gid,'status':'EXPORTED','capture_validity':'CAPTURE_OK_EVIDENTIARY','validator_status':'confirmed','environment_fingerprint':fp}]}))
        _write_jsonl(rd/'oracle.jsonl',[{'group_id':gid,'environment_fingerprint':fp,'split_role':'certify','category':'sqli','ideal_decision':'confirm','vulnerable':True}])
    regp=tmp_path/'registry.json';regp.write_text(json.dumps(reg));cfg=tmp_path/'cfg.json';cfg.write_text(json.dumps({'confidence_delta':0.05,'primary_alpha':0.1,'formal_min_confirmations':{'0.1':30}}))
    class A:pass
    a=A();a.registry=str(regp);a.runs_root=str(runs);a.config=str(cfg);a.output=str(tmp_path/'progress.json')
    cc.cmd_progress(a);rep=json.loads((tmp_path/'progress.json').read_text())
    assert rep['accepted_unique_environments']==30
    assert rep['certification_confirmations']==30
    assert rep['false_confirmations']==0
    assert rep['one_sided_cp_upper'] < 0.1
    assert rep['formal_certificate_ready'] is True
