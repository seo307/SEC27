from __future__ import annotations
import importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
if str(HERE) not in sys.path:sys.path.insert(0,str(HERE))
def load(name):
 p=HERE/name; s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
screen=load('screen_capture_jobs.py'); runner=load('run_local_documented_capture.py')

def test_extract_sqli_control_payload():
 text='''curl http://your-ip:8080/item?id=1\ncurl "http://your-ip:8080/item?id=1%27%20or%201=1"'''
 specs=screen._curl_specs(text);g,_,sel=screen._grade('sqli',specs,text)
 assert g=='full' and len(sel)==2

def test_xss_is_partial_without_browser():
 text='curl "http://your-ip:8080/?q=<script>alert(1)</script>"'
 specs=screen._curl_specs(text);g,_,_=screen._grade('xss',specs,text);assert g=='partial'

def test_auth_full_requires_control():
 text='''curl -H "Authorization: Bearer demo" http://localhost:8080/admin\ncurl http://localhost:8080/admin'''
 specs=screen._curl_specs(text);g,_,_=screen._grade('auth_bypass',specs,text);assert g=='full'

def test_rewrite_url_loopback():
 u=runner.rewrite_url('http://example.invalid:8080/test?q=1',[(8080,9007)])
 assert u.startswith('http://127.0.0.1:9007/test')

def test_ssti_eval_confirm():
 specs=[{'raw':'curl http://x/?q={{7*7}}','headers':[],'user':None}]
 obs=[{'body_preview':'49','status_code':200}]
 ev=[{'id':'E1'}]
 st,_,_=runner.evaluate('ssti',specs,obs,ev,'positive_confirmable');assert st=='confirmed'

def test_ambiguous_forces_manual_review():
 st,mp,lim=runner.evaluate('ssrf',[],[],[],'ambiguous_positive');assert st=='needs_manual_review' and not mp

def test_safe_compose_binds_loopback(tmp_path):
    p=tmp_path/'docker-compose.yml';p.write_text('services:\n  app:\n    image: demo\n    ports:\n      - "8080:80"\n')
    out=runner.prepare_safe_compose(p)
    txt=out.read_text();assert '127.0.0.1:9000:80/tcp' in txt

def test_safe_compose_rejects_privileged(tmp_path):
    p=tmp_path/'docker-compose.yml';p.write_text('services:\n  app:\n    image: demo\n    privileged: true\n')
    import pytest
    with pytest.raises(ValueError):runner.prepare_safe_compose(p)
