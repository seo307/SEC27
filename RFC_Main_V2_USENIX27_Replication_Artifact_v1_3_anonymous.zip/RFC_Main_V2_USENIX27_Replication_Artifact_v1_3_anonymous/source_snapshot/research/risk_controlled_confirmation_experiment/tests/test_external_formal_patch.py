from pathlib import Path
import csv, json, sys

HERE=Path(__file__).resolve().parents[1]; ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE)); sys.path.insert(0,str(ROOT))

from proof_adapter import derive_obligations
from validate_external_bundle import validate
from formal_readiness import evaluate
from common import write_jsonl, dump_json


def test_explicit_proof_obligations_require_direct_evidence_binding():
    ev=[{'id':'E1','value':{}},{'id':'E2','value':{}}]
    vr={'proof_obligation_evidence':{
        'distinct_identities_or_objects':['E1'],
        'unauthorized_resource_access':['E2'],
        'authorized_control_request':['MISSING'],
        'not_a_real_token':['E1'],
    }}
    got=derive_obligations('idor',ev,vr)
    assert got==['distinct_identities_or_objects','unauthorized_resource_access']


def _bundle(n=1, duplicate_fp=False):
    caps=[]; ors=[]
    for i in range(n):
        cid=f'C{i}'; gid=f'G{i}'; fp='same' if duplicate_fp else f'FP{i}'
        caps.append({'capture_id':cid,'case_id':cid,'category':'sqli','pair_id':'sqli','group_id':gid,'source_class':'public_benchmark','result':{'status':'ok','rfc_capture':{}}})
        ors.append({'capture_id':cid,'case_id':cid,'category':'sqli','pair_id':'sqli','group_id':gid,'source_class':'public_benchmark','independence_eligible':True,'vulnerable':True,'ideal_decision':'confirm','split_role':'certify','oracle_source':'known_vulnerable_image','oracle_independent_of_validator':True,'scenario_fingerprint':fp,'environment_fingerprint':f'ENV{i}','independence_basis':'distinct pinned image'})
    return caps,ors


def test_external_bundle_requires_unique_scenario_fingerprint():
    c,o=_bundle(2,duplicate_fp=True)
    r=validate(c,o)
    assert r['status']=='FAIL'
    assert any('scenario_fingerprint' in x for x in r['errors'])


def test_external_bundle_passes_with_required_independence_metadata():
    c,o=_bundle(1)
    r=validate(c,o)
    assert r['status']=='PASS'
    assert r['independence_eligible_groups']==1


def test_preregistered_plan_has_120_groups_and_36_certify_positives():
    p=HERE/'external_group_plan_120.csv'
    rows=list(csv.DictReader(p.open()))
    assert len(rows)==120
    assert sum(r['split_role']=='tune' for r in rows)==48
    assert sum(r['split_role']=='certify' for r in rows)==48
    assert sum(r['split_role']=='test' for r in rows)==24
    assert sum(r['split_role']=='certify' and r['scenario_kind']=='positive_confirmable' for r in rows)==36


def test_formal_readiness_uses_structural_confirmable_capacity(tmp_path):
    d=tmp_path/'dataset'; d.mkdir()
    records=[]; oracle=[]
    # 30 certify ideal-confirm groups, all structurally allowed, plus tune/test.
    spec=[('tune',5),('certify',30),('test',5)]
    i=0
    for role,n in spec:
        for _ in range(n):
            i+=1; rid=f'R{i}'
            records.append({'record_id':rid,'structural_gate':{'allowed':True}})
            oracle.append({'record_id':rid,'group_id':f'G{i}','category':'ssrf','split_role':role,'ideal_decision':'confirm','certificate_eligible':True,'independence_eligible':True,'oracle_independent_of_validator':True,'scenario_fingerprint':f'FP{i}','environment_fingerprint':f'ENV{i}'})
    write_jsonl(d/'records_blinded.jsonl',records); write_jsonl(d/'oracle.jsonl',oracle)
    cfg=tmp_path/'cfg.json'; dump_json(cfg,{'primary_alpha':0.1,'formal_min_confirmations':{'0.1':30}})
    r=evaluate(d,cfg)
    assert r['checks']['primary_certify_confirmable_capacity'] is True
