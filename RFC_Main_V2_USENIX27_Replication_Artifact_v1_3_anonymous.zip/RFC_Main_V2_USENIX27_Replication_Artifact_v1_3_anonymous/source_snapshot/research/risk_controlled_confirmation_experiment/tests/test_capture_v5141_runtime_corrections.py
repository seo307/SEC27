from __future__ import annotations

from types import SimpleNamespace

from research.risk_controlled_confirmation_experiment import run_local_documented_capture as rl


def test_installer_redirect_paths_are_application_preconditions():
    assert rl._application_precondition_redirect('http://127.0.0.1:9000/install.php')
    assert rl._application_precondition_redirect('/installation/index.php')
    assert rl._application_precondition_redirect('/setup')
    assert not rl._application_precondition_redirect('/index.php')
    assert not rl._application_precondition_redirect('/admin/login')


def test_readiness_fails_closed_on_persistent_installer_redirect(monkeypatch):
    class R:
        status_code=302
        text=''
        headers={'Location':'http://127.0.0.1:9000/install.php'}
    monkeypatch.setattr(rl.requests,'get',lambda *a,**k:R())
    monkeypatch.setattr(rl.time,'sleep',lambda *_:None)
    ready,meta=rl.wait_for_readiness([{'url':'http://your-ip:8080/'}],[(80,9000)],timeout=2)
    assert ready is False
    assert meta['explicit_application_precondition'] is True
    assert meta['application_precondition_responses']>=2
    assert meta['last_status'][-1]['application_precondition_redirect'] is True


def test_capture_validity_rejects_application_precondition_marker():
    state,reason,scientific=rl.capture_validity(
        'sqli','positive_confirmable',[{'url':'http://x/'}],
        [{'request_error':None,'application_precondition_marker':True,'redirected_to_login':False,'tls_required_marker':False,'warmup_marker':False}],
        [{'id':'E1'}],
    )
    assert state=='APPLICATION_PRECONDITION_FAILED'
    assert scientific is False
    assert 'fixture' in reason or 'required' in reason


def test_port_selection_prefers_http_application_over_jdwp_when_url_has_no_port():
    url,meta=rl.rewrite_url('http://internal/geoserver/TestWfsPost',[(5005,9003),(8080,9002)],return_meta=True)
    assert url.startswith('http://127.0.0.1:9002/')
    assert meta['container_port']==8080
    assert meta['host_port']==9002
    assert meta['port_selection_reason']=='http_application_port_preference'
    assert meta['known_debug_port_avoided'] is True


def test_exact_documented_port_still_wins_over_application_preference():
    url,meta=rl.rewrite_url('http://internal:5005/debug',[(5005,9003),(8080,9002)],return_meta=True)
    assert url.startswith('http://127.0.0.1:9003/')
    assert meta['container_port']==5005
    assert meta['port_selection_reason']=='exact_documented_logical_port'


def test_xpath_syntax_error_is_backend_database_evidence_for_sqli():
    body="Error: 500 XPATH syntax error: 'root@172.18.0.3'"
    assert rl.DB_BACKEND.search(body)
    assert not rl.APP_PARSER.search(body)


def test_xpath_signal_remains_category_scoped():
    # The marker exists in the shared regex, but _request_once only populates
    # db_backend_error when category == 'sqli'.  Preserve that category gate.
    body="XPATH syntax error: 'root@db'"
    assert bool(rl.DB_BACKEND.search(body))
    assert ('ssrf'=='sqli' and bool(rl.DB_BACKEND.search(body))) is False
