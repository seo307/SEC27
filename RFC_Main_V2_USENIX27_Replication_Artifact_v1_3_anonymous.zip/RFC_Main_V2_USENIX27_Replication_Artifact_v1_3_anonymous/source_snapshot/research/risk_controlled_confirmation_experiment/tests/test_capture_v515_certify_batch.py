from __future__ import annotations

import hashlib
import json
import socket
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from research.risk_controlled_confirmation_experiment import screen_capture_jobs as sc
from research.risk_controlled_confirmation_experiment import run_local_documented_capture as rl


def _stamp(x):
    x=dict(x)
    x['source_request_sha256']=hashlib.sha256(str(x.get('raw','')).encode()).hexdigest()
    x['parsed_spec_sha256']=sc.spec_sha256(x)
    return x


def _run_screen(tmp_path:Path, group:str, readme_text:str):
    srcroot=tmp_path/'sources';readme=srcroot/'vulhub'/'case'/'README.md';readme.parent.mkdir(parents=True)
    readme.write_text(readme_text)
    recipes=tmp_path/'recipes.jsonl'
    recipes.write_text(json.dumps({'group_id':group,'category':'auth_bypass','scenario_kind':'positive_confirmable','source_name':'vulhub','readme_path':'case/README.md','compose_path':'case/docker-compose.yml','environment_fingerprint':'ENV-'+group})+'\n')
    out=tmp_path/'screened.jsonl';summary=tmp_path/'summary.json'
    subprocess.run([sys.executable,sc.__file__,'--recipes',str(recipes),'--sources-root',str(srcroot),'--output',str(out),'--summary',str(summary)],check=True,capture_output=True,text=True)
    return json.loads(out.read_text())


def test_dataease_path_traversal_pair_is_source_grounded_and_read_only():
    specs=[
        _stamp({'source':'curl','raw':'curl --path-as-is http://your-ip:8100/dataease/de2api/datasource/types','method':'GET','url':'http://your-ip:8100/dataease/de2api/datasource/types','headers':[],'data':[],'user':None,'session_key':'anonymous'}),
        _stamp({'source':'curl','raw':'curl --path-as-is http://your-ip:8100/geo/../dataease/de2api/datasource/types','method':'GET','url':'http://your-ip:8100/geo/../dataease/de2api/datasource/types','headers':[],'data':[],'user':None,'session_key':'anonymous'}),
    ]
    text='# DataEase Authentication Bypass via Whitelist Path Traversal (CVE-2024-56511)\n## Vulnerability Reproduction\n'
    c,q=sc._safe_auth_bypass_pair(specs,text)
    assert c['auth_probe_role']=='control' and q['auth_probe_role']=='candidate'
    assert c['auth_normalized_endpoint']==q['auth_normalized_endpoint']=='/dataease/de2api/datasource/types'
    assert q['preserve_raw_path'] is True
    assert q['auth_candidate_credential_kind']=='no_credential_path_bypass'
    assert c['method']==q['method']=='GET'


def test_influxdb_empty_secret_pair_drops_only_authorization_for_control():
    cand=_stamp({'source':'raw_http','raw':'POST /query HTTP/1.1','method':'POST','url':'http://your-ip/query','headers':['Authorization: Bearer public-benchmark-token','Content-Type: application/x-www-form-urlencoded'],'data':['db=sample&q=show+users'],'user':None,'session_key':'authenticated'})
    text='# InfluxDB Empty JWT Secret Key Authentication Bypass (CVE-2019-20933)\n## Vulnerability Reproduce\n'
    c,q=sc._safe_auth_bypass_pair([cand],text)
    assert c['auth_probe_role']=='control' and q['auth_probe_role']=='candidate'
    assert not any(h.lower().startswith('authorization:') for h in c['headers'])
    assert any(h.lower().startswith('authorization: bearer ') for h in q['headers'])
    assert c['data']==q['data']==['db=sample&q=show+users']
    assert c['auth_normalized_endpoint']==q['auth_normalized_endpoint']=='/query'
    assert q['auth_candidate_credential_kind']=='documented_empty_secret_bearer'


def test_hugegraph_full_text_recovery_and_control_derivation():
    text='''# Apache HugeGraph JWT Token Secret Hardcoding Leads to Authentication Bypass (CVE-2024-43441)
## Vulnerability Reproduce
```python
# Install the jwt library
print('x')
```
```http
GET /graphs HTTP/1.1
Host: localhost:8080
Authorization: Bearer documented-public-benchmark-token
```
'''
    parsed=sc._augment_auth_bypass_specs(sc.extract_specs(text),text)
    assert any(sc._normalized_auth_path(x.get('url',''))=='/graphs' for x in parsed)
    stamped=[_stamp(x) for x in parsed]
    c,q=sc._safe_auth_bypass_pair(stamped,text)
    assert c['auth_probe_role']=='control' and q['auth_probe_role']=='candidate'
    assert c['session_key']=='anonymous'
    assert q['auth_candidate_credential_kind']=='documented_default_secret_bearer'


def test_grade_accepts_role_pair_on_normalized_endpoint():
    c={'auth_probe_role':'control','auth_bypass_pair_kind':'documented_whitelist_path_traversal','auth_normalized_endpoint':'/dataease/de2api/datasource/types','method':'GET','url':'http://x/dataease/de2api/datasource/types','headers':[],'data':[]}
    q={**c,'auth_probe_role':'candidate','url':'http://x/geo/../dataease/de2api/datasource/types','preserve_raw_path':True}
    grade,reason,selected=sc._grade('auth_bypass',[c,q],'x')
    assert grade=='full'
    assert len(selected)==2


def test_role_based_auth_evaluation_confirms_no_issued_session_pair():
    specs=[
        {'auth_probe_role':'control','auth_bypass_pair_kind':'documented_empty_secret_bearer','auth_normalized_endpoint':'/query'},
        {'auth_probe_role':'candidate','auth_bypass_pair_kind':'documented_empty_secret_bearer','auth_normalized_endpoint':'/query','auth_candidate_credential_kind':'documented_empty_secret_bearer'},
    ]
    obs=[
        {'status_code':401,'redirected_to_login':False,'auth_denied_marker':True},
        {'status_code':200,'redirected_to_login':False,'application_precondition_marker':False,'preserve_raw_path':False,'wire_path':'/query'},
    ]
    ev=[{'id':'E1','value':{}},{'id':'E2','value':{}}]
    status,mapping,limitations=rl.evaluate('auth_bypass',specs,obs,ev,'positive_confirmable')
    assert status=='confirmed'
    assert mapping['protected_resource_access']==['E2']
    assert mapping['no_valid_session_used']==['E1','E2']
    assert limitations==[]


def test_role_based_path_bypass_requires_raw_dot_segment_on_wire():
    specs=[
        {'auth_probe_role':'control','auth_bypass_pair_kind':'documented_whitelist_path_traversal','auth_normalized_endpoint':'/dataease/de2api/datasource/types'},
        {'auth_probe_role':'candidate','auth_bypass_pair_kind':'documented_whitelist_path_traversal','auth_normalized_endpoint':'/dataease/de2api/datasource/types','auth_candidate_credential_kind':'no_credential_path_bypass'},
    ]
    base=[{'status_code':500,'redirected_to_login':False,'auth_denied_marker':False},{'status_code':200,'redirected_to_login':False,'application_precondition_marker':False,'preserve_raw_path':True,'wire_path':'/geo/../dataease/de2api/datasource/types'}]
    ev=[{'id':'E1','value':{}},{'id':'E2','value':{}}]
    assert rl.evaluate('auth_bypass',specs,base,ev,'positive_confirmable')[0]=='confirmed'
    bad=[dict(x) for x in base];bad[1]['wire_path']='/dataease/de2api/datasource/types'
    assert rl.evaluate('auth_bypass',specs,bad,ev,'positive_confirmable')[0]=='needs_manual_review'


def test_raw_path_http_sender_preserves_dot_segments():
    seen={}
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            seen['path']=self.path
            self.send_response(200);self.end_headers();self.wfile.write(b'ok')
        def log_message(self,*a):pass
    server=HTTPServer(('127.0.0.1',0),H);port=server.server_address[1]
    t=threading.Thread(target=server.handle_request,daemon=True);t.start()
    try:
        r=rl._raw_path_http_request('GET',f'http://127.0.0.1:{port}/geo/../dataease/x',{},None,timeout=2)
        t.join(2)
        assert r['status_code']==200
        assert seen['path']=='/geo/../dataease/x'
        assert r['wire_path']=='/geo/../dataease/x'
    finally:
        server.server_close()


def test_screening_integration_unlocks_dataease_only_with_safe_get_pair(tmp_path:Path):
    text='''# DataEase Authentication Bypass via Whitelist Path Traversal (CVE-2024-56511)
## Vulnerability Reproduction
```
$ curl -sS -D - --path-as-is http://your-ip:8100/dataease/de2api/datasource/types
```
```
$ curl -sS -D - --path-as-is 'http://your-ip:8100/geo/../dataease/de2api/datasource/types'
```
```http
POST /geo/../dataease/de2api/datasource/validate HTTP/1.1
Host: your-ip:8100
Content-Type: application/json

{"cmd":"Runtime.getRuntime().exec('touch /tmp/pwned')"}
```
'''
    row=_run_screen(tmp_path,'G-DATAEASE',text)
    assert row['preexecution_automatable'] is True
    assert row['documentation_grade']=='full'
    assert [x['method'] for x in row['selected_requests']]==['GET','GET']
    assert [x['auth_probe_role'] for x in row['selected_requests']]==['control','candidate']
    assert row['proof_only_rejected_request_count']>=1


def test_screening_integration_unlocks_influxdb_read_only_pair(tmp_path:Path):
    text='''# InfluxDB Empty JWT Secret Key Authentication Bypass (CVE-2019-20933)
## Vulnerability Reproduce
```http
POST /query HTTP/1.1
Host: your-ip
Authorization: Bearer documented-public-benchmark-token
Content-Type: application/x-www-form-urlencoded

db=sample&q=show+users
```
'''
    row=_run_screen(tmp_path,'G-INFLUX',text)
    assert row['preexecution_automatable'] is True
    assert row['documentation_grade']=='full'
    assert [x['auth_probe_role'] for x in row['selected_requests']]==['control','candidate']
    assert row['selected_requests'][1]['auth_candidate_credential_kind']=='documented_empty_secret_bearer'


def test_screening_integration_unlocks_hugegraph_read_only_pair(tmp_path:Path):
    text='''# Apache HugeGraph JWT Token Secret Hardcoding Leads to Authentication Bypass (CVE-2024-43441)
## Vulnerability Reproduce
```python
# Install the jwt library
print('token')
```
```http
GET /graphs HTTP/1.1
Host: localhost:8080
Authorization: Bearer documented-public-benchmark-token
```
'''
    row=_run_screen(tmp_path,'G-HUGEGRAPH',text)
    assert row['preexecution_automatable'] is True
    assert row['documentation_grade']=='full'
    assert [x['auth_probe_role'] for x in row['selected_requests']]==['control','candidate']
    assert row['selected_requests'][1]['auth_candidate_credential_kind']=='documented_default_secret_bearer'
