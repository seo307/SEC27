from __future__ import annotations
import importlib.util,json
from pathlib import Path

HERE=Path(__file__).resolve().parents[1]

def load(name,file):
    spec=importlib.util.spec_from_file_location(name,HERE/file)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

cap=load('cap512','run_local_documented_capture.py')
stab=load('stab512','analyze_stability_regression.py')


def geoserver_spec():
    return {
        'method':'GET','headers':[],'data':[],'session_key':'anonymous',
        'url':"http://your-ip:8080/geoserver/ows?service=wfs&version=1.0.0&request=GetFeature&typeName=vulhub:example&CQL_FILTER=x",
    }


def test_wfs_fixture_probe_uses_describe_feature_type():
    p=cap._wfs_fixture_probe_spec(geoserver_spec())
    assert p['kind']=='wfs_describe_feature_type'
    assert p['type_name']=='vulhub:example'
    assert 'request=DescribeFeatureType' in p['url']
    assert 'typeName=vulhub%3Aexample' in p['url']
    assert 'CQL_FILTER' not in p['url']


def test_non_wfs_request_has_no_fixture_requirement():
    assert cap.fixture_readiness_requirements('sqli',[{'url':'http://your-ip:8000/?x=1'}]) == []


def test_wfs_schema_requires_requested_feature_name():
    req=cap._wfs_fixture_probe_spec(geoserver_spec())
    good='<xsd:schema><xsd:element name="example" type="vulhub:exampleType"/></xsd:schema>'
    wrong='<xsd:schema><xsd:element name="other"/></xsd:schema>'
    missing='<ServiceExceptionReport><ServiceException>Feature type vulhub:example unknown</ServiceException></ServiceExceptionReport>'
    assert cap._fixture_probe_ready(req,good,200) is True
    assert cap._fixture_probe_ready(req,wrong,200) is False
    assert cap._fixture_probe_ready(req,missing,200) is False


def test_fixture_wait_tolerates_startup_race(monkeypatch):
    class R:
        status_code=200
        def __init__(self,text):self.text=text;self.content=text.encode()
    seq=[
        R('<ServiceExceptionReport><ServiceException>Feature type vulhub:example unknown</ServiceException></ServiceExceptionReport>'),
        R('<xsd:schema><xsd:element name="example" type="vulhub:exampleType"/></xsd:schema>'),
    ]
    monkeypatch.setattr(cap.requests,'get',lambda *a,**k:seq.pop(0))
    monkeypatch.setattr(cap.time,'sleep',lambda *a,**k:None)
    ok,meta=cap.wait_for_fixture_readiness('sqli',[geoserver_spec()],[(8080,9003)],timeout=10)
    assert ok is True
    assert meta['ready'] is True
    assert meta['attempts']==2
    assert meta['missing_responses']==1


def _write_rep(base:Path,name:str,signature_variant=False):
    raw=base/name/'acquired_raw';raw.mkdir(parents=True)
    (raw/'acquisition_summary.json').write_text(json.dumps({'status':'PARTIAL','scheduled':1,'valid_captures':1,'invalid_captures':0,'run_errors':0}))
    rec={
        'group_id':'RFCEXT-sqli-014','status':'OK','capture_validity':'CAPTURE_OK_EVIDENTIARY',
        'fixture_readiness':{'required':True,'ready':True},
        'observations':[{'db_backend_error':not signature_variant}],
        'callback_receipts':[],
        'result':{'rfc_capture':{'validation_records':[{'validator_result':{'status':'confirmed' if not signature_variant else 'needs_manual_review'}}]}},
    }
    (raw/'RFCEXT-sqli-014.json').write_text(json.dumps(rec))


def test_stability_analyzer_never_counts_repetitions_as_formal_n(tmp_path):
    _write_rep(tmp_path,'rep-01');_write_rep(tmp_path,'rep-02');_write_rep(tmp_path,'rep-03')
    obj=stab.analyze(tmp_path)
    assert obj['status']=='STABLE'
    assert obj['formal_n_contribution']==0
    assert obj['groups']['RFCEXT-sqli-014']['observed_repetitions']==3
    assert obj['groups']['RFCEXT-sqli-014']['stable'] is True


def test_stability_analyzer_flags_run_to_run_semantic_change(tmp_path):
    _write_rep(tmp_path,'rep-01');_write_rep(tmp_path,'rep-02',signature_variant=True)
    obj=stab.analyze(tmp_path)
    assert obj['status']=='UNSTABLE'
    assert 'RFCEXT-sqli-014' in obj['unstable_groups']
    assert obj['formal_n_contribution']==0


def test_stability_shell_does_not_export_formal_bundle():
    text=(HERE/'run_external_stability_regression.sh').read_text()
    # It may mention the forbidden exporter in a comment explaining the guard,
    # but must contain no executable invocation.
    active=[line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith('#')]
    assert not any('export_external_bundle.py' in line for line in active)
    assert 'formal_n_contribution":0' in text
