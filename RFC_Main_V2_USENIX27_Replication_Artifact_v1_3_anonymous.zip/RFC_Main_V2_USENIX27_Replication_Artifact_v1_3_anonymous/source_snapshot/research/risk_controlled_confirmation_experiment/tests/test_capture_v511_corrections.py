from __future__ import annotations
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import pytest

HERE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cap511',HERE/'run_local_documented_capture.py')
cap=importlib.util.module_from_spec(spec);spec.loader.exec_module(cap)


def test_target_port_allocator_reserves_9999():
    assert cap.PortPool().end == 9998
    with pytest.raises(ValueError):
        cap.PortPool(9000,9999)


def test_reserved_callback_port_is_exactly_9999(monkeypatch):
    bound=[]
    class Sock:
        def bind(self,addr): bound.append(addr)
        def close(self): pass
    monkeypatch.setattr(cap.socket,'socket',lambda *a,**k:Sock())
    assert cap.free_callback_port('172.18.0.1') == 9999
    assert bound == [('172.18.0.1',9999)]


def test_reserved_callback_port_conflict_fails_closed():
    with pytest.raises(RuntimeError,match='reserved SSRF callback port 9999 conflicts'):
        cap.free_callback_port('172.18.0.1',avoid={9999})


def test_missing_feature_type_is_application_precondition_failure():
    body='Feature type vulhub:example unknown'
    assert cap.APP_FIXTURE_MISSING.search(body)
    state,reason,scientific=cap.capture_validity(
        'sqli','positive_confirmable',[{'url':'http://x'},{'url':'http://x?q=1'}],
        [
            {'application_precondition_marker':False,'request_error':None},
            {'application_precondition_marker':True,'request_error':None},
        ],
        [{'id':'E1'},{'id':'E2'}],
    )
    assert state=='APPLICATION_PRECONDITION_FAILED'
    assert scientific is False
    assert 'fixture' in reason


def test_no_such_workspace_is_application_precondition_marker():
    assert cap.APP_FIXTURE_MISSING.search("No such workspace: 'vulhub' found")
    assert cap.APP_FIXTURE_MISSING.search("workspace vulhub not found")


class FakeResponse:
    status_code=500
    headers={}
    content=b'psycopg2 ProgrammingError: SQL syntax error near SELECT'
    text=content.decode()

class FakeSession:
    def request(self,*a,**k): return FakeResponse()


def test_db_backend_feature_is_sqli_only():
    spec={'url':'http://your-ip:8000/vuln','method':'GET','headers':[],'data':[]}
    ports=[(8000,9000)]
    sqli=cap._request_once(spec,ports,FakeSession(),category='sqli')
    ssrf=cap._request_once(spec,ports,FakeSession(),category='ssrf')
    assert sqli['db_backend_error'] is True
    assert sqli['db_error'] is True
    assert ssrf['db_backend_error'] is False
    assert ssrf['db_error'] is False
