#!/usr/bin/env python3
"""Merge externally produced RFC-format captures into a live dataset.

Main-v2 patch rules:
- blinded captures and oracle remain separate;
- independence-eligible groups must be predeclared and audited;
- oracle source must be independent of the validator;
- scenario fingerprints and group IDs may not be reused;
- split_role is frozen before the experiment is run.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from common import HERE, read_jsonl, write_jsonl
from validate_external_bundle import validate


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--captures',required=True)
    ap.add_argument('--oracle',required=True)
    ap.add_argument('--live-dir',default=str(HERE/'work/live'))
    ap.add_argument('--skip-readiness-warnings',action='store_true')
    a=ap.parse_args()
    newc=read_jsonl(Path(a.captures)); newo=read_jsonl(Path(a.oracle)); out=Path(a.live_dir); out.mkdir(parents=True,exist_ok=True)

    report=validate(newc,newo)
    if report['status']!='PASS':
        print(json.dumps(report,indent=2)); raise SystemExit(2)
    if report['warnings'] and not a.skip_readiness_warnings:
        print(json.dumps({**report,'status':'PASS_WITH_WARNINGS','note':'re-run with --skip-readiness-warnings to import after reviewing warnings'},indent=2))
        raise SystemExit(3)

    oldc=read_jsonl(out/'captures_blinded.jsonl'); oldo=read_jsonl(out/'oracle_live.jsonl')
    errors=[]
    existing_ids={c['capture_id'] for c in oldc}; new_ids={c['capture_id'] for c in newc}
    dup_ids=existing_ids & new_ids
    if dup_ids: errors.append(f'duplicate capture ids: {sorted(dup_ids)[:10]}')

    existing_independent={o['group_id'] for o in oldo if o.get('independence_eligible')}
    new_independent={o['group_id'] for o in newo if o.get('independence_eligible')}
    overlap=existing_independent & new_independent
    if overlap: errors.append(f'independence-eligible group_id already present: {sorted(overlap)[:10]}')

    existing_fp={o.get('scenario_fingerprint') for o in oldo if o.get('independence_eligible') and o.get('scenario_fingerprint')}
    new_fp={o.get('scenario_fingerprint') for o in newo if o.get('independence_eligible') and o.get('scenario_fingerprint')}
    fp_overlap=existing_fp & new_fp
    if fp_overlap: errors.append(f'scenario_fingerprint already present: {sorted(fp_overlap)[:10]}')

    if errors:
        print(json.dumps({'status':'FAIL','errors':errors},indent=2)); raise SystemExit(2)
    write_jsonl(out/'captures_blinded.jsonl',oldc+newc); write_jsonl(out/'oracle_live.jsonl',oldo+newo)
    print(json.dumps({
        'status':'PASS','added_captures':len(newc),'added_independent_groups':len(new_independent),
        'by_role':report['by_role'],'by_category':report['by_category'],
    },indent=2))

if __name__=='__main__': main()
