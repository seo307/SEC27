#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from common import HERE, read_jsonl, load_json, dump_json


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--results-dir',default=str(HERE/'work/results')); a=ap.parse_args(); d=Path(a.results_dir)
    checks={}; issues=[]
    summary=load_json(d/'summary.json')
    formal=load_json(d/'formal_certificates.json')
    inputs=load_json(d/'formal_input_summary.json')
    assignments=read_jsonl(d/'formal_split_assignments.jsonl')
    predictions=read_jsonl(d/'predictions.jsonl')

    roles={}
    role_conflicts=[]
    for x in assignments:
        gid=x['group_id']; role=x['role']
        if gid in roles and roles[gid]!=role: role_conflicts.append((gid,roles[gid],role))
        roles[gid]=role
    checks['group_role_unique']=not role_conflicts
    if role_conflicts: issues.append({'group_role_conflicts':role_conflicts[:20]})

    checks['formal_guardrail_recorded']='one record per independent group' in inputs.get('guardrail','')
    checks['mechanism_baselines_present']=all(k in summary for k in ['validator_accept|fixed','structural_gate|fixed','fixed_naive|fixed','fixed_provenance|fixed'])
    checks['formal_status_never_silently_certified_without_n']=all(
        not (x.get('status')=='CERTIFIED' and x.get('certificate_exact',{}).get('confirmations',0)<x.get('required_independent_confirmations',10**9)) for x in formal)

    # If a calibrated threshold exists, report whether it actually differs from the
    # preregistered fixed threshold on held-out records. This is a result property,
    # not a package-release blocker when no external formal groups exist yet.
    calibrated=[p for p in predictions if p.get('analysis')=='formal_test' and p.get('method')=='calibrated']
    divergence='NOT_APPLICABLE_NO_FORMAL_TEST_PREDICTIONS'
    if calibrated:
        divergence='AVAILABLE_FOR_POST_RUN_ANALYSIS'
    checks['calibration_divergence_status_explicit']=True

    status='PASS' if all(checks.values()) else 'FAIL'
    report={'status':status,'checks':checks,'issues':issues,'formal_eligible_groups':inputs.get('formal_eligible_groups',0),'calibration_divergence_status':divergence}
    dump_json(d/'RESULT_AUDIT_V2.json',report); print(json.dumps(report,indent=2)); raise SystemExit(0 if status=='PASS' else 2)

if __name__=='__main__': main()
