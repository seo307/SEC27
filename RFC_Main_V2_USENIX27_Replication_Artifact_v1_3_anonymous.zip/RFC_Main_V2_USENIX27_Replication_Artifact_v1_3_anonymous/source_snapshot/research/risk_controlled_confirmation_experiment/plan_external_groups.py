#!/usr/bin/env python3
"""Generate a preregistered 120-group external benchmark acquisition plan.

The plan is a *collection scaffold*, not synthetic experiment data. Each row must
be instantiated with an independently verifiable real/public scenario before it
may be imported as independence-eligible.
"""
from __future__ import annotations
import argparse, csv, hashlib, json
from pathlib import Path

CATEGORIES=['sqli','idor','ssrf','auth_bypass','ssti','xss']
# Per category: 20 groups = 8 tune + 8 certify + 4 test.
ROLE_DESIGN = {
    'tune': [('positive_confirmable',4),('negative_lookalike',2),('ambiguous_positive',2)],
    'certify': [('positive_confirmable',6),('negative_lookalike',1),('ambiguous_positive',1)],
    'test': [('positive_confirmable',2),('negative_lookalike',1),('ambiguous_positive',1)],
}


def ideal(kind):
    if kind=='positive_confirmable': return True,'confirm'
    if kind=='negative_lookalike': return False,'reject'
    return True,'abstain'


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default='external_group_plan_120.csv'); ap.add_argument('--prefix',default='RFCEXT')
    a=ap.parse_args(); rows=[]
    for cat in CATEGORIES:
        n=0
        for role, design in ROLE_DESIGN.items():
            for kind,count in design:
                for _ in range(count):
                    n+=1; vuln,ide=ideal(kind)
                    gid=f'{a.prefix}-{cat}-{n:03d}'
                    fp_seed=f'{gid}|UNSET_PRODUCT|UNSET_VERSION|UNSET_TARGET_STATE'
                    rows.append({
                        'group_id':gid,'case_id':gid,'category':cat,'pair_id':cat,
                        'split_role':role,'scenario_kind':kind,'planned_vulnerable':str(vuln).lower(),
                        'planned_ideal_decision':ide,'source_class':'public_benchmark',
                        'oracle_source':'FILL_ME','oracle_independent_of_validator':'true',
                        'independence_basis':'FILL_ME','software_product':'FILL_ME','software_version':'FILL_ME',
                        'target_state_id':'FILL_ME','scenario_fingerprint':hashlib.sha256(fp_seed.encode()).hexdigest(),
                        'capture_path':'FILL_ME','oracle_path':'FILL_ME','status':'PLANNED',
                    })
    p=Path(a.output); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    summary={
        'groups':len(rows),'categories':len(CATEGORIES),
        'tune':sum(r['split_role']=='tune' for r in rows),'certify':sum(r['split_role']=='certify' for r in rows),'test':sum(r['split_role']=='test' for r in rows),
        'certify_positive_confirmable':sum(r['split_role']=='certify' and r['scenario_kind']=='positive_confirmable' for r in rows),
        'note':'Rows are preregistered acquisition slots only; replace FILL_ME fields and recompute scenario_fingerprint from real scenario identity before import.'
    }
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
