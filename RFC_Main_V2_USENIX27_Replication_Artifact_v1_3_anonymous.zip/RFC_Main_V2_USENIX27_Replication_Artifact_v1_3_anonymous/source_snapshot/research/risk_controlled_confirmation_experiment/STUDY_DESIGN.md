# Main-v2 Study Design — Risk-Controlled Promotion of Autonomous Pentest Findings

## 1. Study objective

The study evaluates whether an autonomous penetration-testing system can safely promote validator-accepted findings from **PROBABLE** to **CONFIRMED** while controlling the risk that promoted findings are false or epistemically unsafe.

The study explicitly separates:

1. candidate discovery,
2. validator acceptance,
3. structural ProofBundle admissibility, and
4. risk-controlled final promotion.

The primary contribution is the fourth boundary, evaluated against the first three as baselines.

---

## 2. Primary research question

**RQ1. Can exact risk-calibrated selective promotion keep the false-confirmation risk at or below a predeclared target α while preserving useful confirmation coverage?**

Primary target: `α = 0.10`.

Sensitivity targets: `α = 0.05` and `α = 0.20`.

The formal claim is conditional on the independence and deployment assumptions explicitly stated below.

---

## 3. Secondary research questions

### RQ2 — Structural versus epistemic validity

When a ProofBundle is structurally admissible, how often does current evidence state still make final confirmation unsafe?

### RQ3 — Provenance dependence

Does provenance-aware evidence accounting avoid overconfidence caused by multiple tool outputs that derive from the same underlying observation?

### RQ4 — State transition robustness

How do unchanged aging evidence, an observation gap, known remediation, deployment replacement, artifact corruption, and conflicting telemetry change promotion behavior?

### RQ5 — Safety–utility trade-off

How much confirmation coverage and true-confirm recall are lost as the promotion threshold becomes more conservative?

---

## 4. Unit of analysis

### Mechanism evaluation unit

A captured validator decision plus its evidence bundle under one controlled evidence/state condition.

Repeated runs and challenge transformations are correlated observations and are reported descriptively.

### Formal certification unit

One **predeclared natural record from one genuinely independent scenario group**.

A group may contribute at most one record to formal calibration/certification/testing. Repetitions and challenge derivatives from the same group are excluded.

---

## 5. Study layers

### Layer A — Internal controlled mechanism benchmark

The existing Docker benchmark is used to establish mechanism behavior and reproducibility.

The internal benchmark is deliberately marked:

```text
independence_eligible = false
```

Therefore no formal risk certificate may be generated from repeated internal runs alone.

### Layer B — Independent natural scenario benchmark

Publication-level risk certification requires independently constructed or independently sourced scenarios. Each scenario must have:

- a unique `group_id`,
- an independently established oracle,
- one natural candidate/evidence state used for the formal path,
- source provenance,
- current vulnerability truth where observable,
- a predeclared ideal promotion decision,
- no derivation from another formal group.

A practical target for primary α=.10 is at least **80–100 independent groups**, because both tune and certify partitions must contain enough actual promotions. More may be required if abstention is high.

---

## 6. Decision boundaries

### B0 — Validator acceptance

`confirmed` or `probable` validator result is treated as accepted.

### B1 — Strict structural ProofBundle gate

The actual `FindingConfirmationService` is called with strict target/deployment continuity enabled. Mandatory proof obligations, evidence execution status, validator result, artifact integrity, target consistency, target continuity, and formal contradictions are enforced.

### B2 — Fixed naive risk threshold

A deliberately naive score rewards nominally distinct tool names even when observations are correlated.

### B3 — Fixed provenance-aware threshold

Uses the preregistered threshold `0.35`. Evidence is counted through provenance roots and dependency links rather than tool-name count.

### P1 — Exact risk-calibrated promotion

A threshold is selected only from the tune groups. For each candidate threshold, the system computes:

- number of promoted independent groups,
- number of false confirmations among those promoted groups,
- exact one-sided Clopper–Pearson upper confidence bound.

Among thresholds whose upper bound is ≤ α, the threshold that maximizes selected confirmations is frozen. It is then checked on a separate certification group set. Only after a successful certification is the held-out test result treated as a formally risk-controlled result.

---

## 7. Primary endpoint

For promoted findings with observable current truth:

```text
FCR = false confirmed findings / all confirmed findings with known truth
```

The primary statistical endpoint is the one-sided 95% exact upper confidence bound on this risk among independent promoted scenario groups.

---

## 8. Secondary endpoints

- unsafe confirmations: promotion when `ideal_decision != confirm`
- ideal-confirm recall
- confirmation coverage
- abstention rate
- results by evidence/state condition
- threshold versus risk/coverage curve
- number of independent groups required for certification

---

## 9. Challenge-state design

Challenge transformations are mechanistic tests and never enter the formal certificate.

### Clean

Captured evidence and current deployment state are aligned.

### Age 6h, unchanged

Evidence timestamps are moved six hours into the past and an explicit no-change state event is attached. The purpose is to test whether modest age causes unnecessary abstention.

### Age 18h, state unknown

Evidence is 18 hours old and a monitoring gap makes the current state unobserved. The correct action is abstention even when historical vulnerability truth remains positive.

### Post-remediation 72h

Historical evidence is replayed after a known remediation event. Current vulnerability truth is false; confirmation is unsafe.

### Continuity break

Evidence is bound to a prior deployment identity. Main-v2 strengthens the structural baseline so this is rejected before the proposed risk layer.

### Soft conflict

An independent contradictory observation is added as an evidence object, but not promoted to a formal ProofBundle contradiction. This probes epistemic conflict not already handled by the structural gate.

### Hard conflict

A formal unresolved contradiction is attached to the ProofBundle. The structural gate must reject it.

### Artifact corruption

A separate artifact file is physically modified after the expected hash is frozen. The structural gate must reject it.

### Correlated duplication

Additional evidence objects are created with new tool names but shared `provenance_root` and explicit `derived_from` links. The naive baseline may become more confident; the provenance-aware method must not treat them as independent support.

---

## 10. Oracle separation

Blinded records contain no `vulnerable`, `ideal_decision`, or equivalent oracle field. Oracle rows are stored separately and joined only by `record_id` during analysis.

Validator outputs are evidence, not ground truth.

---

## 11. Split procedure

Formal independent groups are assigned to:

- Tune: 40%
- Certification: 40%
- Held-out test: 20%

Assignment uses a predeclared deterministic hash seed unless an external benchmark predeclares a role before labels are analyzed.

No group can appear in multiple roles.

---

## 12. Calibration and certification

For each α:

1. enumerate observed risk-score thresholds on the tune groups;
2. select only thresholds whose one-sided exact risk upper bound is ≤ α;
3. among admissible thresholds, choose the one with maximum number of promoted groups;
4. freeze the threshold;
5. apply it unchanged to the independent certification groups;
6. require both:
   - exact upper bound ≤ α, and
   - minimum number of independent confirmations configured for α;
7. report held-out test performance separately.

If no threshold meets the tune bound, output `NOT_RUN_NO_CALIBRATED_THRESHOLD`.

If the risk bound passes but selected independent confirmations are too few, output `INSUFFICIENT_INDEPENDENT_CONFIRMATIONS`.

No successful label is inferred from repetitions.

---

## 13. Primary hypotheses

### H1

Strict structural gating reduces false/unsafe confirmations relative to validator acceptance.

### H2

Provenance-aware risk scoring reduces unsafe promotion under stale, soft-conflicting, and correlated evidence without reducing clean ideal-confirm recall more than necessary.

### H3

When sufficient independent groups are available, exact calibration selects a threshold that differs from a fixed heuristic in at least some regimes and satisfies the predeclared α risk criterion on the independent certification split.

### H4

Correlated evidence duplication improves the naive tool-count score but does not improve the provenance-aware independent-support representation.

---

## 14. Go / no-go criteria

### Mechanism GO

- all internal live captures valid;
- dataset audit PASS;
- structural continuity, artifact, and hard-conflict controls behave as expected;
- at least three structurally allowed risk levels exist;
- provenance mutation is represented by real evidence/provenance objects;
- fixed and calibrated algorithms demonstrably differ on the preregistered calibration sanity fixture.

### Publication-level formal GO

Primary α=.10 requires:

- enough independence-eligible natural groups to calibrate and certify;
- successful tune threshold selection;
- certification exact upper bound ≤ .10;
- at least 30 independent promoted certification groups;
- held-out test results reported without retuning;
- no oracle leakage or group overlap.

---

## 15. Interpretation limits

Main-v2 must not claim:

- universal distribution-free validity under arbitrary adversarial shift;
- independence from repeated executions of the same scenario;
- a formal α guarantee when the package outputs a non-certified status;
- that challenge transformations constitute external validation.

The strongest permissible formal claim is conditional on the independence, oracle, and calibration/deployment assumptions documented in the study.
