#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ $# -ne 0 ]]; then
  echo "This targeted runner takes no arguments." >&2
  echo "It executes the normal immutable pipeline with --only-new for RFCEXT-sqli-013,RFCEXT-sqli-016,RFCEXT-ssrf-010." >&2
  exit 2
fi
exec "$HERE/run_external_capture_pipeline.sh" \
  --only-new \
  --groups RFCEXT-sqli-013,RFCEXT-sqli-016,RFCEXT-ssrf-010
