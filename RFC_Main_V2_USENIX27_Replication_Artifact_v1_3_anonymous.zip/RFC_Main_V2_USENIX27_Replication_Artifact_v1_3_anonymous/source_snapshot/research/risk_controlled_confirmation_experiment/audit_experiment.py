#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from common import HERE, read_jsonl, dump_json, sha256_file, resolve_dataset_path
from risk_score import extract_features, score_provenance_aware, score_naive_toolcount
from calibration_sanity import run as calibration_sanity


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--dataset-dir',default=str(HERE/'work/dataset')); ap.add_argument('--results-dir',default=str(HERE/'work/results')); a=ap.parse_args()
    d=Path(a.dataset_dir); issues=[]; checks={}
    records=read_jsonl(d/'records_blinded.jsonl'); oracle=read_jsonl(d/'oracle.jsonl'); meta_rows=read_jsonl(d/'analysis_metadata.jsonl')
    meta={m['record_id']:m for m in meta_rows}; omap={o['record_id']:o for o in oracle}
    forbidden={'vulnerable','ground_truth','ideal_decision','oracle_label'}
    leaks=[]
    for r in records:
        text=json.dumps(r).lower()
        for k in forbidden:
            if f'"{k}"' in text: leaks.append((r.get('record_id'),k))
    checks['oracle_leak_free']=not leaks
    if leaks: issues.append({'oracle_leaks':leaks[:20]})
    ids={r['record_id'] for r in records}; oids={o['record_id'] for o in oracle}
    checks['record_oracle_id_match']=ids==oids

    abs_paths=[]; artifact_semantics=[]; feature_drift=[]; score_drift=[]
    for r in records:
        ref=r.get('artifact_ref','')
        if Path(ref).is_absolute(): abs_paths.append(r['record_id']); continue
        try: p=resolve_dataset_path(ref,d)
        except Exception: artifact_semantics.append((r['record_id'],'path_resolution')); continue
        actual=p.exists() and sha256_file(p)==r['artifact_sha256']
        observed=bool(r.get('artifact_integrity_observed'))
        condition=meta.get(r['record_id'],{}).get('condition')
        expected = condition!='artifact_corruption'
        if actual!=observed or actual!=expected:
            artifact_semantics.append((r['record_id'],condition,actual,observed,expected))
        f=extract_features(r)
        if f!=r.get('features'): feature_drift.append(r['record_id'])
        if score_provenance_aware(f)!=r.get('risk_score') or score_naive_toolcount(f)!=r.get('naive_risk_score'):
            score_drift.append(r['record_id'])
    checks['relative_artifact_paths']=not abs_paths
    checks['artifact_state_semantics_valid']=not artifact_semantics
    checks['features_recomputed_from_raw_state']=not feature_drift
    checks['scores_recomputed_from_features']=not score_drift
    if abs_paths: issues.append({'absolute_artifact_paths':abs_paths[:20]})
    if artifact_semantics: issues.append({'artifact_semantics':artifact_semantics[:20]})
    if feature_drift: issues.append({'feature_drift':feature_drift[:20]})
    if score_drift: issues.append({'score_drift':score_drift[:20]})

    continuity=[r for r in records if meta.get(r['record_id'],{}).get('condition')=='continuity_break']
    checks['strict_structural_gate_enforces_continuity']=bool(continuity) and all(not r['structural_gate']['allowed'] and 'target_continuity_unverified' in r['structural_gate']['failures'] for r in continuity)

    corr=[r for r in records if meta.get(r['record_id'],{}).get('condition')=='correlated_duplication']
    checks['correlated_support_is_object_level']=bool(corr) and all(
        r['features']['duplicate_observation_count']>0 and r['features']['dependency_edge_count']>0 and
        r['features']['nominal_tool_count']>=r['features']['independent_root_count'] for r in corr)

    soft=[r for r in records if meta.get(r['record_id'],{}).get('condition')=='soft_conflict']
    checks['soft_conflict_is_evidence_level']=bool(soft) and all(r['features']['soft_conflict_count']>0 and not r.get('contradictions') for r in soft)

    challenges=[o for o in oracle if meta.get(o['record_id'],{}).get('condition')!='clean']
    checks['challenge_records_excluded_from_formal_certificate']=all(not o.get('certificate_eligible') for o in challenges)

    eligible=[o for o in oracle if o.get('certificate_eligible')]
    by_group={}
    for o in eligible: by_group.setdefault(o['group_id'],0); by_group[o['group_id']]+=1
    checks['one_formal_record_per_group']=all(n==1 for n in by_group.values())

    unique_scores=sorted({r['risk_score'] for r in records if r['structural_gate']['allowed']})
    checks['intermediate_risk_support_present']=len(unique_scores)>=3
    if len(unique_scores)<3: issues.append({'unique_structurally_allowed_risk_scores':unique_scores})

    sanity=calibration_sanity()
    checks['calibration_can_differ_from_fixed_threshold']=sanity['status']=='PASS' and sanity['differing_decisions']>0

    status='PASS' if all(checks.values()) else 'FAIL'
    report={'status':status,'checks':checks,'issues':issues,'records':len(records),'oracle_rows':len(oracle),'formal_eligible_groups':len(by_group),'structurally_allowed_risk_scores':unique_scores,'calibration_sanity':sanity}
    dump_json(d/'AUDIT_REPORT_V2.json',report); print(json.dumps(report,indent=2)); raise SystemExit(0 if status=='PASS' else 2)

if __name__=='__main__': main()
