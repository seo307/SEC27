#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ $# -ne 0 ]]; then
  echo "This targeted runner takes no arguments." >&2
  echo "It executes the normal immutable pipeline with --only-new for the V5.1.5 certify batch." >&2
  echo "Groups: RFCEXT-auth_bypass-009,RFCEXT-auth_bypass-011,RFCEXT-auth_bypass-013" >&2
  exit 2
fi
exec "$HERE/run_external_capture_pipeline.sh" \
  --only-new \
  --groups RFCEXT-auth_bypass-009,RFCEXT-auth_bypass-011,RFCEXT-auth_bypass-013
