from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def load_json(path: Path):
    return json.loads(path.read_text())

def dump_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str))

def read_jsonl(path: Path):
    if not path.exists():
        return []
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]

def write_jsonl(path: Path, rows: Iterable[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w') as f:
        for r in rows:
            f.write(json.dumps(r, sort_keys=True, default=str) + '\n')

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def parse_ts(value: str) -> datetime:
    v = value.replace('Z', '+00:00')
    dt = datetime.fromisoformat(v)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

def iso_shift(value: str, *, hours: float = 0.0) -> str:
    from datetime import timedelta
    dt = parse_ts(value) + timedelta(hours=hours)
    return dt.isoformat().replace('+00:00', 'Z')

def relative_to_dataset(path: Path, dataset_dir: Path) -> str:
    return path.resolve().relative_to(dataset_dir.resolve()).as_posix()

def resolve_dataset_path(ref: str, dataset_dir: Path) -> Path:
    p = Path(ref)
    if p.is_absolute():
        raise ValueError(f'absolute artifact path forbidden in v2: {ref}')
    resolved = (dataset_dir / p).resolve()
    base = dataset_dir.resolve()
    if resolved != base and base not in resolved.parents:
        raise ValueError(f'artifact path escapes dataset dir: {ref}')
    return resolved
