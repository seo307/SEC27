#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
EXT="$HERE/external"
REGISTRY="$EXT/scientifically_accepted_environment_registry.json"
RUNS="$EXT/runs"
RECIPES="$EXT/acquisition_recipes.jsonl"
SOURCES="$EXT/sources"
PLAN_ONLY=0
RETRY_BLOCKERS=0
INCLUDE_AMBIGUOUS=0
INCLUDE_NONCERTIFY=0
MAX_BATCH=0
MIN_REGISTRY=10
while [[ $# -gt 0 ]]; do
  case "$1" in
    --plan-only) PLAN_ONLY=1; shift ;;
    --retry-blockers) RETRY_BLOCKERS=1; shift ;;
    --include-ambiguous) INCLUDE_AMBIGUOUS=1; shift ;;
    --include-noncertify) INCLUDE_NONCERTIFY=1; shift ;;
    --max-batch) MAX_BATCH="${2:?max batch required}"; shift 2 ;;
    --registry) REGISTRY="${2:?registry path required}"; shift 2 ;;
    --min-registry) MIN_REGISTRY="${2:?minimum registry count required}"; shift 2 ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done
if [[ ! -f "$REGISTRY" ]]; then
  echo "V5.2 requires an initialized scientific registry: $REGISTRY" >&2
  exit 2
fi
REG_COUNT=$(PYTHONPATH="$ROOT" python - <<PY
import json
from pathlib import Path
p=Path(r'''$REGISTRY''');o=json.loads(p.read_text());print(len(o.get('entries') or {}))
PY
)
if (( REG_COUNT < MIN_REGISTRY )); then
  echo "registry has $REG_COUNT accepted environments; V5.2 checkpoint expects at least $MIN_REGISTRY" >&2
  echo "Complete explicit scientific acceptance for prior reviewed runs before batch expansion." >&2
  exit 2
fi
RUN_ID="${RFC_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-v52-$$}"
RUN="$RUNS/$RUN_ID"
mkdir -p "$RUN"
SCREENED="$RUN/controller_screened_jobs.jsonl"
SCREEN_SUM="$RUN/controller_screen_summary.json"
CTRL_PLAN="$RUN/controller_plan.json"
INVENTORY="$RUN/corpus_inventory.jsonl"
BLOCKED="$RUN/corpus_blockers.jsonl"
READY="$RUN/ready_groups.txt"
REVIEW="$RUN/scientific_review_queue.jsonl"
REGCAND="$RUN/registry_review_candidates.jsonl"
REVIEW_SUM="$RUN/scientific_review_summary.json"
PROGRESS="$RUN/formal_progress.json"
SUMMARY_MD="$RUN/V52_RUN_SUMMARY.md"
PLAN_ARGS=()
[[ "$RETRY_BLOCKERS" -eq 1 ]] && PLAN_ARGS+=(--retry-blockers)
[[ "$INCLUDE_AMBIGUOUS" -eq 1 ]] && PLAN_ARGS+=(--include-ambiguous)
[[ "$INCLUDE_NONCERTIFY" -eq 1 ]] && PLAN_ARGS+=(--include-noncertify)
[[ "$MAX_BATCH" -gt 0 ]] && PLAN_ARGS+=(--max-batch "$MAX_BATCH")
PYTHONPATH="$ROOT" python "$HERE/screen_capture_jobs.py" \
  --recipes "$RECIPES" --sources-root "$SOURCES" --output "$SCREENED" --summary "$SCREEN_SUM"
PYTHONPATH="$ROOT" python "$HERE/corpus_expansion_controller.py" plan \
  --screened "$SCREENED" --registry "$REGISTRY" --runs-root "$RUNS" \
  --output "$CTRL_PLAN" --inventory "$INVENTORY" --blocked "$BLOCKED" --ready-groups "$READY" \
  "${PLAN_ARGS[@]}"
READY_COUNT=$(grep -cve '^\s*$' "$READY" 2>/dev/null || true)
PIPE_RC=0
if [[ "$PLAN_ONLY" -eq 0 && "$READY_COUNT" -gt 0 ]]; then
  READY_CSV=$(python - <<PY
from pathlib import Path
print(','.join(x.strip() for x in Path(r'''$READY''').read_text().splitlines() if x.strip()))
PY
)
  set +e
  RFC_RUN_ID="$RUN_ID" "$HERE/run_external_capture_pipeline.sh" \
    --only-new --registry "$REGISTRY" --groups "$READY_CSV"
  PIPE_RC=$?
  set -e
fi
if [[ -f "$RUN/acquisition_ledger.json" ]]; then
  PYTHONPATH="$ROOT" python "$HERE/corpus_expansion_controller.py" review \
    --run-dir "$RUN" --output "$REVIEW" --registry-candidates "$REGCAND" --summary "$REVIEW_SUM"
else
  : > "$REVIEW"; : > "$REGCAND"
  python - <<PY
import json
from pathlib import Path
Path(r'''$REVIEW_SUM''').write_text(json.dumps({'status':'PASS','run_id':r'''$RUN_ID''','rows':0,'registry_review_candidates':0,'formal_confirmation_candidates':0,'risk_event_candidates':0,'scientific_acceptance_automatic':False},indent=2)+'\n')
PY
fi
PYTHONPATH="$ROOT" python "$HERE/corpus_expansion_controller.py" progress \
  --registry "$REGISTRY" --runs-root "$RUNS" --config "$HERE/config/experiment.json" --output "$PROGRESS"
PYTHONPATH="$ROOT" python "$HERE/corpus_expansion_controller.py" render \
  --plan "$CTRL_PLAN" --review-summary "$REVIEW_SUM" --progress "$PROGRESS" --output "$SUMMARY_MD"
python - <<PY
import hashlib,json
from pathlib import Path
run=Path(r'''$RUN''')
def sha(p):
 p=Path(p);return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
acq=run/'acquired_raw'/'acquisition_summary.json';run_errors=None
if acq.exists():
 try:run_errors=json.loads(acq.read_text()).get('run_errors')
 except Exception:pass
obj={
 'controller_version':'5.2','run_id':r'''$RUN_ID''','pipeline_returncode':int(r'''$PIPE_RC'''),'plan_only':bool(int(r'''$PLAN_ONLY''')),
 'registry_count_before':int(r'''$REG_COUNT'''),'ready_count':int(r'''$READY_COUNT'''),'run_errors':run_errors,
 'scientific_acceptance_automatic':False,
 'hashes':{
  'controller_plan_sha256':sha(run/'controller_plan.json'),'inventory_sha256':sha(run/'corpus_inventory.jsonl'),
  'blockers_sha256':sha(run/'corpus_blockers.jsonl'),'review_queue_sha256':sha(run/'scientific_review_queue.jsonl'),
  'registry_candidates_sha256':sha(run/'registry_review_candidates.jsonl'),'formal_progress_sha256':sha(run/'formal_progress.json'),
  'run_summary_sha256':sha(run/'V52_RUN_SUMMARY.md'),'capture_run_manifest_sha256':sha(run/'run_manifest.json')
 }
}
(run/'controller_manifest.json').write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
print(json.dumps(obj,indent=2))
PY
# Empty/invalid scientific yield is not an operational controller failure when the
# capture runtime itself reported zero run errors. Keep the immutable pipeline RC
# in controller_manifest.json for audit.
RUN_ERRORS=$(python - <<PY
import json
from pathlib import Path
p=Path(r'''$RUN''')/'acquired_raw'/'acquisition_summary.json'
if not p.exists(): print(0)
else:
 try: print(int(json.loads(p.read_text()).get('run_errors') or 0))
 except Exception: print(1)
PY
)
if [[ "$RUN_ERRORS" -gt 0 ]]; then exit "${PIPE_RC:-1}"; fi
exit 0
