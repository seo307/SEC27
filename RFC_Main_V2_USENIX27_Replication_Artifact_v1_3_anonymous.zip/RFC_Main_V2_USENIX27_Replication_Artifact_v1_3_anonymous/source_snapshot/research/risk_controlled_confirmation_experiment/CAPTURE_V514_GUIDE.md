# RFC Main-V2 Auto-Capture v5.1.4 — Targeted Corpus Expansion

## Scope

V5.1.4 is an acquisition-layer overlay on audited V5.1.3 + V5.1.3.1. It does **not** change:

- structural ProofBundle vs risk-gate separation;
- validator/oracle separation;
- oracle labels;
- tune/certify/test assignments;
- FCR definition or exact Clopper–Pearson certification;
- environment-level independence;
- the six already accepted environment fingerprints;
- the rule that repetitions contribute zero additional independent N.

The patch only unlocks three currently assigned, previously non-automatable public benchmark recipes.

## Changes

### 1. Error-based SQLi recognition

The screening classifier now recognizes the narrowly scoped error-based SQL functions `updatexml()` and `extractvalue()` as SQLi reproduction signals.

This makes `RFCEXT-sqli-016` (Joomla CVE-2017-8917) a valid **partial-evidence** acquisition recipe. Its scenario remains predeclared `ambiguous_positive`, so the method should continue to abstain / require manual review even if the payload produces useful evidence.

### 2. Benign derived SQLi control

For a `positive_confirmable` SQLi recipe that has one non-mutating error-based source request but no documented control, the screen may derive a same-endpoint benign control only when the transformation is narrow and mechanically checkable.

Transformation label:

```text
SQLI_ERROR_PAYLOAD_TO_BENIGN_SAME_ENDPOINT_CONTROL
```

For the Drupal CVE-2014-3704 recipe, the injected array-key expression is replaced by a benign numeric array index in the control request. The original candidate request is preserved unchanged. The control records:

- source request SHA-256;
- source parsed-spec SHA-256;
- transformed request SHA-256;
- exact transformed component location;
- source/effective component SHA-256;
- transformation strategy;
- control/candidate roles.

This unlocks `RFCEXT-sqli-013` for prospective acquisition. If the Drupal installation/application fixture is not ready, it must still be excluded as an application precondition failure and contribute formal N += 0.

### 3. GeoServer SSRF Host alignment

`RFCEXT-ssrf-010` documents that the URL host must match the HTTP `Host` header. The source request already contains a URL-fetch field and explicitly states that the server sends the request and returns the fetched response.

When the controlled local callback replaces the source URL, V5.1.4 may align the **effective Host header** to the callback authority only when this requirement is explicit in the source documentation. The connection target remains loopback-published Docker; this does not permit arbitrary external targeting.

Recorded provenance includes:

- source Host-header SHA-256;
- effective Host-header SHA-256;
- effective callback authority;
- source-documentation basis;
- existing callback URL/body substitution provenance.

A valid nonce-correlated callback remains the confirmation evidence.

## Screening result on the current 46-case corpus

V5.1.3:

```text
jobs=46
automatable=7
unsupported=39
```

V5.1.4:

```text
jobs=46
automatable=10
unsupported=36
```

Newly automatable groups are exactly:

```text
RFCEXT-sqli-013  certify  positive_confirmable
RFCEXT-sqli-016  certify  ambiguous_positive
RFCEXT-ssrf-010  certify  positive_confirmable
```

`RFCEXT-sqli-004` gains more accurate URL parsing but remains non-automatable, so no additional unintended acquisition target is introduced.

With the current six-environment scientific registry, `--only-new` continues to remove all six accepted fingerprints before Docker execution.

## Install

From the extracted patch directory:

```bash
python apply_patch.py --repo ~/main_test_V2 --check
python apply_patch.py --repo ~/main_test_V2
```

## Validate

From `~/main_test_V2`:

```bash
python -m pytest -q \
  research/risk_controlled_confirmation_experiment/tests/test_environment_registry_v513.py \
  research/risk_controlled_confirmation_experiment/tests/test_capture_v513_family_adapters.py \
  research/risk_controlled_confirmation_experiment/tests/test_capture_v514_corpus_expansion.py
```

Expected:

```text
17 passed
```

Full external experiment tests should also pass:

```bash
python -m pytest -q research/risk_controlled_confirmation_experiment/tests
```

Expected on the audited reconstruction:

```text
82 passed
```

## Run the targeted normal immutable acquisition

Ensure the six-environment registry is already installed at:

```text
research/risk_controlled_confirmation_experiment/external/scientifically_accepted_environment_registry.json
```

Then execute:

```bash
research/risk_controlled_confirmation_experiment/run_external_corpus_expansion_v514.sh
```

This is a **normal acquisition**, not a regression-only run. It invokes:

```text
--only-new --groups RFCEXT-sqli-013,RFCEXT-sqli-016,RFCEXT-ssrf-010
```

It intentionally excludes the repeatedly auth-precondition-failing `RFCEXT-sqli-010`.

## Scientific acceptance after the run

Do not auto-register any result. Review each group first.

Expected decision rules:

- `RFCEXT-sqli-013`: accept only if the benign control and source candidate are both acquired and backend-database evidence satisfies the existing SQLi semantics. Installation/setup failure => N += 0.
- `RFCEXT-sqli-016`: if direct evidence is acquired, preserve the predeclared ambiguous-positive abstention behavior. Scientific acceptance as an ambiguous-positive certify environment does not require promotion to CONFIRM.
- `RFCEXT-ssrf-010`: accept only if the controlled callback is actually received with nonce correlation and Host-alignment provenance is present.

Only after scientific review should accepted groups be added with `environment_registry.py record --accept-group ...`.
