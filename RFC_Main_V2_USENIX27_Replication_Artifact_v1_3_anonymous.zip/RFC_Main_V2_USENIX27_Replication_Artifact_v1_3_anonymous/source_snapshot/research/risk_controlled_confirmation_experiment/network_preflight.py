#!/usr/bin/env python3
"""Non-blocking network dependency preflight for the external benchmark harness.

This tool does not decide vulnerability outcomes.  It records whether common
source/registry dependencies can be resolved and reached so later failures can
be classified as infrastructure/network issues rather than model outcomes.
"""
from __future__ import annotations
import argparse,json,socket,ssl,time
from datetime import datetime,timezone
from pathlib import Path

DEFAULT_HOSTS=['github.com','registry-1.docker.io','auth.docker.io']
def now():return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')

def check(host,port=443,timeout=4):
    r={'host':host,'port':port,'dns':'FAIL','tcp':'NOT_RUN','tls':'NOT_RUN','addresses':[]}
    try:
        infos=socket.getaddrinfo(host,port,type=socket.SOCK_STREAM);addrs=sorted({x[4][0] for x in infos});r['addresses']=addrs[:8];r['dns']='PASS'
    except Exception as e:r['dns_error']=f'{type(e).__name__}: {e}';return r
    try:
        s=socket.create_connection((host,port),timeout=timeout);r['tcp']='PASS'
    except Exception as e:r['tcp']='FAIL';r['tcp_error']=f'{type(e).__name__}: {e}';return r
    try:
        ctx=ssl.create_default_context();ss=ctx.wrap_socket(s,server_hostname=host);r['tls']='PASS';r['tls_version']=ss.version();ss.close()
    except Exception as e:r['tls']='FAIL';r['tls_error']=f'{type(e).__name__}: {e}';s.close()
    return r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);ap.add_argument('--host',action='append',default=[]);a=ap.parse_args()
    hosts=a.host or DEFAULT_HOSTS;rows=[check(h) for h in hosts];blocked=[x['host'] for x in rows if x['dns']!='PASS' or x['tcp']!='PASS' or x['tls']!='PASS']
    out={'status':'PASS' if not blocked else 'PARTIAL','captured_at':now(),'informational_only':True,'hosts':rows,'unreachable_or_intercepted':blocked}
    p=Path(a.output);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(out,indent=2,sort_keys=True));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
