#!/usr/bin/env python3
"""Pre-import audit for independent external RFC capture/oracle bundles."""
from __future__ import annotations
import argparse, json
from collections import Counter, defaultdict
from pathlib import Path

from common import read_jsonl, dump_json

CATEGORIES={'sqli','idor','ssrf','auth_bypass','ssti','xss'}
ROLES={'tune','certify','test'}
IDEALS={'confirm','abstain','reject'}


def _low_json(x):
    return json.dumps(x, sort_keys=True).lower()


def validate(captures: list[dict], oracle: list[dict], *, allow_empty: bool=False) -> dict:
    errors=[]; warnings=[]
    if not allow_empty:
        if not captures: errors.append('external capture bundle is empty')
        if not oracle: errors.append('external oracle bundle is empty')
    cids=[x.get('capture_id') for x in captures]
    oids=[x.get('capture_id') for x in oracle]
    if len(cids)!=len(set(cids)): errors.append('duplicate capture_id in blinded captures')
    if len(oids)!=len(set(oids)): errors.append('duplicate capture_id in oracle')
    if set(cids)!=set(oids): errors.append('capture/oracle ID sets differ')
    omap={o.get('capture_id'):o for o in oracle}

    group_ids=[]; fingerprints=[]; environment_fingerprints=[]; eligible=[]
    by_role=Counter(); by_cat=Counter(); by_role_cat=defaultdict(Counter); ideal_by_role=defaultdict(Counter)
    for c in captures:
        cid=c.get('capture_id')
        for k in ['capture_id','case_id','category','pair_id','group_id','source_class','result']:
            if k not in c: errors.append(f'{cid}: capture missing {k}')
        if c.get('category') not in CATEGORIES: errors.append(f'{cid}: unsupported category {c.get("category")}')
        txt=_low_json(c)
        for forbidden in ['"vulnerable"','"ideal_decision"','"oracle_source"']:
            if forbidden in txt: errors.append(f'{cid}: oracle leak in blinded capture ({forbidden})')

        o=omap.get(cid,{})
        for k in ['capture_id','case_id','category','pair_id','group_id','source_class','independence_eligible','vulnerable','ideal_decision']:
            if k not in o: errors.append(f'{cid}: oracle missing {k}')
        if c.get('case_id')!=o.get('case_id') or c.get('category')!=o.get('category') or c.get('group_id')!=o.get('group_id'):
            errors.append(f'{cid}: blinded/oracle identity fields disagree')
        if o.get('ideal_decision') not in IDEALS: errors.append(f'{cid}: invalid ideal_decision')
        if o.get('ideal_decision')=='confirm' and o.get('vulnerable') is not True:
            errors.append(f'{cid}: ideal confirm requires vulnerable=true')
        if o.get('vulnerable') is False and o.get('ideal_decision')=='confirm':
            errors.append(f'{cid}: non-vulnerable scenario cannot be ideal confirm')

        if o.get('independence_eligible'):
            eligible.append(o)
            for k in ['split_role','oracle_source','oracle_independent_of_validator','scenario_fingerprint','environment_fingerprint','independence_basis']:
                if not o.get(k): errors.append(f'{cid}: independent oracle missing {k}')
            if o.get('split_role') not in ROLES: errors.append(f'{cid}: invalid/missing split_role')
            if o.get('oracle_independent_of_validator') is not True:
                errors.append(f'{cid}: oracle_independent_of_validator must be true')
            if o.get('source_class') in {None,'internal_controlled'}:
                errors.append(f'{cid}: independent group must use non-internal source_class')
            group_ids.append(o.get('group_id')); fingerprints.append(o.get('scenario_fingerprint')); environment_fingerprints.append(o.get('environment_fingerprint'))
            by_role[o.get('split_role')]+=1; by_cat[o.get('category')]+=1
            by_role_cat[o.get('split_role')][o.get('category')]+=1
            ideal_by_role[o.get('split_role')][o.get('ideal_decision')]+=1

    if len(group_ids)!=len(set(group_ids)): errors.append('independence-eligible group_id repeated')
    fps=[x for x in fingerprints if x]
    if len(fps)!=len(set(fps)): errors.append('scenario_fingerprint repeated among independent groups')
    envs=[x for x in environment_fingerprints if x]
    if len(envs)!=len(set(envs)): errors.append('environment_fingerprint repeated among independent groups')

    # Readiness warnings, not import blockers.
    cert_confirm=ideal_by_role['certify']['confirm']
    if eligible and cert_confirm < 30:
        warnings.append(f'certify split has only {cert_confirm} ideal-confirm groups; alpha=.10 may lack 30 independent confirmations')
    for cat in sorted(CATEGORIES):
        if eligible and by_cat[cat] < 10:
            warnings.append(f'category {cat} has fewer than 10 independent groups')
    if eligible and not all(by_role[r] for r in ROLES): warnings.append('one or more formal split roles are empty')

    return {
        'status':'PASS' if not errors else 'FAIL',
        'captures':len(captures),'oracle_rows':len(oracle),'independence_eligible_groups':len(eligible),
        'errors':errors,'warnings':warnings,
        'by_role':dict(by_role),'by_category':dict(by_cat),
        'by_role_category':{r:dict(by_role_cat[r]) for r in sorted(by_role_cat)},
        'ideal_decision_by_role':{r:dict(ideal_by_role[r]) for r in sorted(ideal_by_role)},
    }


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--captures',required=True); ap.add_argument('--oracle',required=True); ap.add_argument('--report'); ap.add_argument('--allow-empty',action='store_true',help='Scaffolding only: permit an empty bundle to validate structurally')
    a=ap.parse_args(); report=validate(read_jsonl(Path(a.captures)),read_jsonl(Path(a.oracle)), allow_empty=a.allow_empty)
    if a.report: dump_json(Path(a.report),report)
    print(json.dumps(report,indent=2)); raise SystemExit(0 if report['status']=='PASS' else 2)

if __name__=='__main__': main()
