#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
EXP="$(cd "$HERE/.." && pwd)"
EXT="$EXP/external"
REG="${RFC_FINAL_REGISTRY:-$EXT/scientifically_accepted_environment_registry.json}"
RUNS="${RFC_FINAL_RUNS_ROOT:-$EXT/runs}"
CORR="${RFC_FINAL_CORRECTION_RUN:-}"
MODE="${1:---prepare}"

latest_corr() {
  ls -td "$EXT"/phase2_correction_runs/* 2>/dev/null | head -1 || true
}

if [[ -z "$CORR" ]]; then CORR="$(latest_corr)"; fi
if [[ -z "$CORR" || ! -d "$CORR" ]]; then echo "Set RFC_FINAL_CORRECTION_RUN to the V5.4.1 correction run directory" >&2; exit 2; fi

if [[ "$MODE" == "--prepare" ]]; then
  RUN_ID="${RFC_FINAL_EVAL_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-finaleval-$$}"
  OUT="${RFC_FINAL_EVAL_OUT:-$EXT/final_evaluation_runs/$RUN_ID}"
  mkdir -p "$OUT"
  echo "[FINAL 1/4] Freeze source-only independent Juice Shop oracle"
  python "$HERE/final_evaluation.py" freeze-juice-oracle --correction-run "$CORR" --output "$OUT/juice_shop_oracle_source_freeze.json"
  echo "[FINAL 2/4] Build deduplicated blinded casepack + separate oracle + frozen method replay"
  python "$HERE/final_evaluation.py" build-casepack --runs-root "$RUNS" --registry "$REG" --phase2-correction-run "$CORR" --juice-oracle "$OUT/juice_shop_oracle_source_freeze.json" --include-internal-stress --output-dir "$OUT"
  echo "[FINAL 3/4] Snapshot current formal progress"
  python "$HERE/final_evaluation.py" formal-progress --registry "$REG" --runs-root "$RUNS" --output "$OUT/formal_progress.json" || true
  echo "[FINAL 4/4] Prepared. Run a blinded agent baseline, then finalize."
  echo "$OUT" > "$OUT/RUN_DIR.txt"
  echo "RUN_DIR=$OUT"
  echo "AGENT_INPUT=$OUT/casepack_agent_blinded.jsonl"
  exit 0
fi

if [[ "$MODE" == "--agent" ]]; then
  OUT="${RFC_FINAL_EVAL_OUT:?Set RFC_FINAL_EVAL_OUT to a prepared final evaluation run directory}"
  PROVIDER="${RFC_FINAL_AGENT_PROVIDER:?Set RFC_FINAL_AGENT_PROVIDER=openai or anthropic}"
  MODEL="${RFC_FINAL_AGENT_MODEL:?Set RFC_FINAL_AGENT_MODEL}"
  LABEL="${RFC_FINAL_AGENT_LABEL:-$PROVIDER-$MODEL}"
  mkdir -p "$OUT/agent_outputs"
  SAFE_LABEL="$(printf '%s' "$LABEL" | tr -cs 'A-Za-z0-9._-' '_')"
  echo "[FINAL AGENT] $PROVIDER / $MODEL"
  python "$HERE/final_evaluation.py" run-agent --inputs "$OUT/casepack_agent_blinded.jsonl" --output "$OUT/agent_outputs/$SAFE_LABEL.jsonl" --provider "$PROVIDER" --model "$MODEL" --label "$LABEL" --resume
  echo "AGENT_OUTPUT=$OUT/agent_outputs/$SAFE_LABEL.jsonl"
  exit 0
fi

if [[ "$MODE" == "--finalize" ]]; then
  OUT="${RFC_FINAL_EVAL_OUT:?Set RFC_FINAL_EVAL_OUT to a prepared final evaluation run directory}"
  AGENT="${RFC_FINAL_AGENT_OUTPUT:?Set RFC_FINAL_AGENT_OUTPUT to the completed blinded agent output JSONL}"
  echo "[FINALIZE 1/4] Join explicit agent decisions + independent oracle + frozen method replay"
  python "$HERE/final_evaluation.py" join-ablation --methods "$OUT/casepack_methods.jsonl" --oracle "$OUT/casepack_oracle.jsonl" --agent "$AGENT" --output "$OUT/ablation_rows.jsonl"
  echo "[FINALIZE 2/4] Compute overall/category/scenario method metrics"
  python "$HERE/final_evaluation.py" evaluate --input "$OUT/ablation_rows.jsonl" --output "$OUT/FINAL_ABLATION_RESULTS.json"
  echo "[FINALIZE 3/4] Build final scientific summary"
  python "$HERE/final_evaluation.py" final-summary --casepack-summary "$OUT/CASEPACK_SUMMARY.json" --evaluation "$OUT/FINAL_ABLATION_RESULTS.json" --formal-progress "$OUT/formal_progress.json" --juice-oracle "$OUT/juice_shop_oracle_source_freeze.json" --output "$OUT/FINAL_EVALUATION_SUMMARY.json"
  echo "[FINALIZE 4/4] Freeze immutable final manifest"
  python "$HERE/final_evaluation.py" manifest --root "$OUT" --name FINAL_MANIFEST.sha256 --exclude PRE_AGENT_MANIFEST.sha256
  echo "COMPLETE=$OUT"
  exit 0
fi

echo "Usage: $0 --prepare | --agent | --finalize" >&2
exit 2
