#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
EXP="$(cd "$HERE/.." && pwd)"
EXT="$EXP/external"
PREP="${RFC_PHASE2_PREP:-$EXT/phase2}"
WORKSPACE="${RFC_PHASE2_WORKSPACE:-$EXT/phase2_sources}"
RUN_ID="${RFC_PHASE2_CORRECTION_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-p2c541-$$}"
OUT="${RFC_PHASE2_CORRECTION_OUT:-$EXT/phase2_correction_runs/$RUN_ID}"
MODE="${1:---execute}"
PRIOR_RUN="${RFC_PHASE2_PRIOR_V54_RUN:-}"
AGENT_OUTPUTS="${RFC_PHASE2_AGENT_OUTPUTS:-}"
ORACLE_OUTPUTS="${RFC_PHASE2_ORACLE_OUTPUTS:-}"
mkdir -p "$OUT/execution"

echo "[V5.4.1 1/6] Verify frozen Phase-1/Phase-2 sources"
python "$HERE/phase2_final_runner.py" verify --prep "$PREP" --output "$OUT/preflight.json"

echo "[V5.4.1 2/6] Freeze correction runtimes (source build for Juice Shop/PyGoat)"
set +e
if [[ "$MODE" == "--plan-only" ]]; then
  python "$HERE/phase2_correction_v541.py" runtime-freeze --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/runtime_freeze_v541.json"
  RT_RC=$?
else
  python "$HERE/phase2_correction_v541.py" runtime-freeze --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/runtime_freeze_v541.json" --resolve
  RT_RC=$?
fi
set -e
if [[ $RT_RC -ne 0 ]]; then
  echo "[V5.4.1] Runtime freeze had fail-closed rows; continuing so all correction artifacts are preserved."
fi

echo "[V5.4.1 3/6] Rebuild BenchmarkJava stress corpus with strict schema/truth validation"
python "$HERE/phase2_correction_v541.py" stress --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/benchmark_stress_v541.json" --blinded-output "$OUT/benchmark_stress_blinded_v541.jsonl" --oracle-output "$OUT/benchmark_stress_oracle_v541.jsonl"

if [[ "$MODE" == "--plan-only" ]]; then
  printf '{"status":"NOT_RUN","reason":"plan-only"}\n' > "$OUT/ablation_results_v541.json"
else
  echo "[V5.4.1 4/6] Execute source-aligned Juice Shop/PyGoat and VulnerableApp source-grounding"
  python "$HERE/phase2_correction_v541.py" execute --runtime "$OUT/runtime_freeze_v541.json" --outdir "$OUT/execution"

  echo "[V5.4.1 5/6] Materialize 5-way ablation only from explicit agent + independent-oracle files"
  set +e
  if [[ -n "$AGENT_OUTPUTS" && -n "$ORACLE_OUTPUTS" ]]; then
    python "$HERE/phase2_correction_v541.py" ablation-materialize --execution-dir "$OUT/execution" --agent-outputs "$AGENT_OUTPUTS" --oracle-outputs "$ORACLE_OUTPUTS" --output "$OUT/ablation_inputs_v541.jsonl"
    MAT_RC=$?
    if [[ $MAT_RC -eq 0 ]]; then
      python "$HERE/phase2_controller.py" ablation --input "$OUT/ablation_inputs_v541.jsonl" --output "$OUT/ablation_results_v541.json"
    else
      cp "$OUT/ablation_inputs_v541.summary.json" "$OUT/ablation_results_v541.json"
    fi
  else
    printf '{"status":"FAIL_CLOSED","reason":"Set both RFC_PHASE2_AGENT_OUTPUTS and RFC_PHASE2_ORACLE_OUTPUTS; neither is inferred from RFC/validator outputs"}\n' > "$OUT/ablation_results_v541.json"
  fi
  set -e
fi

echo "[V5.4.1 6/6] Aggregate correction report and immutable manifest"
AGG=(python "$HERE/phase2_correction_v541.py" aggregate --preflight "$OUT/preflight.json" --runtime "$OUT/runtime_freeze_v541.json" --execution-dir "$OUT/execution" --stress "$OUT/benchmark_stress_v541.json" --ablation "$OUT/ablation_results_v541.json" --output "$OUT/PHASE2_V541_SUMMARY.json")
if [[ -n "$PRIOR_RUN" ]]; then AGG+=(--prior-run "$PRIOR_RUN"); fi
"${AGG[@]}" || true

python - "$OUT" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); files=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.sha256': files.append((hashlib.sha256(p.read_bytes()).hexdigest(),str(p.relative_to(root))))
(root/'MANIFEST.sha256').write_text(''.join(f'{h}  {n}\n' for h,n in files))
print(json.dumps({'status':'COMPLETE','run_dir':str(root),'files_hashed':len(files)},indent=2))
PY
