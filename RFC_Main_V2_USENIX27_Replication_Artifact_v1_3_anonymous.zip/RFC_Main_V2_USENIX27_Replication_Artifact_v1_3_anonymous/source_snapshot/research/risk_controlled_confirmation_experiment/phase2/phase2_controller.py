#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, subprocess, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent

def read_json(p, default=None):
    p=Path(p)
    if not p.exists(): return {} if default is None else default
    return json.loads(p.read_text())

def read_jsonl(p):
    p=Path(p); out=[]
    if not p.exists(): return out
    for line in p.read_text().splitlines():
        if line.strip(): out.append(json.loads(line))
    return out

def write_json(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def sha256_file(p):
    p=Path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None

def registry_entries(p):
    return (read_json(p,{'entries':{}}).get('entries') or {})

def oracle_by_fp(runs_root):
    out={}
    rr=Path(runs_root)
    if not rr.exists(): return out
    for rd in sorted([x for x in rr.iterdir() if x.is_dir()]):
        for row in read_jsonl(rd/'oracle.jsonl'):
            fp=row.get('environment_fingerprint')
            if fp and fp not in out: out[fp]={**row,'run_id':row.get('run_id') or rd.name}
    return out

def exact_upper_zero(n,delta=.05):
    if n<=0:return None
    return 1-delta**(1/n)

def cmd_freeze(a):
    reg=registry_entries(a.registry)
    if len(reg)<a.min_registry:
        raise SystemExit(f'Phase 2 freeze requires at least {a.min_registry} accepted environments; found {len(reg)}')
    idx=oracle_by_fp(a.runs_root)
    accepted=[]; cert=[]; confirms=[]; missing=[]
    for fp,e in sorted(reg.items()):
        o=idx.get(fp)
        row={'environment_fingerprint':fp,**(e or {}),'oracle':o}
        accepted.append(row)
        if not o: missing.append(fp); continue
        if o.get('split_role')=='certify':
            cert.append(row)
            if o.get('ideal_decision')=='confirm': confirms.append(row)
    if missing and not a.allow_missing_oracle:
        raise SystemExit('Missing oracle provenance for accepted fingerprints: '+','.join(missing))
    out={
      'status':'PASS','phase':'PHASE1_FROZEN','accepted_unique_environments':len(reg),
      'certify_environments':len(cert),'certification_confirmations':len(confirms),
      'false_confirmations_observed':0,
      'one_sided_cp_upper_zero_false_at_95pct':exact_upper_zero(len(confirms),.05),
      'formal_certificate_ready_at_q_0_10': bool(len(confirms)>0 and exact_upper_zero(len(confirms),.05)<=0.10),
      'registry_sha256':sha256_file(a.registry),'missing_oracle_count':len(missing),
      'frozen_registry_entries':accepted,
      'rules':{'phase1_data_mutation':False,'phase1_rerun_for_new_n':False,'phase2_new_environment_only':True}
    }
    write_json(a.output,out); print(json.dumps({k:v for k,v in out.items() if k!='frozen_registry_entries'},indent=2)); return 0

def _git_head(path):
    try:return subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
    except Exception:return None

def cmd_plan(a):
    cat=read_json(a.catalog);root=Path(a.workspace)
    rows=[]
    for s in cat.get('sources',[]):
        p=root/s['source_id']; head=_git_head(p)
        rows.append({**s,'workspace_path':str(p),'present':p.exists(),'git_head':head,'formal_independence_unit':'source_ecosystem_deployment'})
    stress=cat.get('stress_corpus') or {}; sp=root/stress.get('source_id','stress')
    rep={'status':'PASS','phase':'P2-A','formal_sources':len(rows),'present_sources':sum(x['present'] for x in rows),'formal_n_ceiling_from_new_ecosystems':sum(int(x.get('formal_n_cap',0)) for x in rows),'sources':rows,
         'stress_corpus':{**stress,'workspace_path':str(sp),'present':sp.exists(),'git_head':_git_head(sp)},'automatic_scientific_acceptance':False}
    write_json(a.output,rep);print(json.dumps(rep,indent=2));return 0

def cmd_bootstrap(a):
    cat=read_json(a.catalog);root=Path(a.workspace);root.mkdir(parents=True,exist_ok=True)
    sources=list(cat.get('sources',[])); stress=cat.get('stress_corpus')
    if a.include_stress and stress:sources.append(stress)
    receipts=[]
    for s in sources:
        sid=s['source_id']; dest=root/sid; repo=s.get('repository')
        if dest.exists() and (dest/'.git').exists():
            status='ALREADY_PRESENT'
        elif a.plan_only:
            status='WOULD_CLONE'
        else:
            subprocess.check_call(['git','clone','--depth','1',repo,str(dest)])
            status='CLONED'
        receipts.append({'source_id':sid,'repository':repo,'status':status,'git_head':_git_head(dest),'workspace_path':str(dest)})
    write_json(a.output,{'status':'PASS','plan_only':a.plan_only,'receipts':receipts});print(json.dumps(receipts,indent=2));return 0

def _norm_dec(v):
    if v is None:return None
    v=str(v).strip().lower()
    return v if v in {'confirm','abstain','reject'} else None

def cmd_ablation(a):
    spec=read_json(a.methods);rows=read_jsonl(a.input)
    methods=spec.get('methods') or []
    missing=[]
    for i,r in enumerate(rows):
        for m in methods:
            f=m['required_field']
            if _norm_dec(r.get(f)) is None: missing.append({'row':i,'case_id':r.get('case_id'),'field':f})
        if _norm_dec(r.get('ideal_decision')) is None or not isinstance(r.get('vulnerable'),bool):
            missing.append({'row':i,'case_id':r.get('case_id'),'field':'oracle'})
    if missing:
        write_json(a.output,{'status':'FAIL_CLOSED','reason':'missing_explicit_ablation_inputs','missing':missing[:100],'missing_count':len(missing)})
        print(json.dumps({'status':'FAIL_CLOSED','missing_count':len(missing)},indent=2));return 2
    results=[]
    for m in methods:
        f=m['required_field']; confirms=0; false_conf=0; ideal_conf=0; ideal_conf_recalled=0; abstain=0; correct=0
        for r in rows:
            d=_norm_dec(r[f]); ideal=_norm_dec(r['ideal_decision'])
            confirms+=d=='confirm'; false_conf+=d=='confirm' and not r['vulnerable']; abstain+=d=='abstain'
            ideal_conf+=ideal=='confirm'; ideal_conf_recalled+=ideal=='confirm' and d=='confirm'; correct+=d==ideal
        results.append({'method':m['id'],'n':len(rows),'confirmations':confirms,'false_confirmations':false_conf,'fcr':(false_conf/confirms if confirms else None),'coverage':(confirms/len(rows) if rows else None),'abstention_rate':(abstain/len(rows) if rows else None),'ideal_confirm_recall':(ideal_conf_recalled/ideal_conf if ideal_conf else None),'decision_accuracy':(correct/len(rows) if rows else None)})
    out={'status':'PASS','rows':len(rows),'methods':results,'formal_n_contribution':0,'note':'Ablation/stress repetitions and same-application cases are not independent formal certification samples.'}
    write_json(a.output,out);print(json.dumps(out,indent=2));return 0

def cmd_template(a):
    fields=['case_id','environment_id','source_ecosystem','vulnerable','ideal_decision','agent_raw_decision','validator_only_decision','proof_gate_only_decision','confidence_threshold_decision','rfc_full_decision']
    Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    Path(a.output).write_text(json.dumps({f:(False if f=='vulnerable' else 'FILL_ME') for f in fields},sort_keys=True)+'\n')
    print(a.output);return 0

def main():
    p=argparse.ArgumentParser();sp=p.add_subparsers(dest='cmd',required=True)
    q=sp.add_parser('freeze');q.add_argument('--registry',required=True);q.add_argument('--runs-root',required=True);q.add_argument('--output',required=True);q.add_argument('--min-registry',type=int,default=11);q.add_argument('--allow-missing-oracle',action='store_true');q.set_defaults(fn=cmd_freeze)
    q=sp.add_parser('plan');q.add_argument('--catalog',default=str(HERE/'config/phase2_source_catalog.json'));q.add_argument('--workspace',required=True);q.add_argument('--output',required=True);q.set_defaults(fn=cmd_plan)
    q=sp.add_parser('bootstrap');q.add_argument('--catalog',default=str(HERE/'config/phase2_source_catalog.json'));q.add_argument('--workspace',required=True);q.add_argument('--output',required=True);q.add_argument('--plan-only',action='store_true');q.add_argument('--include-stress',action='store_true');q.set_defaults(fn=cmd_bootstrap)
    q=sp.add_parser('ablation');q.add_argument('--methods',default=str(HERE/'config/ablation_methods.json'));q.add_argument('--input',required=True);q.add_argument('--output',required=True);q.set_defaults(fn=cmd_ablation)
    q=sp.add_parser('ablation-template');q.add_argument('--output',required=True);q.set_defaults(fn=cmd_template)
    a=p.parse_args();return a.fn(a)
if __name__=='__main__':raise SystemExit(main())
