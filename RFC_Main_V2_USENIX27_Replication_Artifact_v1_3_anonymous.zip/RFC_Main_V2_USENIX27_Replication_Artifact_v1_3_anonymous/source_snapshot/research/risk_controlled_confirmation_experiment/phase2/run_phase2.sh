#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
EXP="$(cd "$HERE/.." && pwd)"
ROOT="$(cd "$EXP/../.." && pwd)"
EXT="$EXP/external"
REG="$EXT/scientifically_accepted_environment_registry.json"
RUNS="$EXT/runs"
WORKSPACE="${RFC_PHASE2_WORKSPACE:-$EXT/phase2_sources}"
OUT="${RFC_PHASE2_OUT:-$EXT/phase2}"
MODE="${1:---plan-only}"
mkdir -p "$OUT"
python "$HERE/phase2_controller.py" freeze --registry "$REG" --runs-root "$RUNS" --output "$OUT/PHASE1_FREEZE.json" --min-registry 11
case "$MODE" in
  --plan-only)
    python "$HERE/phase2_controller.py" bootstrap --workspace "$WORKSPACE" --output "$OUT/bootstrap_plan.json" --plan-only --include-stress
    ;;
  --bootstrap)
    python "$HERE/phase2_controller.py" bootstrap --workspace "$WORKSPACE" --output "$OUT/bootstrap_receipts.json" --include-stress
    ;;
  *) echo "usage: $0 [--plan-only|--bootstrap]" >&2; exit 2 ;;
esac
python "$HERE/phase2_controller.py" plan --workspace "$WORKSPACE" --output "$OUT/source_plan.json"
python "$HERE/phase2_controller.py" ablation-template --output "$OUT/ablation_inputs_template.jsonl"
printf 'Phase 2 preparation complete.\nOutputs: %s\n' "$OUT"
