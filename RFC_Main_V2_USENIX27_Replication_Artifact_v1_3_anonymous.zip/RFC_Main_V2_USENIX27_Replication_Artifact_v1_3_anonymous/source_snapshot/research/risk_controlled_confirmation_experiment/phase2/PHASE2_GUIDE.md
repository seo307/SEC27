# RFC/Main-V2 Phase 2 — External Validity + Baseline/Ablation

## Frozen Phase 1

Phase 1 is immutable. Phase 2 must begin only after the scientific registry contains at least 11 explicitly accepted environments. Existing runs are read-only and cannot be rerun to create new independent N.

## P2-A: independent external ecosystems

The source catalog contains six deliberately vulnerable application ecosystems. Each ecosystem is capped at **one formal independent contribution**, even if multiple challenges are exercised inside it. Additional challenges are useful for stress/ablation only.

Priority: server-side, read-only or authentication/authorization differential proof. Destructive operations, persistence, command execution, arbitrary file write, and browser-only XSS are not primary formal confirmation recipes.

## P2-B: baseline/ablation stress corpus

OWASP Benchmark Java is intentionally kept outside formal N. It can provide many labeled test cases for method comparison, but those cases share an application/runtime and are not treated as independent certification environments.

The ablation evaluator requires explicit outputs for all five methods:

1. agent_raw
2. validator_only
3. proof_gate_only
4. confidence_threshold
5. rfc_full

It **fails closed** rather than infer a baseline from oracle labels or from another method's output.

## First run

```bash
research/risk_controlled_confirmation_experiment/phase2/run_phase2.sh --plan-only
```

Then, if the plan is correct:

```bash
research/risk_controlled_confirmation_experiment/phase2/run_phase2.sh --bootstrap
```

This clones the official source repositories and records exact Git commit SHAs. It does not execute vulnerability proofs or mutate the scientific registry.

## Next artifact expected

Upload the generated `external/phase2/` directory (or ZIP it) after bootstrap. The next step is a **single adapter batch** against the frozen commits, not a sequence of changing upstream `latest` environments.
