#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
EXP="$(cd "$HERE/.." && pwd)"
EXT="$EXP/external"
PREP="${RFC_PHASE2_PREP:-$EXT/phase2}"
WORKSPACE="${RFC_PHASE2_WORKSPACE:-$EXT/phase2_sources}"
RUN_ID="${RFC_PHASE2_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-p2final-$$}"
OUT="${RFC_PHASE2_FINAL_OUT:-$EXT/phase2_final_runs/$RUN_ID}"
MODE="${1:---plan-only}"
AGENT_OUTPUTS="${RFC_PHASE2_AGENT_OUTPUTS:-}"
mkdir -p "$OUT/execution"

python "$HERE/phase2_final_runner.py" verify --prep "$PREP" --output "$OUT/preflight.json"

case "$MODE" in
  --plan-only)
    python "$HERE/phase2_final_runner.py" runtime-freeze --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/runtime_freeze.json"
    python "$HERE/phase2_final_runner.py" stress --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/benchmark_stress.json" --blinded-output "$OUT/benchmark_stress_blinded.jsonl" --oracle-output "$OUT/benchmark_stress_oracle.jsonl"
    ;;
  --execute)
    python "$HERE/phase2_final_runner.py" runtime-freeze --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/runtime_freeze.json" --resolve
    python "$HERE/phase2_final_runner.py" execute --runtime "$OUT/runtime_freeze.json" --outdir "$OUT/execution"
    python "$HERE/phase2_final_runner.py" stress --prep "$PREP" --workspace "$WORKSPACE" --output "$OUT/benchmark_stress.json" --blinded-output "$OUT/benchmark_stress_blinded.jsonl" --oracle-output "$OUT/benchmark_stress_oracle.jsonl"
    set +e
    if [[ -n "$AGENT_OUTPUTS" ]]; then
      python "$HERE/phase2_final_runner.py" ablation-materialize --execution-dir "$OUT/execution" --agent-outputs "$AGENT_OUTPUTS" --output "$OUT/ablation_inputs.jsonl"
      MAT_RC=$?
      if [[ $MAT_RC -eq 0 ]]; then
        python "$HERE/phase2_controller.py" ablation --input "$OUT/ablation_inputs.jsonl" --output "$OUT/ablation_results.json"
      fi
    else
      printf '{"status":"FAIL_CLOSED","reason":"RFC_PHASE2_AGENT_OUTPUTS not supplied; agent_raw and oracle are not inferred"}\n' > "$OUT/ablation_results.json"
    fi
    set -e
    ;;
  *) echo "usage: $0 [--plan-only|--execute]" >&2; exit 2 ;;
esac

python "$HERE/phase2_final_runner.py" aggregate --preflight "$OUT/preflight.json" --runtime "$OUT/runtime_freeze.json" --execution-dir "$OUT/execution" --stress "$OUT/benchmark_stress.json" --ablation "$OUT/ablation_results.json" --output "$OUT/PHASE2_FINAL_SUMMARY.json"

python - "$OUT" <<'PY2'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); files=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.sha256': files.append((hashlib.sha256(p.read_bytes()).hexdigest(),str(p.relative_to(root))))
(root/'MANIFEST.sha256').write_text(''.join(f'{h}  {n}\n' for h,n in files))
print(json.dumps({'status':'COMPLETE','run_dir':str(root),'files_hashed':len(files)},indent=2))
PY2
