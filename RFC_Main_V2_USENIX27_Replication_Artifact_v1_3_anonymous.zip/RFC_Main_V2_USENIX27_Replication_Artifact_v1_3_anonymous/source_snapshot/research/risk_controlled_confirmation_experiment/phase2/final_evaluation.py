#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, csv, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
from collections import defaultdict, Counter

HERE=Path(__file__).resolve().parent
EXP=HERE.parent
EXT=EXP/'external'
DEFAULT_RULES=HERE/'config/final_eval_methods.json'
DECISIONS={'confirm','abstain'}
FORBIDDEN_AGENT_KEY_FRAGMENTS=(
    'oracle','ideal_decision','vulnerable','split_role','independence','validator',
    'proof_obligation','proof_valid','scenario_kind','scientific','confidence',
    'registry','formal_candidate','formal_n'
)
AGENT_METADATA_DROP_KEYS={
    'case_id','capture_id','group_id','run_id','repetition','title','source_class','pair_id',
    'target_state_id','environment_fingerprint','finding_fingerprint','scenario_fingerprint'
}
FORBIDDEN_AGENT_VALUE_MARKERS=('negative_control','ambiguous_positive','positive_confirmable')


def now():
    import datetime
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
    p=Path(p); return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def read_json(p,default=None):
    p=Path(p)
    if not p.exists(): return {} if default is None else default
    return json.loads(p.read_text())

def read_jsonl(p):
    p=Path(p); out=[]
    if not p.exists(): return out
    for line in p.read_text().splitlines():
        if line.strip(): out.append(json.loads(line))
    return out

def write_json(p,o):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')

def write_jsonl(p,rows):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n' for x in rows))

def norm_dec(v):
    v=str(v or '').strip().lower()
    if v=='reject': return 'abstain'
    return v if v in DECISIONS else None

def exact_upper_zero(n,delta=.05):
    return None if n<=0 else 1-delta**(1/n)

def registry_entries(path):
    x=read_json(path,{'entries':{}})
    return x.get('entries') or {}

def _first_validator(capture):
    try:
        rc=capture['result']['rfc_capture']
        vals=rc.get('validator_results') or []
        if vals: return vals[0]
        recs=rc.get('validation_records') or []
        if recs: return recs[0].get('validator_result') or {}
    except Exception: pass
    return {}

def _evidence_ids(capture):
    try:return {str(x.get('id')) for x in capture['result']['rfc_capture'].get('evidences',[]) if x.get('id')}
    except Exception:return set()

def proof_gate_from_capture(capture,ledger):
    if (ledger or {}).get('capture_validity')!='CAPTURE_OK_EVIDENTIARY': return 'abstain',{'reason':'capture_not_evidentiary'}
    v=_first_validator(capture); po=v.get('proof_obligation_evidence') or {}
    if not po: return 'abstain',{'reason':'no_logged_proof_obligations'}
    eids=_evidence_ids(capture); missing=[]
    for name,refs in po.items():
        refs=[str(x) for x in (refs or []) if x]
        if not refs: missing.append({'obligation':name,'reason':'empty'})
        elif not any(x in eids for x in refs): missing.append({'obligation':name,'reason':'evidence_id_not_present','refs':refs})
    if missing:return 'abstain',{'reason':'unbound_proof_obligation','details':missing}
    return 'confirm',{'reason':'all_logged_proof_obligations_bound','obligations':sorted(po)}

def method_replay_standard(capture,ledger,threshold):
    v=_first_validator(capture); status=str(v.get('status') or '').lower(); conf=float(v.get('confidence') or 0.0)
    validator='confirm' if status=='confirmed' else 'abstain'
    proof,proof_meta=proof_gate_from_capture(capture,ledger)
    ct='confirm' if conf>=threshold else 'abstain'
    full='confirm' if proof=='confirm' and ct=='confirm' else 'abstain'
    return {
      'validator_only_decision':validator,
      'proof_gate_only_decision':proof,
      'confidence_threshold_decision':ct,
      'rfc_full_decision':full,
      'validator_status':status or None,'validator_confidence':conf,'proof_replay':proof_meta,
      'decision_source':'replayed_from_frozen_capture_final_eval_v1'
    }

def _sanitize_agent_obj(obj):
    if isinstance(obj,dict):
        out={}
        for k,v in obj.items():
            kl=str(k).lower()
            if any(f in kl for f in FORBIDDEN_AGENT_KEY_FRAGMENTS): continue
            if kl in AGENT_METADATA_DROP_KEYS: continue
            if kl in {'validation_records','validator_results','lifecycle_finding','limitations','tags','trace_events'}: continue
            out[k]=_sanitize_agent_obj(v)
        return out
    if isinstance(obj,list): return [_sanitize_agent_obj(x) for x in obj]
    return obj

def forbidden_paths(obj,path='$'):
    bad=[]
    if isinstance(obj,dict):
        for k,v in obj.items():
            kl=str(k).lower(); p=f'{path}.{k}'
            if any(f in kl for f in FORBIDDEN_AGENT_KEY_FRAGMENTS): bad.append(p)
            bad.extend(forbidden_paths(v,p))
    elif isinstance(obj,list):
        for i,v in enumerate(obj): bad.extend(forbidden_paths(v,f'{path}[{i}]'))
    return bad

def forbidden_value_paths(obj,path='$'):
    bad=[]
    if isinstance(obj,dict):
        for k,v in obj.items(): bad.extend(forbidden_value_paths(v,f'{path}.{k}'))
    elif isinstance(obj,list):
        for i,v in enumerate(obj): bad.extend(forbidden_value_paths(v,f'{path}[{i}]'))
    elif isinstance(obj,str):
        s=obj.lower()
        if any(x in s for x in FORBIDDEN_AGENT_VALUE_MARKERS) or re.search(r'(^|[_-])neg(?:ative)?([_-]|$)',s): bad.append(path)
    return bad

def _assert_agent_blinded(obj,label='agent input'):
    bad=forbidden_paths(obj); vals=forbidden_value_paths(obj)
    if bad or vals:
        detail=[f'key:{x}' for x in bad[:10]]+[f'value:{x}' for x in vals[:10]]
        raise RuntimeError(f'{label} blinding failed: '+','.join(detail))

def _agent_view_standard(capture):
    x=copy.deepcopy(capture)
    view={
      'category':x.get('category'),
      'candidate_and_observations':(x.get('result') or {}).get('rfc_capture') or {}
    }
    view=_sanitize_agent_obj(view)
    _assert_agent_blinded(view,'standard agent view')
    return view

def _agent_view_phase2(row):
    res=row.get('result') or {}
    view={'category':row.get('category'),'candidate_and_observations':{'observations':res.get('observations') or []}}
    view=_sanitize_agent_obj(view)
    _assert_agent_blinded(view,'phase2 agent view')
    return view

def _run_dirs(root):
    root=Path(root)
    return sorted([p for p in root.iterdir() if p.is_dir()]) if root.exists() else []

def collect_standard_cases(runs_root,registry,rules,include_unregistered=False):
    reg=registry_entries(registry); reg_by_fp=reg
    candidates=defaultdict(list)
    for rd in _run_dirs(runs_root):
        caps={str(x.get('group_id')):x for x in read_jsonl(rd/'captures_blinded.jsonl')}
        ors={str(x.get('group_id')):x for x in read_jsonl(rd/'oracle.jsonl')}
        led=read_json(rd/'acquisition_ledger.json',{'rows':[]}); lmap={str(x.get('group_id')):x for x in led.get('rows',[])}
        for gid,o in ors.items():
            fp=o.get('environment_fingerprint'); c=caps.get(gid); l=lmap.get(gid) or {}
            if not fp or not c or l.get('capture_validity')!='CAPTURE_OK_EVIDENTIARY': continue
            candidates[fp].append({'run_dir':rd,'run_id':rd.name,'group_id':gid,'capture':c,'oracle':o,'ledger':l})
    chosen=[]
    for fp,rows in candidates.items():
        entry=reg_by_fp.get(fp) or {}
        accepted_run=entry.get('first_accepted_run_id')
        exact=[x for x in rows if accepted_run and x['run_id']==accepted_run]
        if exact: row=sorted(exact,key=lambda x:x['run_id'])[0]
        else: row=sorted(rows,key=lambda x:x['run_id'])[0]
        row['registry_accepted']=fp in reg_by_fp; row['registry_entry']=entry
        if row['registry_accepted'] or include_unregistered:
            chosen.append(row)
    out=[]; threshold=float(rules.get('confidence_threshold',.8))
    for x in sorted(chosen,key=lambda z:(z['oracle'].get('category',''),z['group_id'])):
        m=method_replay_standard(x['capture'],x['ledger'],threshold)
        o=x['oracle']; l=x['ledger']; fp=o.get('environment_fingerprint')
        agent=_agent_view_standard(x['capture'])
        out.append({
          'case_id':x['group_id'],'environment_fingerprint':fp,'run_id':x['run_id'],'category':o.get('category') or x['capture'].get('category'),
          'scenario_kind':l.get('scenario_kind'),'source_ecosystem':o.get('software_product') or o.get('source_class') or 'phase1_external',
          'registry_accepted':x['registry_accepted'],'capture_sha256':sha_file(x['run_dir']/'captures_blinded.jsonl'),'oracle_sha256':sha_file(x['run_dir']/'oracle.jsonl'),
          'oracle':{'vulnerable':o.get('vulnerable'),'ideal_decision':norm_dec(o.get('ideal_decision')),'oracle_source':o.get('oracle_source'),'oracle_independent_of_validator':o.get('oracle_independent_of_validator'),'split_role':o.get('split_role')},
          'methods':m,'agent_input':agent,'formal_n_contribution':0,'cohort':'external_reviewed' if x['registry_accepted'] else 'external_unregistered_stress',
          'selection_rule':'one earliest evidentiary capture per environment fingerprint, except registry-accepted environments use first_accepted_run_id when available'
        })
    return out

def collect_internal_stress(captures_path,oracle_path,rules):
    cp=Path(captures_path); op=Path(oracle_path)
    if not cp.is_file() or not op.is_file(): return []
    caps=read_jsonl(cp); ors=read_jsonl(op)
    ob={str(x.get('capture_id')):x for x in ors}
    # Repetitions are repeated measurements, not independent cases. Prespecify the lowest repetition per case.
    by_case=defaultdict(list)
    for c in caps:
        if c.get('case_id') and c.get('capture_id') in ob: by_case[str(c['case_id'])].append(c)
    out=[]; threshold=float(rules.get('confidence_threshold',.8))
    for case_id,rows in sorted(by_case.items()):
        c=sorted(rows,key=lambda x:(int(x.get('repetition') or 10**9),str(x.get('capture_id'))))[0]
        o=ob[c['capture_id']]
        # Legacy controlled captures predate proof-bundle binding. Applying the frozen final rule therefore abstains when obligations are absent.
        ledger={'capture_validity':'CAPTURE_OK_EVIDENTIARY'}
        m=method_replay_standard(c,ledger,threshold)
        ideal=norm_dec(o.get('ideal_decision')); vuln=o.get('vulnerable')
        scenario='negative_control' if vuln is False else ('positive_confirmable' if ideal=='confirm' else 'ambiguous_positive')
        fp=sha_bytes(('internal_controlled_stress|'+case_id).encode())
        out.append({
          'case_id':case_id,'environment_fingerprint':fp,'run_id':'work/live','category':c.get('category') or o.get('category'),'scenario_kind':scenario,
          'source_ecosystem':'internal_controlled_benchmark','registry_accepted':False,'capture_sha256':sha_file(cp),'oracle_sha256':sha_file(op),
          'oracle':{'vulnerable':vuln,'ideal_decision':ideal,'oracle_source':f'{op.name}::{c.get("capture_id")}', 'oracle_independent_of_validator':True,'split_role':None,'original_ideal_decision':o.get('ideal_decision')},
          'methods':m,'agent_input':_agent_view_standard(c),'formal_n_contribution':0,'cohort':'internal_controlled_stress',
          'selection_rule':'lowest repetition per case_id; repetitions are not independent and are excluded from primary ablation N'
        })
    return out

def _phase2_juice_case(correction_run,juice_oracle,rules):
    if not correction_run or not juice_oracle:return None
    cr=Path(correction_run); rows=read_jsonl(cr/'execution/phase2_correction_rows.jsonl'); js=[x for x in rows if x.get('source_id')=='P2-OWASP-JUICE-SHOP']
    if not js:return None
    x=js[0]; o=read_json(juice_oracle)
    if o.get('status')!='PASS': raise RuntimeError('Juice oracle freeze is not PASS')
    if o.get('environment_fingerprint')!=x.get('environment_fingerprint'): raise RuntimeError('Juice oracle/capture environment fingerprint mismatch')
    mo=x.get('method_outputs') or {}
    need=['validator_only_decision','proof_gate_only_decision','confidence_threshold_decision','rfc_full_decision']
    if any(norm_dec(mo.get(k)) is None for k in need): raise RuntimeError('Juice row lacks explicit method outputs')
    return {
      'case_id':'P2-OWASP-JUICE-SHOP','environment_fingerprint':x.get('environment_fingerprint'),'run_id':cr.name,'category':x.get('category') or 'sqli','scenario_kind':'positive_confirmable',
      'source_ecosystem':'OWASP Juice Shop','registry_accepted':False,'capture_sha256':sha_file(cr/'execution/P2-OWASP-JUICE-SHOP.json'),'oracle_sha256':sha_file(juice_oracle),
      'oracle':{'vulnerable':o.get('vulnerable'),'ideal_decision':norm_dec(o.get('ideal_decision')),'oracle_source':o.get('oracle_source'),'oracle_independent_of_validator':o.get('oracle_independent_of_validator'),'split_role':'certify','oracle_timing':o.get('oracle_timing')},
      'methods':{**{k:norm_dec(mo.get(k)) for k in need},'decision_source':'logged_v5_4_1_method_outputs'},'agent_input':_agent_view_phase2(x),'formal_n_contribution':0,'cohort':'phase2_external_candidate',
      'selection_rule':'predeclared Phase-2 ecosystem; source/runtime-aligned evidentiary capture; formal registry admission remains separate explicit review'
    }

def build_casepack(a):
    rules=read_json(a.rules); cases=collect_standard_cases(a.runs_root,a.registry,rules,a.include_unregistered_evidentiary)
    reg=registry_entries(a.registry)
    represented={x.get('environment_fingerprint') for x in cases if x.get('registry_accepted')}
    missing_registry=sorted(set(reg)-represented)
    if missing_registry and not a.allow_missing_registry:
        raise RuntimeError('accepted registry environments missing from evidentiary casepack: '+','.join(missing_registry))
    internal=[]
    if a.include_internal_stress:
        internal=collect_internal_stress(a.internal_captures,a.internal_oracle,rules)
        if not internal and not a.allow_missing_internal_stress:
            raise RuntimeError('internal controlled stress corpus requested but not found')
        cases.extend(internal)
    js=_phase2_juice_case(a.phase2_correction_run,a.juice_oracle,rules) if a.phase2_correction_run and a.juice_oracle else None
    if js: cases.append(js)
    # Unique case/environment invariant.
    seen=set(); ded=[]
    for x in cases:
        fp=x.get('environment_fingerprint')
        if fp in seen: raise RuntimeError('duplicate environment in final casepack: '+str(fp))
        seen.add(fp); ded.append(x)
    cases=sorted(ded,key=lambda x:x['case_id'])
    out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    agent_rows=[]; oracle_rows=[]; method_rows=[]; map_rows=[]
    for x in cases:
        eval_id='FE-'+sha_bytes(('final-eval-v1|'+str(x['environment_fingerprint'])).encode())[:16]
        agent={'case_id':eval_id,'category':x['category'],'evidence':x['agent_input']}
        _assert_agent_blinded(agent,'final casepack agent row')
        agent_rows.append(agent)
        map_rows.append({'case_id':eval_id,'source_case_id':x['case_id'],'environment_fingerprint':x['environment_fingerprint'],'category':x['category'],'source_ecosystem':x['source_ecosystem'],'cohort':x.get('cohort'),'run_id':x.get('run_id')})
        oracle_rows.append({'case_id':eval_id,'source_case_id':x['case_id'],'environment_fingerprint':x['environment_fingerprint'],'category':x['category'],'scenario_kind':x.get('scenario_kind'),'source_ecosystem':x['source_ecosystem'],'cohort':x.get('cohort'),**x['oracle'],'formal_n_contribution':0})
        method_rows.append({'case_id':eval_id,'source_case_id':x['case_id'],'environment_fingerprint':x['environment_fingerprint'],'category':x['category'],'scenario_kind':x.get('scenario_kind'),'source_ecosystem':x['source_ecosystem'],'cohort':x.get('cohort'),'registry_accepted':x['registry_accepted'],**{k:v for k,v in x['methods'].items() if k.endswith('_decision')},'method_provenance':x['methods'].get('decision_source'),'formal_n_contribution':0})
    write_jsonl(out/'casepack_agent_blinded.jsonl',agent_rows); write_jsonl(out/'casepack_case_map.jsonl',map_rows); write_jsonl(out/'casepack_oracle.jsonl',oracle_rows); write_jsonl(out/'casepack_methods.jsonl',method_rows)
    write_jsonl(out/'agent_outputs_template.jsonl',[{'case_id':x['case_id'],'decision':None,'note':'FILL ONLY FROM AN EXPLICIT BLINDED AGENT RUN; do not infer from validator/oracle'} for x in agent_rows])
    shutil.copy2(a.rules,out/'FROZEN_METHOD_RULES.json')
    shutil.copy2(a.registry,out/'SCIENTIFIC_REGISTRY_SNAPSHOT.json')
    key_hits=sum(len(forbidden_paths(x)) for x in agent_rows); value_hits=sum(len(forbidden_value_paths(x)) for x in agent_rows)
    summary={'status':'PASS','casepack_version':'final-eval-v1','cases':len(cases),'categories':dict(Counter(x['category'] for x in cases)),'scenarios':dict(Counter(str(x.get('scenario_kind')) for x in cases)),'cohorts':dict(Counter(str(x.get('cohort')) for x in cases)),'internal_stress_cases':len(internal),'registry_accepted_cases':sum(x['registry_accepted'] for x in cases),'registry_expected_cases':len(reg),'registry_missing_cases':len(missing_registry),'phase2_juice_included':bool(js),'include_unregistered_evidentiary':bool(a.include_unregistered_evidentiary),'agent_blinding_forbidden_key_hits':key_hits,'agent_blinding_forbidden_value_hits':value_hits,'agent_ids_opaque':True,'method_rules_sha256':sha_file(out/'FROZEN_METHOD_RULES.json'),'registry_snapshot_sha256':sha_file(out/'SCIENTIFIC_REGISTRY_SNAPSHOT.json'),'formal_n_contribution':0,'generated_at':now()}
    write_json(out/'CASEPACK_SUMMARY.json',summary)
    _write_manifest(out,'PRE_AGENT_MANIFEST.sha256',exclude={'PRE_AGENT_MANIFEST.sha256','FINAL_MANIFEST.sha256'})
    print(json.dumps(summary,indent=2)); return 0

def _git_head(p):
    try:return subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
    except Exception:return None

def _git_clean(p):
    try:return subprocess.check_output(['git','-C',str(p),'status','--porcelain'],text=True).strip()==''
    except Exception:return False

def _find_login_challenge_block(text):
    # Prefer a bounded block containing key loginAdminChallenge and name Login Admin.
    blocks=re.split(r'\n(?=-\s+name:)',text)
    for b in blocks:
        if 'loginAdminChallenge' in b and re.search(r"name:\s*['\"]?Login Admin",b,re.I): return b
    # Fallback around the key.
    m=re.search(r'(.{0,1800}key:\s*loginAdminChallenge.{0,400})',text,re.S)
    return m.group(1) if m else ''

def freeze_juice_oracle(a):
    cr=Path(a.correction_run); rt=read_json(cr/'runtime_freeze_v541.json'); rows=rt.get('rows') or []; rr=next((x for x in rows if x.get('source_id')=='P2-OWASP-JUICE-SHOP'),None)
    if not rr or rr.get('status')!='PASS': raise SystemExit('Juice runtime freeze PASS row not found')
    src=Path(rr.get('workspace_path') or ''); head=_git_head(src); expected=rr.get('git_head') or rr.get('expected_git_head')
    image=((rr.get('image') or {}).get('labels') or {}); revision=image.get('org.opencontainers.image.revision')
    issues=[]
    if not src.exists(): issues.append('source workspace missing')
    if not _git_clean(src): issues.append('source git tree not clean')
    if not head or head!=expected: issues.append(f'git head mismatch: {head} != {expected}')
    if revision and revision!=head: issues.append(f'OCI revision mismatch: {revision} != {head}')
    login=src/'routes/login.ts'; challenges=src/'data/static/challenges.yml'
    if not login.is_file(): issues.append('routes/login.ts missing')
    if not challenges.is_file(): issues.append('data/static/challenges.yml missing')
    lt=login.read_text(errors='replace') if login.is_file() else ''; ct=challenges.read_text(errors='replace') if challenges.is_file() else ''
    checks={
      'login_admin_vuln_marker':bool(re.search(r'vuln-line\s+loginAdminChallenge',lt)),
      'login_query_interpolates_email':bool(re.search(r'SELECT \* FROM Users WHERE email\s*=\s*[`\'\"]?\$\{req\.body\.email',lt)),
      'login_query_interpolates_password':('security.hash(req.body.password' in lt and 'sequelize.query' in lt),
    }
    block=_find_login_challenge_block(ct)
    checks.update({
      'challenge_name_login_admin':bool(re.search(r"name:\s*['\"]?Login Admin",block,re.I)),
      'challenge_category_injection':bool(re.search(r"category:\s*['\"]?Injection",block,re.I)),
      'challenge_key_login_admin':bool(re.search(r'key:\s*loginAdminChallenge',block))
    })
    if not all(checks.values()): issues.append('source oracle predicates not all satisfied')
    erows=read_jsonl(cr/'execution/phase2_correction_rows.jsonl'); er=next((x for x in erows if x.get('source_id')=='P2-OWASP-JUICE-SHOP'),None)
    if not er: issues.append('Juice correction execution row missing')
    if er and er.get('environment_fingerprint')!=rr.get('environment_fingerprint'): issues.append('runtime/execution environment fingerprint mismatch')
    out={
      'status':'PASS' if not issues else 'FAIL_CLOSED','source_id':'P2-OWASP-JUICE-SHOP','environment_fingerprint':rr.get('environment_fingerprint'),
      'vulnerable':True if not issues else None,'ideal_decision':'confirm' if not issues else None,
      'oracle_independent_of_validator':True if not issues else None,'independence_eligible':True if not issues else None,
      'oracle_timing':'post_capture_source_only','formal_registry_admission':'REVIEW_REQUIRED_TIMING_CAVEAT',
      'oracle_source':f'frozen_git:{head}::routes/login.ts + data/static/challenges.yml' if head else None,
      'independence_basis':'Predeclared distinct OWASP Juice Shop ecosystem deployment; truth derived only from frozen source/challenge metadata, not validator or capture outcome.' if not issues else None,
      'source_git_head':head,'runtime_oci_revision':revision,'source_clean':_git_clean(src),
      'source_files':{'routes/login.ts':{'sha256':sha_file(login)},'data/static/challenges.yml':{'sha256':sha_file(challenges)}},
      'source_checks':checks,'issues':issues,'scientific_acceptance_automatic':False,'registry_mutated':False,'generated_at':now()
    }
    write_json(a.output,out); print(json.dumps(out,indent=2)); return 0 if out['status']=='PASS' else 2

def _extract_json_object(text):
    text=text.strip()
    try:return json.loads(text)
    except Exception: pass
    m=re.search(r'\{.*\}',text,re.S)
    if m:
        try:return json.loads(m.group(0))
        except Exception: pass
    return None

def _prompt(row):
    payload=json.dumps(row,sort_keys=True,separators=(',',':'))
    return (
      'You are a penetration-testing agent reviewing one candidate finding and its observed evidence. '
      'Decide whether you would report the finding as CONFIRMED or ABSTAIN based only on the supplied evidence. '
      'Use your best judgment; do not assume hidden benchmark truth. Return only JSON with keys '
      'decision (confirm|abstain), confidence (0..1), and evidence_ids (array of strings).\n\nCASE:\n'+payload
    )

def _call_openai(model,prompt,max_tokens):
    from openai import OpenAI
    c=OpenAI(); r=c.responses.create(model=model,input=prompt,max_output_tokens=max_tokens)
    return r.output_text,{'response_id':getattr(r,'id',None),'model':getattr(r,'model',model)}

def _call_anthropic(model,prompt,max_tokens):
    import anthropic
    c=anthropic.Anthropic(); r=c.messages.create(model=model,max_tokens=max_tokens,messages=[{'role':'user','content':prompt}])
    txt=''.join(getattr(b,'text','') for b in r.content if getattr(b,'type',None)=='text')
    return txt,{'response_id':getattr(r,'id',None),'model':getattr(r,'model',model),'stop_reason':getattr(r,'stop_reason',None)}

def run_agent(a):
    rows=read_jsonl(a.inputs); outp=Path(a.output); done={}
    if a.resume and outp.exists(): done={x.get('case_id'):x for x in read_jsonl(outp)}
    outputs=list(done.values()); calls=0
    for row in rows:
        cid=row.get('case_id')
        if cid in done: continue
        _assert_agent_blinded(row,'refusing to send case '+str(cid))
        if a.max_cases and calls>=a.max_cases: break
        prompt=_prompt(row); inp_sha=sha_bytes(prompt.encode())
        try:
            if a.provider=='openai': text,meta=_call_openai(a.model,prompt,a.max_output_tokens)
            elif a.provider=='anthropic': text,meta=_call_anthropic(a.model,prompt,a.max_output_tokens)
            else: raise RuntimeError('unsupported provider')
            obj=_extract_json_object(text) or {}; dec=norm_dec(obj.get('decision'))
            rec={'case_id':cid,'environment_fingerprint':row.get('environment_fingerprint'),'provider':a.provider,'model':a.model,'agent_label':a.label or f'{a.provider}:{a.model}','decision':dec,'reported_confidence':obj.get('confidence'),'evidence_ids':obj.get('evidence_ids') if isinstance(obj.get('evidence_ids'),list) else [],'input_sha256':inp_sha,'raw_response_sha256':sha_bytes(text.encode()),'raw_response':text,'api_metadata':meta,'completed_at':now(),'status':'PASS' if dec else 'PARSE_FAIL'}
        except Exception as e:
            rec={'case_id':cid,'environment_fingerprint':row.get('environment_fingerprint'),'provider':a.provider,'model':a.model,'agent_label':a.label or f'{a.provider}:{a.model}','decision':None,'input_sha256':inp_sha,'status':'ERROR','error':f'{type(e).__name__}: {e}','completed_at':now()}
        outputs=[x for x in outputs if x.get('case_id')!=cid]+[rec]; write_jsonl(outp,sorted(outputs,key=lambda x:x.get('case_id',''))); calls+=1
        print(f"[{calls}/{len(rows)}] {cid} -> {rec.get('decision') or rec.get('status')}",flush=True)
    rep={'status':'PASS' if outputs and all(x.get('decision') in DECISIONS for x in outputs) and len(outputs)==len(rows) else 'PARTIAL','cases_expected':len(rows),'cases_completed':sum(x.get('decision') in DECISIONS for x in outputs),'provider':a.provider,'model':a.model,'output':str(outp)}
    write_json(outp.with_suffix('.summary.json'),rep); print(json.dumps(rep,indent=2)); return 0 if rep['status']=='PASS' else 2

def join_ablation(a):
    methods={x['case_id']:x for x in read_jsonl(a.methods)}; oracle={x['case_id']:x for x in read_jsonl(a.oracle)}; agents={x['case_id']:x for x in read_jsonl(a.agent)}
    ids=sorted(set(methods)|set(oracle)); missing=[]; out=[]
    for cid in ids:
        m=methods.get(cid) or {}; o=oracle.get(cid) or {}; ag=agents.get(cid) or {}; d=norm_dec(ag.get('decision'))
        if not d: missing.append({'case_id':cid,'field':'agent_raw_decision'})
        ideal=norm_dec(o.get('ideal_decision')); vuln=o.get('vulnerable')
        if not ideal or not isinstance(vuln,bool): missing.append({'case_id':cid,'field':'oracle'})
        if o.get('oracle_independent_of_validator') is not True: missing.append({'case_id':cid,'field':'oracle_independence'})
        for k in ['validator_only_decision','proof_gate_only_decision','confidence_threshold_decision','rfc_full_decision']:
            if norm_dec(m.get(k)) is None: missing.append({'case_id':cid,'field':k})
        out.append({'case_id':cid,'environment_fingerprint':m.get('environment_fingerprint') or o.get('environment_fingerprint'),'category':m.get('category') or o.get('category'),'scenario_kind':m.get('scenario_kind') or o.get('scenario_kind'),'source_ecosystem':m.get('source_ecosystem') or o.get('source_ecosystem'),'cohort':m.get('cohort') or o.get('cohort'),'vulnerable':vuln if isinstance(vuln,bool) else None,'ideal_decision':ideal,'agent_raw_decision':d,'validator_only_decision':norm_dec(m.get('validator_only_decision')),'proof_gate_only_decision':norm_dec(m.get('proof_gate_only_decision')),'confidence_threshold_decision':norm_dec(m.get('confidence_threshold_decision')),'rfc_full_decision':norm_dec(m.get('rfc_full_decision')),'formal_n_contribution':0})
    write_jsonl(a.output,out); rep={'status':'PASS' if out and not missing else 'FAIL_CLOSED','rows':len(out),'missing_count':len(missing),'missing':missing[:100]}; write_json(Path(a.output).with_suffix('.summary.json'),rep); print(json.dumps(rep,indent=2)); return 0 if rep['status']=='PASS' else 2

def _metrics(rows,field):
    n=len(rows); confirms=sum(r[field]=='confirm' for r in rows); false=sum(r[field]=='confirm' and r.get('vulnerable') is False for r in rows); abst=n-confirms
    ideal_conf=sum(r.get('ideal_decision')=='confirm' for r in rows); recall=sum(r.get('ideal_decision')=='confirm' and r[field]=='confirm' for r in rows)
    correct=sum(r[field]==r.get('ideal_decision') for r in rows)
    unsafe=sum(r[field]=='confirm' and r.get('ideal_decision')!='confirm' for r in rows)
    unsupported=sum(r[field]=='confirm' and r.get('proof_gate_only_decision')!='confirm' for r in rows)
    amb=sum(r[field]=='confirm' and r.get('scenario_kind')=='ambiguous_positive' and r.get('ideal_decision')!='confirm' for r in rows)
    return {'n':n,'confirmations':confirms,'false_confirmations':false,'false_confirmation_rate':false/confirms if confirms else None,'coverage':confirms/n if n else None,'abstention_rate':abst/n if n else None,'ideal_confirm_recall':recall/ideal_conf if ideal_conf else None,'decision_accuracy':correct/n if n else None,'unsafe_promotions':unsafe,'unsafe_promotion_rate':unsafe/confirms if confirms else None,'unsupported_confirmations':unsupported,'unsupported_confirmation_rate':unsupported/confirms if confirms else None,'ambiguous_positive_overconfirmations':amb}

def evaluate(a):
    rows=read_jsonl(a.input); fields=['agent_raw_decision','validator_only_decision','proof_gate_only_decision','confidence_threshold_decision','rfc_full_decision']
    missing=[]
    for r in rows:
        for f in fields:
            if norm_dec(r.get(f)) is None: missing.append({'case_id':r.get('case_id'),'field':f})
        if norm_dec(r.get('ideal_decision')) is None or not isinstance(r.get('vulnerable'),bool): missing.append({'case_id':r.get('case_id'),'field':'oracle'})
    if missing:
        rep={'status':'FAIL_CLOSED','reason':'incomplete_ablation_rows','missing':missing[:100],'missing_count':len(missing)}; write_json(a.output,rep); print(json.dumps(rep,indent=2)); return 2
    overall={f.replace('_decision',''):_metrics(rows,f) for f in fields}
    by_category={}
    for cat in sorted(set(str(r.get('category')) for r in rows)):
        rr=[r for r in rows if str(r.get('category'))==cat]; by_category[cat]={f.replace('_decision',''):_metrics(rr,f) for f in fields}
    by_scenario={}
    for sc in sorted(set(str(r.get('scenario_kind')) for r in rows)):
        rr=[r for r in rows if str(r.get('scenario_kind'))==sc]; by_scenario[sc]={f.replace('_decision',''):_metrics(rr,f) for f in fields}
    by_cohort={}
    for co in sorted(set(str(r.get('cohort')) for r in rows)):
        rr=[r for r in rows if str(r.get('cohort'))==co]; by_cohort[co]={f.replace('_decision',''):_metrics(rr,f) for f in fields}
    rep={'status':'PASS','rows':len(rows),'formal_n_contribution':0,'overall':overall,'by_category':by_category,'by_scenario':by_scenario,'by_cohort':by_cohort,'generated_at':now()}; write_json(a.output,rep)
    # Manuscript-friendly CSV exports.
    op=Path(a.output)
    cols=['method','n','confirmations','false_confirmations','false_confirmation_rate','coverage','abstention_rate','ideal_confirm_recall','decision_accuracy','unsafe_promotions','unsafe_promotion_rate','unsupported_confirmations','unsupported_confirmation_rate','ambiguous_positive_overconfirmations']
    with op.with_suffix('.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader();
        for method,v in overall.items(): w.writerow({'method':method,**v})
    for name,grouped in [('by_category',by_category),('by_scenario',by_scenario),('by_cohort',by_cohort)]:
        path=op.with_name(op.stem+'_'+name+'.csv')
        with path.open('w',newline='') as f:
            gcols=['group','method']+cols[1:]; w=csv.DictWriter(f,fieldnames=gcols); w.writeheader()
            for g,mm in grouped.items():
                for method,v in mm.items(): w.writerow({'group':g,'method':method,**v})
    print(json.dumps({'status':'PASS','rows':len(rows),'overall':overall},indent=2)); return 0

def _cp_upper(k,n,alpha=.05):
    if n<=0:return None
    if k==0:return 1-alpha**(1/n)
    try:
        from scipy.stats import beta
        return float(beta.ppf(1-alpha,k+1,n-k))
    except Exception:
        return None

def formal_progress(a):
    reg=registry_entries(a.registry); oracle_idx={}; run_idx={}
    for rd in _run_dirs(a.runs_root):
        ors=read_jsonl(rd/'oracle.jsonl'); led=read_json(rd/'acquisition_ledger.json',{'rows':[]}); lm={str(x.get('group_id')):x for x in led.get('rows',[])}
        for o in ors:
            fp=o.get('environment_fingerprint'); gid=str(o.get('group_id'))
            if fp:
                oracle_idx.setdefault(fp,o)
                run_idx[(rd.name,fp)]={'oracle':o,'ledger':lm.get(gid) or {}}
    cert=[]; confirms=[]; false=[]; missing=[]; details=[]
    for fp,e in reg.items():
        accepted_run=(e or {}).get('first_accepted_run_id'); pair=run_idx.get((accepted_run,fp)) if accepted_run else None
        o=(pair or {}).get('oracle') or oracle_idx.get(fp); l=(pair or {}).get('ledger') or {}
        if not o: missing.append(fp); continue
        method='confirm' if str(l.get('validator_status') or '').lower()=='confirmed' else 'abstain'
        if o.get('split_role')=='certify':
            cert.append(fp)
            if method=='confirm':
                confirms.append(fp)
                if o.get('vulnerable') is False:false.append(fp)
        details.append({'environment_fingerprint':fp,'first_accepted_run_id':accepted_run,'split_role':o.get('split_role'),'vulnerable':o.get('vulnerable'),'ideal_decision':o.get('ideal_decision'),'reviewed_method_decision':method})
    n=len(confirms); k=len(false); upper=_cp_upper(k,n,.05)
    rep={'status':'PASS' if not missing else 'PARTIAL','accepted_unique_environments':len(reg),'certify_environments':len(cert),'certification_confirmations':n,'false_confirmations_observed':k,'one_sided_cp_upper_at_95pct':upper,'formal_certificate_ready_at_q_0_10':bool(upper is not None and upper<=.10),'missing_oracle_count':len(missing),'registry_sha256':sha_file(a.registry),'details':details,'generated_at':now()}
    if k==0: rep['one_sided_cp_upper_zero_false_at_95pct']=upper
    if k>0 and upper is None: rep['warning']='nonzero-failure Clopper-Pearson requires scipy; certificate readiness forced false'
    write_json(a.output,rep); print(json.dumps({k:v for k,v in rep.items() if k!='details'},indent=2)); return 0 if not missing else 2

def final_summary(a):
    cp=read_json(a.casepack_summary); ev=read_json(a.evaluation); fp=read_json(a.formal_progress); jo=read_json(a.juice_oracle) if a.juice_oracle and Path(a.juice_oracle).exists() else {}
    rep={'status':'PASS' if cp.get('status')=='PASS' and ev.get('status')=='PASS' and fp.get('status') in {'PASS','PARTIAL'} else 'PARTIAL','phase':'FINAL_EVALUATION_ABLATION','casepack_cases':cp.get('cases'),'evaluation_status':ev.get('status'),'formal_progress':fp,'juice_shop_oracle_status':jo.get('status'),'juice_shop_formal_registry_admission':jo.get('formal_registry_admission'),'automatic_registry_mutation':False,'ablation_formal_n_contribution':0,'corpus_expansion_closed':True,'next_action':'Freeze this evaluation and write manuscript; any Juice Shop registry admission remains an explicit scientific-review decision.'}
    write_json(a.output,rep); print(json.dumps(rep,indent=2)); return 0 if rep['status']=='PASS' else 2

def _write_manifest(root,name,exclude=None):
    root=Path(root); exclude=set(exclude or [])|{name}; rows=[]
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.name not in exclude: rows.append((sha_file(p),str(p.relative_to(root))))
    (root/name).write_text(''.join(f'{h}  {n}\n' for h,n in rows)); return rows

def manifest_cmd(a):
    rows=_write_manifest(a.root,a.name,exclude=set(a.exclude or [])); rep={'status':'PASS','files_hashed':len(rows),'manifest':str(Path(a.root)/a.name)}; print(json.dumps(rep,indent=2)); return 0

def main():
    ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest='cmd',required=True)
    p=sp.add_parser('freeze-juice-oracle'); p.add_argument('--correction-run',required=True); p.add_argument('--output',required=True); p.set_defaults(fn=freeze_juice_oracle)
    p=sp.add_parser('build-casepack'); p.add_argument('--runs-root',default=str(EXT/'runs')); p.add_argument('--registry',default=str(EXT/'scientifically_accepted_environment_registry.json')); p.add_argument('--rules',default=str(DEFAULT_RULES)); p.add_argument('--phase2-correction-run'); p.add_argument('--juice-oracle'); p.add_argument('--output-dir',required=True); p.add_argument('--include-unregistered-evidentiary',action='store_true'); p.add_argument('--allow-missing-registry',action='store_true'); p.add_argument('--include-internal-stress',action='store_true'); p.add_argument('--internal-captures',default=str(EXP/'work/live/captures_blinded.jsonl')); p.add_argument('--internal-oracle',default=str(EXP/'work/live/oracle_live.jsonl')); p.add_argument('--allow-missing-internal-stress',action='store_true'); p.set_defaults(fn=build_casepack)
    p=sp.add_parser('run-agent'); p.add_argument('--inputs',required=True); p.add_argument('--output',required=True); p.add_argument('--provider',choices=['openai','anthropic'],required=True); p.add_argument('--model',required=True); p.add_argument('--label'); p.add_argument('--max-cases',type=int,default=0); p.add_argument('--max-output-tokens',type=int,default=1000); p.add_argument('--resume',action='store_true'); p.set_defaults(fn=run_agent)
    p=sp.add_parser('join-ablation'); p.add_argument('--methods',required=True); p.add_argument('--oracle',required=True); p.add_argument('--agent',required=True); p.add_argument('--output',required=True); p.set_defaults(fn=join_ablation)
    p=sp.add_parser('evaluate'); p.add_argument('--input',required=True); p.add_argument('--output',required=True); p.set_defaults(fn=evaluate)
    p=sp.add_parser('formal-progress'); p.add_argument('--registry',default=str(EXT/'scientifically_accepted_environment_registry.json')); p.add_argument('--runs-root',default=str(EXT/'runs')); p.add_argument('--output',required=True); p.set_defaults(fn=formal_progress)
    p=sp.add_parser('final-summary'); p.add_argument('--casepack-summary',required=True); p.add_argument('--evaluation',required=True); p.add_argument('--formal-progress',required=True); p.add_argument('--juice-oracle'); p.add_argument('--output',required=True); p.set_defaults(fn=final_summary)
    p=sp.add_parser('manifest'); p.add_argument('--root',required=True); p.add_argument('--name',default='FINAL_MANIFEST.sha256'); p.add_argument('--exclude',action='append'); p.set_defaults(fn=manifest_cmd)
    a=ap.parse_args(); return a.fn(a)
if __name__=='__main__': raise SystemExit(main())
