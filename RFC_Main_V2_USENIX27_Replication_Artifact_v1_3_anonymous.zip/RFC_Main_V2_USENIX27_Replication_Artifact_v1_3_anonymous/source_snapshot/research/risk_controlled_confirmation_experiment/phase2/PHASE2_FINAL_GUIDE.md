# RFC/Main-V2 V5.4 — Phase 2 Final Execution Runner

This overlay is additive on top of audited V5.3. It does not modify Phase-1 data, V5.2/V5.3 logic, or the scientific registry.

## What one execution does

1. Verifies the immutable Phase-1 freeze (`11` accepted environments, frozen certification-confirmation `N=7`).
2. Verifies all seven bootstrapped repositories are still on the exact recorded Git SHAs.
3. Resolves/pins Docker runtime identities and records image IDs/RepoDigests.
4. Attempts curated loopback-only, non-destructive P2-A proof adapters.
5. Classifies remaining ecosystems as explicit adapter gaps rather than inventing evidence, and records read-only source-discovery snippets for a single later scientific decision.
6. Parses OWASP Benchmark Java expected-results into a stratified **stress-only** corpus (`formal N += 0`) and writes separate blinded-input and oracle files.
7. Materializes the five-way ablation input only when explicit agent/oracle outputs are supplied. It never infers `agent_raw` or oracle truth from RFC/validator output.
8. Writes an `oracle_review_template.jsonl` whose truth fields are intentionally blank; oracle truth is never derived from the validator/capture.
9. Produces a manifest-bound final summary. Scientific registry admission remains manual.

## Safety / scientific guardrails

- All live HTTP services are bound to `127.0.0.1` only.
- No command-execution, file-write, delete/update, persistence, or browser-only XSS proof is used.
- P2-A formal count is capped at one per ecosystem and only after scientific review.
- P2-B Benchmark Java contributes zero formal N.
- Runtime or adapter failures are reported as blockers; they are not converted into abstention samples.

## First: dry plan

```bash
research/risk_controlled_confirmation_experiment/phase2/run_phase2_final.sh --plan-only
```

This checks freeze/source integrity, inventories runtime resolution, and builds the Benchmark Java stress sample without starting vulnerable applications.

## Final execution

```bash
research/risk_controlled_confirmation_experiment/phase2/run_phase2_final.sh --execute
```

The runner currently has conservative executable adapters for:

- OWASP Juice Shop: authentication-only SQLi differential on the login endpoint.
- OWASP WebGoat: read-only `SqlInjectionLesson5a` differential; if deterministic registration/login cannot be established, it fails closed.

crAPI, NodeGoat, PyGoat, and VulnerableApp are deliberately left as **adapter-gap classifications** in this release instead of guessing mutable/destructive workflows. The final run records these gaps in one pass so they can be treated as external-validity limitations or later expanded as a single source-grounded batch.

## Five-way ablation

The deterministic RFC-side decisions are derived from actual capture evidence, but `agent_raw` and oracle labels must come from an explicit file. Set:

```bash
export RFC_PHASE2_AGENT_OUTPUTS=/path/to/phase2_agent_oracle_outputs.jsonl
```

Each row must contain:

```json
{"source_id":"P2-OWASP-JUICE-SHOP","agent_raw_decision":"confirm","oracle":{"vulnerable":true,"ideal_decision":"confirm"}}
```

Then rerun `--execute`. If this file is absent or incomplete, ablation is `FAIL_CLOSED`; no result is fabricated.
