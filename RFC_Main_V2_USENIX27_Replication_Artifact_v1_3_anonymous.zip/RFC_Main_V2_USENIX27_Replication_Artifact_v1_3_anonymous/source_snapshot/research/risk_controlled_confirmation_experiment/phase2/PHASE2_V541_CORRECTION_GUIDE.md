# RFC/Main-V2 Phase 2 V5.4.1 Correction Guide

Purpose: one immutable correction round after V5.4. It does **not** edit Phase-1 runs, the scientific registry, or the V5.4 run.

## Corrections

1. **BenchmarkJava expected-results parser**
   - canonicalizes CSV headers by trimming whitespace, removing a leading `#`, and normalizing punctuation/case;
   - parses vulnerability truth to Boolean;
   - fails closed if any case ID/category/truth is missing or unknown;
   - keeps blinded rows separate from oracle rows;
   - formal N contribution remains zero.

2. **Juice Shop source/runtime alignment**
   - builds the runtime directly from the frozen Git checkout;
   - refuses dirty Git worktrees;
   - records Dockerfile SHA-256, image ID, and `org.opencontainers.image.revision`;
   - formal candidacy is possible only after source-built alignment succeeds.

3. **PyGoat conservative live adapter**
   - activates only if frozen `introduction/urls.py` maps `/sql_lab` to `views.sql_lab`;
   - requires the `sql_lab` function to contain a SELECT and no SQL mutation keywords;
   - uses same-endpoint control/candidate POSTs and requires a conservative table-row differential;
   - otherwise ABSTAINS / review-required; no formal N is added automatically.

4. **OWASP VulnerableApp source-grounded expansion**
   - checks the frozen `ErrorBasedSQLInjectionVulnerability.java` for the declared error-based SQLi attack vector, Level 1 mapping, `id` request parameter, and concatenated SELECT;
   - this is stress/source-ground-truth evidence only (`formal_n_cap=0`);
   - no live endpoint is guessed.

5. **5-way ablation input separation**
   - actual agent output and independent oracle are separate explicit files;
   - the correction runner never derives either from validator/proof/RFC output;
   - oracle independence must be explicitly true or evaluation fails closed.

## Run

```bash
research/risk_controlled_confirmation_experiment/phase2/run_phase2_correction_v541.sh --plan-only
```

Then:

```bash
research/risk_controlled_confirmation_experiment/phase2/run_phase2_correction_v541.sh --execute
```

The source-build stage can take time on the first run. V5.4.1 prints progress labels for every stage.

Optional provenance link to the frozen V5.4 run:

```bash
export RFC_PHASE2_PRIOR_V54_RUN="$PWD/research/risk_controlled_confirmation_experiment/external/phase2_final_runs/20260811T041021Z-p2final-21912"
```

## Ablation inputs

Do not fill these by looking at RFC decisions.

Actual agent outputs:

```json
{"source_id":"P2-OWASP-JUICE-SHOP","agent_raw_decision":"confirm"}
```

Independent oracle file:

```json
{"source_id":"P2-OWASP-JUICE-SHOP","vulnerable":true,"ideal_decision":"confirm","oracle_source":"<independent source>","oracle_independent_of_validator":true,"independence_eligible":true}
```

Supply both before `--execute` only if they were produced independently:

```bash
export RFC_PHASE2_AGENT_OUTPUTS=/path/to/agent_outputs.jsonl
export RFC_PHASE2_ORACLE_OUTPUTS=/path/to/oracle_outputs.jsonl
```

If either is absent, the ablation stage intentionally returns `FAIL_CLOSED` while preserving all other correction artifacts.

## Scientific policy

- no automatic registry mutation;
- no automatic scientific acceptance;
- no Phase-1 reruns for new N;
- no repetitions or same-runtime BenchmarkJava cases count toward formal N;
- previous V5.4 data remains immutable.
