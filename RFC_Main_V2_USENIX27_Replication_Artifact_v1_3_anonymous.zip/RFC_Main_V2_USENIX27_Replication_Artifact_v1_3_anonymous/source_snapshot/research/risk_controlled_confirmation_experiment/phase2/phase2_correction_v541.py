#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, html, importlib.util, json, os, re, subprocess, time, urllib.parse
from collections import Counter, defaultdict
from pathlib import Path
from html.parser import HTMLParser
import requests

HERE=Path(__file__).resolve().parent
EXP=HERE.parent
EXT=EXP/'external'
DEFAULT_PREP=EXT/'phase2'
DEFAULT_WORKSPACE=EXT/'phase2_sources'
DEFAULT_CATALOG=HERE/'config/phase2_v541_catalog.json'
DECISIONS={'confirm','abstain','reject'}

# Reuse only stable primitives from audited V5.4.  This overlay does not modify V5.4 files.
_spec=importlib.util.spec_from_file_location('v54',HERE/'phase2_final_runner.py')
v54=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(v54)

def now(): return v54.now()
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return v54.sha_file(p)
def read_json(p,default=None): return v54.read_json(p,default)
def read_jsonl(p): return v54.read_jsonl(p)
def write_json(p,o): return v54.write_json(p,o)
def write_jsonl(p,rows): return v54.write_jsonl(p,rows)
def run(cmd,cwd=None,timeout=300,check=False): return v54.run(cmd,cwd=cwd,timeout=timeout,check=check)
def git_head(p): return v54.git_head(p)
def docker_ok(): return v54.docker_ok()
def safe_id(s): return v54.safe_id(s)
def choose_free_port(start=9500,end=9799):
    return v54.choose_free_port(start,end)

def git_clean(root):
    q=run(['git','-C',str(root),'status','--porcelain','--untracked-files=no'],timeout=30)
    return q.returncode==0 and not q.stdout.strip(), q.stdout.strip()

def _source_maps(prep): return v54._source_maps(prep)

def canon_header(k):
    s=str(k or '').replace('\ufeff','').strip().lower()
    s=re.sub(r'^#+\s*','',s)
    s=re.sub(r'[^a-z0-9]+',' ',s).strip()
    return s

def canon_bool(v):
    s=str(v or '').strip().lower()
    if s in {'true','1','yes','y'}: return True
    if s in {'false','0','no','n'}: return False
    return None

def normalized_row(r):
    return {canon_header(k):v for k,v in (r or {}).items()}

def field(r,*names):
    low=normalized_row(r)
    for n in names:
        k=canon_header(n)
        if k in low: return low[k]
    return None

def parse_benchmark_expected(path):
    path=Path(path); raw=[]
    with path.open(newline='',encoding='utf-8-sig') as f:
        rd=csv.DictReader(f)
        for line_no,r in enumerate(rd,2): raw.append((line_no,r))
    parsed=[]; issues=[]
    for line_no,r in raw:
        case_id=(field(r,'test name','testname','test number','testnumber') or '').strip()
        category=(field(r,'category','cwe','test category') or '').strip().lower()
        expected=canon_bool(field(r,'real vulnerability','realvulnerability','true vulnerability','vulnerable','expected'))
        if not case_id: issues.append({'line':line_no,'field':'case_id','raw_keys':list(r)})
        if not category or category=='unknown': issues.append({'line':line_no,'field':'category','case_id':case_id})
        if expected is None: issues.append({'line':line_no,'field':'expected','case_id':case_id,'value':field(r,'real vulnerability','realvulnerability','true vulnerability','vulnerable','expected')})
        parsed.append({'case_id':case_id or f'INVALID-{line_no}','category':category or 'unknown','expected':expected,'raw':r,'source_line':line_no})
    return parsed,issues

def stratified_sample(rows,cap):
    cats=defaultdict(list)
    for r in rows: cats[r['category']].append(r)
    sample=[]; keys=sorted(cats); i=0; cap=max(1,int(cap))
    while len(sample)<cap and keys:
        progressed=False
        for k in keys:
            if i<len(cats[k]):
                sample.append(cats[k][i]); progressed=True
                if len(sample)>=cap: break
        if not progressed: break
        i+=1
    return sample

def cmd_stress(a):
    plan=read_json(Path(a.prep)/'source_plan.json'); st=plan.get('stress_corpus') or {}
    root=Path(st.get('workspace_path') or (Path(a.workspace)/'P2-OWASP-BENCHMARK-JAVA'))
    files=sorted(root.glob('expectedresults-*.csv'))
    if not files:
        write_json(a.output,{'status':'FAIL_CLOSED','reason':'expectedresults csv not found','formal_n_contribution':0}); return 2
    p=files[-1]; rows,issues=parse_benchmark_expected(p)
    if issues:
        out={'status':'FAIL_CLOSED','reason':'benchmark_expectedresults_schema_or_truth_invalid','expected_results_file':str(p),'expected_results_sha256':sha_file(p),'total_cases':len(rows),'issue_count':len(issues),'issues':issues[:100],'formal_n_contribution':0}
        write_json(a.output,out); print(json.dumps({k:v for k,v in out.items() if k!='issues'},indent=2)); return 2
    sample=stratified_sample(rows,a.max_cases)
    if not sample or any(x['category']=='unknown' or x['expected'] is None or not x['case_id'] for x in sample):
        out={'status':'FAIL_CLOSED','reason':'sample_contains_unknown_or_null_truth','sampled_cases':len(sample),'formal_n_contribution':0}
        write_json(a.output,out); return 2
    out={'status':'PASS','source_id':'P2-OWASP-BENCHMARK-JAVA','expected_results_file':str(p),'expected_results_sha256':sha_file(p),'total_cases':len(rows),'sampled_cases':len(sample),'categories':dict(sorted(Counter(x['category'] for x in sample).items())),'truth_counts':{'true':sum(x['expected'] is True for x in sample),'false':sum(x['expected'] is False for x in sample)},'formal_n_contribution':0,'schema_normalization':'strip whitespace, strip leading #, canonicalize punctuation/case; truth parsed to boolean','note':'stress-only corpus; same-runtime cases do not contribute to formal certification N','sample':sample}
    write_json(a.output,out)
    if a.blinded_output:
        write_jsonl(a.blinded_output,[{'case_id':x['case_id'],'category':x['category'],'source_id':'P2-OWASP-BENCHMARK-JAVA','formal_n_contribution':0} for x in sample])
    if a.oracle_output:
        write_jsonl(a.oracle_output,[{'case_id':x['case_id'],'category':x['category'],'expected':x['expected'],'oracle_source_file_sha256':sha_file(p),'oracle_source_line':x['source_line'],'formal_n_contribution':0} for x in sample])
    print(json.dumps({k:v for k,v in out.items() if k!='sample'},indent=2)); return 0

def image_metadata(image): return v54.image_metadata(image)

def build_source_image(src,root,timeout=1800):
    root=Path(root); head=git_head(root); clean,dirty=git_clean(root)
    if not head or not clean:
        return {'status':'FAIL_CLOSED_SOURCE_DIRTY','git_head':head,'dirty':dirty}
    dockerfile=root/(src.get('dockerfile') or 'Dockerfile')
    context=root/(src.get('build_context') or '.')
    if not dockerfile.is_file() or not context.exists():
        return {'status':'FAIL_CLOSED_BUILD_RECIPE_MISSING','git_head':head,'dockerfile':str(dockerfile),'context':str(context)}
    tag=f"rfc-phase2/{safe_id(src['source_id']).lower()}:{head[:12]}"
    cmd=['docker','build','--label',f'org.opencontainers.image.revision={head}','--label',f'rfc.phase2.source_id={src["source_id"]}','-f',str(dockerfile),'-t',tag,str(context)]
    q=run(cmd,cwd=root,timeout=timeout)
    if q.returncode:
        return {'status':'FAIL_CLOSED_BUILD_FAILED','git_head':head,'returncode':q.returncode,'stderr_tail':q.stderr[-4000:],'stdout_tail':q.stdout[-2000:]}
    meta=image_metadata(tag); labels=meta.get('labels') or {}
    aligned=meta.get('status')=='PRESENT' and labels.get('org.opencontainers.image.revision')==head
    return {'status':'PASS' if aligned else 'FAIL_CLOSED_BUILD_LABEL_MISMATCH','git_head':head,'image':meta,'tag':tag,'dockerfile':str(dockerfile.relative_to(root)),'dockerfile_sha256':sha_file(dockerfile),'source_clean':True,'runtime_alignment':'built_from_frozen_git_source','build_returncode':q.returncode}

def runtime_freeze(a):
    if not docker_ok():
        write_json(a.output,{'status':'FAIL_CLOSED','reason':'docker_daemon_unavailable'}); return 2
    catalog=read_json(a.catalog); plan,pmap,_=_source_maps(a.prep); rows=[]; issues=[]
    for src in catalog.get('sources',[]):
        sid=src['source_id']; sp=pmap.get(sid) or {}; root=Path(sp.get('workspace_path') or (Path(a.workspace)/sid)); head=git_head(root)
        row={'source_id':sid,'git_head':head,'expected_git_head':sp.get('git_head'),'workspace_path':str(root),'formal_n_cap':src.get('formal_n_cap',0),'resolved_at':now(),'runtime':src.get('runtime')}
        if head!=sp.get('git_head'):
            row['status']='FAIL_CLOSED_GIT_DRIFT'; issues.append(f'{sid}: git drift'); rows.append(row); continue
        if src.get('runtime')=='source_build':
            if a.resolve:
                print(f'[runtime] {sid}: building image from frozen source {head[:12]} ...',flush=True)
                b=build_source_image(src,root,a.build_timeout)
                print(f'[runtime] {sid}: {b.get("status")}',flush=True)
            else:
                b={'status':'PLAN_SOURCE_BUILD','git_head':head,'dockerfile':src.get('dockerfile','Dockerfile'),'runtime_alignment':'will_build_from_frozen_git_source'}
            row['source_build']=b; row['image']=b.get('image'); row['status']='PASS' if (b.get('status')=='PASS' or not a.resolve) else b.get('status')
        elif src.get('runtime')=='source_tree':
            clean,dirty=git_clean(root); row['source_clean']=clean; row['dirty']=dirty; row['status']='PASS' if clean else 'FAIL_CLOSED_SOURCE_DIRTY'; row['runtime_alignment']='frozen_source_tree_only'
        else:
            row['status']='FAIL_CLOSED_UNSUPPORTED_RUNTIME'; issues.append(f'{sid}: unsupported correction runtime')
        seed={'source_id':sid,'git_head':head,'runtime':row.get('runtime'),'image_id':(row.get('image') or {}).get('image_id'),'dockerfile_sha256':(row.get('source_build') or {}).get('dockerfile_sha256')}
        row['environment_fingerprint']=sha_bytes(json.dumps(seed,sort_keys=True).encode()); rows.append(row)
    out={'status':'PASS' if rows and not any(str(x.get('status','')).startswith('FAIL_CLOSED') for x in rows) else 'PARTIAL_FAIL_CLOSED','rows':rows,'issues':issues,'automatic_registry_mutation':False}
    write_json(a.output,out); print(json.dumps({'status':out['status'],'rows':len(rows),'issues':issues},indent=2)); return 0 if out['status']=='PASS' else 2

class FormParser(HTMLParser):
    def __init__(self): super().__init__(); self.inputs=[]; self.forms=[]; self._form=None
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if tag.lower()=='form': self._form={'action':d.get('action'),'method':(d.get('method') or 'get').lower(),'inputs':[]}; self.forms.append(self._form)
        elif tag.lower() in {'input','textarea','select'} and self._form is not None:
            item={'name':d.get('name'),'value':d.get('value') or '','type':d.get('type') or tag.lower()}; self._form['inputs'].append(item); self.inputs.append(item)
    def handle_endtag(self,tag):
        if tag.lower()=='form': self._form=None

def _function_block(text,name):
    m=re.search(rf'^def\s+{re.escape(name)}\s*\([^\n]*\):\s*$',text,re.M)
    if not m:return None
    start=m.start(); n=re.search(r'^def\s+\w+\s*\(',text[m.end():],re.M); end=m.end()+n.start() if n else len(text)
    return text[start:end]

def pygoat_recipe(root):
    root=Path(root); urls=root/'introduction/urls.py'; views=root/'introduction/views.py'
    if not urls.is_file() or not views.is_file(): return {'status':'FAIL_CLOSED_SOURCE_FILES_MISSING'}
    ut=urls.read_text(errors='replace'); vt=views.read_text(errors='replace'); block=_function_block(vt,'sql_lab')
    if not block or not re.search(r'path\(["\']sql_lab["\']\s*,\s*views\.sql_lab',ut): return {'status':'FAIL_CLOSED_ROUTE_NOT_GROUNDED'}
    if not re.search(r'\bselect\b',block,re.I): return {'status':'FAIL_CLOSED_NO_READ_ONLY_SELECT'}
    # A live adapter is allowed only when the relevant function is SELECT-only.
    if re.search(r'\b(insert|update|delete|drop|alter|create|truncate)\b',block,re.I): return {'status':'FAIL_CLOSED_MUTATING_SQL_PRESENT'}
    names=[]
    for pat in [r'request\.POST\.get\(["\']([^"\']+)',r'request\.POST\[["\']([^"\']+)["\']\]']:
        names += re.findall(pat,block)
    names=[x for x in dict.fromkeys(names) if x.lower() not in {'csrfmiddlewaretoken'}]
    if not names:return {'status':'FAIL_CLOSED_POST_FIELD_NOT_GROUNDED'}
    return {'status':'PASS','path':'/sql_lab','post_fields':names,'urls_sha256':sha_file(urls),'views_sha256':sha_file(views),'function_sha256':sha_bytes(block.encode()),'source_read_only_select':True}

def _table_rows(text): return len(re.findall(r'<tr\b',text or '',re.I))
def _obs(r,role,meta): return v54.obs(r,role,meta)

def pygoat_driver(base,root):
    recipe=pygoat_recipe(root)
    if recipe.get('status')!='PASS': return {'driver':'pygoat_sql_lab_source_grounded','category':'sqli','proof_valid':False,'validator_status':'needs_manual_review','validator_confidence':0.0,'limitations':[recipe.get('status')],'source_recipe':recipe,'observations':[],'proof_obligations':{}}
    s=requests.Session(); url=base+recipe['path']; g=s.get(url,timeout=15,allow_redirects=True)
    if g.status_code!=200: return {'driver':'pygoat_sql_lab_source_grounded','category':'sqli','proof_valid':False,'validator_status':'needs_manual_review','validator_confidence':0.0,'limitations':['sql_lab GET not ready'],'source_recipe':recipe,'fixture':{'status':g.status_code,'url':g.url},'observations':[],'proof_obligations':{}}
    hp=FormParser(); hp.feed(g.text); forms=[f for f in hp.forms if f.get('method')=='post'] or hp.forms
    if not forms:return {'driver':'pygoat_sql_lab_source_grounded','category':'sqli','proof_valid':False,'validator_status':'needs_manual_review','validator_confidence':0.0,'limitations':['POST form not discovered'],'source_recipe':recipe,'observations':[],'proof_obligations':{}}
    form=forms[0]; discovered={x.get('name'):x.get('value','') for x in form.get('inputs',[]) if x.get('name')}; target=next((x for x in recipe['post_fields'] if x in discovered),recipe['post_fields'][0])
    base_data={k:(v or '1') for k,v in discovered.items() if k}
    if 'csrfmiddlewaretoken' in discovered: base_data['csrfmiddlewaretoken']=discovered['csrfmiddlewaretoken']
    control=dict(base_data); control[target]='-999999'
    c=s.post(url,data=control,timeout=15,allow_redirects=False)
    candidates=["' OR '1'='1' -- ","1 OR 1=1"]
    attempts=[]; best=None
    for payload in candidates:
        data=dict(base_data); data[target]=payload; d=s.post(url,data=data,timeout=15,allow_redirects=False)
        att={'payload_sha256':sha_bytes(payload.encode()),'status_code':d.status_code,'body_sha256':sha_bytes(d.content),'body_length':len(d.content),'table_rows':_table_rows(d.text)}; attempts.append(att)
        if d.status_code==200 and c.status_code==200 and _table_rows(d.text)>=max(2,_table_rows(c.text)+1): best=(payload,d); break
    co=_obs(c,'control',{'method':'POST','path':recipe['path'],'form_field':target,'value_sha256':sha_bytes(control[target].encode())})
    observations=[co]; success=best is not None
    if best:
        payload,d=best; observations.append(_obs(d,'candidate',{'method':'POST','path':recipe['path'],'form_field':target,'value_sha256':sha_bytes(payload.encode()),'safe_proof':'SELECT-only SQLi differential grounded in frozen source'}))
    return {'driver':'pygoat_sql_lab_source_grounded','category':'sqli','observations':observations,'proof_valid':success,'validator_status':'confirmed' if success else 'needs_manual_review','validator_confidence':0.90 if success else 0.35,'proof_obligations':{'control_request_compared':['E1','E2'],'differential_table_rows':['E1','E2'],'source_read_only_select':['SOURCE']} if success else {},'limitations':[] if success else ['candidate did not produce conservative multi-row differential'],'source_recipe':recipe,'attempts':attempts,'control_table_rows':_table_rows(c.text)}

def vulnerableapp_source_evidence(root):
    root=Path(root); p=root/'src/main/java/org/sasanlabs/service/vulnerability/sqlInjection/ErrorBasedSQLInjectionVulnerability.java'
    if not p.is_file(): return {'status':'FAIL_CLOSED_SOURCE_FILE_MISSING'}
    text=p.read_text(errors='replace')
    checks={
      'attack_vector_error_based_sqli':bool(re.search(r'VulnerabilityType\.ERROR_BASED_SQL_INJECTION',text)),
      'level1_mapping':bool(re.search(r'@VulnerableAppRequestMapping\s*\(.*?LevelConstants\.LEVEL_1',text,re.S)),
      'request_param_id':bool(re.search(r'queryParams\.get\(Constants\.ID\)',text)),
      'read_only_select_concat':bool(re.search(r'"select \* from cars where id="\s*\+\s*id',text,re.I)),
    }
    ok=all(checks.values())
    return {'status':'PASS' if ok else 'FAIL_CLOSED_SOURCE_GROUNDING_INCOMPLETE','source_path':str(p.relative_to(root)),'source_sha256':sha_file(p),'checks':checks,'formal_n_contribution':0,'note':'source-grounded stress evidence only; no live endpoint is guessed or treated as formal confirmation'}

def start_built_image(src,rr):
    meta=rr.get('image') or {}; ref=meta.get('image_id') or (rr.get('source_build') or {}).get('tag')
    if not ref: raise RuntimeError('source-built image reference missing')
    ports=src.get('container_ports') or []; hostports=[choose_free_port(9500+i*20,9519+i*20) for i,_ in enumerate(ports)]
    name='rfc-p2c-'+safe_id(src['source_id']).lower()+'-'+str(os.getpid())
    cmd=['docker','run','--rm','-d','--name',name]
    for hp,cp in zip(hostports,ports): cmd += ['-p',f'127.0.0.1:{hp}:{cp}']
    cmd += [ref]
    q=run(cmd,timeout=120)
    if q.returncode: raise RuntimeError('docker run failed: '+q.stderr[-1200:])
    return {'kind':'docker_image','name':name,'ref':ref,'hostports':hostports,'container_ports':ports,'runtime_alignment':'built_from_frozen_git_source'}

def oracle_template(row,source_evidence=None):
    return {'source_id':row.get('source_id'),'environment_fingerprint':row.get('environment_fingerprint'),'category':row.get('category'),'vulnerable':None,'ideal_decision':None,'oracle_source':None,'oracle_independent_of_validator':None,'independence_eligible':None,'independence_basis':None,'split_role':'certify','source_evidence':source_evidence,'note':'FILL BY EXPLICIT INDEPENDENT REVIEW. Source evidence is pre-capture/frozen-source provenance; truth is not inferred from validator/RFC output.'}

def execute(a):
    cat=read_json(a.catalog); rt=read_json(a.runtime); rmap={x['source_id']:x for x in rt.get('rows',[])}; outdir=Path(a.outdir); outdir.mkdir(parents=True,exist_ok=True)
    rows=[]; oracles=[]
    for src in cat.get('sources',[]):
        sid=src['source_id']; rr=rmap.get(sid) or {}; root=Path(rr.get('workspace_path') or '')
        row={'source_id':sid,'category':src.get('category'),'formal_n_cap':src.get('formal_n_cap',0),'driver':src.get('driver'),'environment_fingerprint':rr.get('environment_fingerprint'),'git_head':rr.get('git_head'),'started_at':now(),'scientific_acceptance_automatic':False}
        if rr.get('status')!='PASS': row.update(status='RUNTIME_BLOCKED',formal_candidate=False,blocker=rr.get('status')); rows.append(row); continue
        if src['driver']=='vulnerableapp_source_grounded':
            ev=vulnerableapp_source_evidence(root); row['source_evidence']=ev; row['status']='SOURCE_GROUND_TRUTH_OK' if ev.get('status')=='PASS' else 'SOURCE_GROUND_TRUTH_BLOCKED'; row['formal_candidate']=False; row['completed_at']=now(); rows.append(row); continue
        runtime=None
        try:
            runtime=start_built_image(src,rr); base='http://127.0.0.1:'+str(runtime['hostports'][0]); ready,last=v54.wait_http(base+src.get('readiness_path','/'),a.readiness_timeout); row['runtime']={**runtime,'readiness_last_status':last}
            if not ready: raise RuntimeError('application readiness failed')
            if src['driver']=='juice_shop_login_sqli':
                res=v54.juice_shop_driver(base)
                source_p=root/'routes/login.ts'; source_ev={'source_path':'routes/login.ts','source_sha256':sha_file(source_p),'vulnerable_query_pattern_present':bool(source_p.is_file() and re.search(r'sequelize\.query\(`SELECT \* FROM Users WHERE email = \'\$\{req\.body\.email',source_p.read_text(errors='replace')))}
            elif src['driver']=='pygoat_sql_lab_source_grounded':
                res=pygoat_driver(base,root); source_ev=res.get('source_recipe')
            else: raise RuntimeError('unsupported correction driver')
            row['result']=res; row['source_evidence']=source_ev; row['status']='CAPTURE_OK_EVIDENTIARY' if res.get('proof_valid') else 'CAPTURE_REVIEW_REQUIRED'; row['formal_candidate']=bool(res.get('proof_valid') and src.get('formal_n_cap',0)>0)
            row['method_outputs']={'validator_only_decision':'confirm' if res.get('validator_status')=='confirmed' else 'abstain','proof_gate_only_decision':'confirm' if res.get('proof_valid') and res.get('proof_obligations') else 'abstain','confidence_threshold_decision':'confirm' if float(res.get('validator_confidence',0))>=a.confidence_threshold else 'abstain','rfc_full_decision':'confirm' if res.get('proof_valid') and float(res.get('validator_confidence',0))>=a.confidence_threshold else 'abstain'}
            oracles.append(oracle_template(row,source_ev))
        except Exception as e: row.update(status='RUN_ERROR',formal_candidate=False,error=f'{type(e).__name__}: {e}')
        finally:
            v54.stop_runtime(runtime); row['completed_at']=now()
        write_json(outdir/(safe_id(sid)+'.json'),row); rows.append(row)
    write_jsonl(outdir/'phase2_correction_rows.jsonl',rows); write_jsonl(outdir/'oracle_review_template.jsonl',oracles)
    write_jsonl(outdir/'agent_outputs_template.jsonl',[{'source_id':x['source_id'],'agent_raw_decision':'FILL_FROM_ACTUAL_AGENT_RUN','note':'Do not infer from validator/proof/RFC output.'} for x in rows if x.get('status') in {'CAPTURE_OK_EVIDENTIARY','CAPTURE_REVIEW_REQUIRED'}])
    rep={'status':'PASS' if any(x.get('formal_candidate') for x in rows) else 'PARTIAL','sources':len(rows),'formal_candidates':sum(bool(x.get('formal_candidate')) for x in rows),'capture_ok':sum(x.get('status')=='CAPTURE_OK_EVIDENTIARY' for x in rows),'source_ground_truth_only':sum(x.get('status')=='SOURCE_GROUND_TRUTH_OK' for x in rows),'automatic_registry_mutation':False}
    write_json(outdir/'execution_summary.json',rep); print(json.dumps(rep,indent=2)); return 0

def _norm(v):
    s=str(v or '').strip().lower(); return s if s in DECISIONS else None

def ablation_materialize(a):
    rows=read_jsonl(Path(a.execution_dir)/'phase2_correction_rows.jsonl'); agents={x.get('source_id'):x for x in read_jsonl(a.agent_outputs)} if a.agent_outputs and Path(a.agent_outputs).exists() else {}; oracles={x.get('source_id'):x for x in read_jsonl(a.oracle_outputs)} if a.oracle_outputs and Path(a.oracle_outputs).exists() else {}
    out=[]; missing=[]
    for x in rows:
        if x.get('status') not in {'CAPTURE_OK_EVIDENTIARY','CAPTURE_REVIEW_REQUIRED'}: continue
        sid=x['source_id']; ag=agents.get(sid) or {}; oc=oracles.get(sid) or {}; d=_norm(ag.get('agent_raw_decision')); ideal=_norm(oc.get('ideal_decision')); vuln=oc.get('vulnerable')
        if not d: missing.append({'source_id':sid,'field':'agent_raw_decision'})
        if not ideal or not isinstance(vuln,bool): missing.append({'source_id':sid,'field':'oracle_truth'})
        if oc.get('oracle_independent_of_validator') is not True: missing.append({'source_id':sid,'field':'oracle_independence'})
        mo=x.get('method_outputs') or {}
        out.append({'case_id':sid,'environment_id':x.get('environment_fingerprint'),'source_ecosystem':sid,'vulnerable':vuln if isinstance(vuln,bool) else None,'ideal_decision':ideal,'agent_raw_decision':d,'validator_only_decision':_norm(mo.get('validator_only_decision')),'proof_gate_only_decision':_norm(mo.get('proof_gate_only_decision')),'confidence_threshold_decision':_norm(mo.get('confidence_threshold_decision')),'rfc_full_decision':_norm(mo.get('rfc_full_decision')),'oracle_source':oc.get('oracle_source')})
    write_jsonl(a.output,out); rep={'status':'PASS' if out and not missing else 'FAIL_CLOSED','rows':len(out),'missing':missing,'inputs_separated':True,'note':'agent outputs and independent oracle are supplied as separate files; neither is inferred from RFC outputs'}; write_json(Path(a.output).with_suffix('.summary.json'),rep); print(json.dumps(rep,indent=2)); return 0 if rep['status']=='PASS' else 2

def aggregate(a):
    pre=read_json(a.preflight); rt=read_json(a.runtime); ex=read_json(Path(a.execution_dir)/'execution_summary.json'); st=read_json(a.stress); abl=read_json(a.ablation) if a.ablation and Path(a.ablation).exists() else {'status':'NOT_RUN'}; rows=read_jsonl(Path(a.execution_dir)/'phase2_correction_rows.jsonl')
    rep={'status':'PASS' if pre.get('status')=='PASS' and st.get('status')=='PASS' else 'PARTIAL_FAIL_CLOSED','phase':'PHASE2_V5_4_1_CORRECTION','prior_v54_run':a.prior_run,'prior_v54_manifest_sha256':sha_file(Path(a.prior_run)/'MANIFEST.sha256') if a.prior_run else None,'phase1_frozen':pre.get('status')=='PASS','runtime_freeze_status':rt.get('status'),'correction_sources':len(rows),'formal_review_candidates':sum(bool(x.get('formal_candidate')) for x in rows),'formal_candidate_sources':[x['source_id'] for x in rows if x.get('formal_candidate')],'source_ground_truth_only_sources':[x['source_id'] for x in rows if x.get('status')=='SOURCE_GROUND_TRUTH_OK'],'benchmark_stress_status':st.get('status'),'benchmark_stress_cases':st.get('sampled_cases',0),'benchmark_truth_counts':st.get('truth_counts'),'ablation_status':abl.get('status'),'scientific_acceptance_automatic':False,'registry_mutated':False,'formal_n_increment_automatic':0,'next_action':'explicit scientific review of formal candidates; fill separate agent/oracle inputs for quantitative 5-way ablation' if abl.get('status')!='PASS' else 'explicit scientific review and freeze final Phase-2 metrics'}
    write_json(a.output,rep); print(json.dumps(rep,indent=2)); return 0 if rep['status']=='PASS' else 2

def main():
    ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest='cmd',required=True)
    p=sp.add_parser('stress'); p.add_argument('--prep',default=str(DEFAULT_PREP)); p.add_argument('--workspace',default=str(DEFAULT_WORKSPACE)); p.add_argument('--output',required=True); p.add_argument('--blinded-output'); p.add_argument('--oracle-output'); p.add_argument('--max-cases',type=int,default=240); p.set_defaults(fn=cmd_stress)
    p=sp.add_parser('runtime-freeze'); p.add_argument('--prep',default=str(DEFAULT_PREP)); p.add_argument('--workspace',default=str(DEFAULT_WORKSPACE)); p.add_argument('--catalog',default=str(DEFAULT_CATALOG)); p.add_argument('--output',required=True); p.add_argument('--resolve',action='store_true'); p.add_argument('--build-timeout',type=int,default=1800); p.set_defaults(fn=runtime_freeze)
    p=sp.add_parser('execute'); p.add_argument('--catalog',default=str(DEFAULT_CATALOG)); p.add_argument('--runtime',required=True); p.add_argument('--outdir',required=True); p.add_argument('--readiness-timeout',type=int,default=240); p.add_argument('--confidence-threshold',type=float,default=.8); p.set_defaults(fn=execute)
    p=sp.add_parser('ablation-materialize'); p.add_argument('--execution-dir',required=True); p.add_argument('--agent-outputs',required=True); p.add_argument('--oracle-outputs',required=True); p.add_argument('--output',required=True); p.set_defaults(fn=ablation_materialize)
    p=sp.add_parser('aggregate'); p.add_argument('--preflight',required=True); p.add_argument('--runtime',required=True); p.add_argument('--execution-dir',required=True); p.add_argument('--stress',required=True); p.add_argument('--ablation'); p.add_argument('--prior-run'); p.add_argument('--output',required=True); p.set_defaults(fn=aggregate)
    a=ap.parse_args(); return a.fn(a)
if __name__=='__main__': raise SystemExit(main())
