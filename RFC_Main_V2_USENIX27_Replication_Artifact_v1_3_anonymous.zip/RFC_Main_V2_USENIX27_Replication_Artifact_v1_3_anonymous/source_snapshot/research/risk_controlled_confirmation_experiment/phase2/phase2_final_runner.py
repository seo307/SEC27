#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, html, json, os, re, socket, subprocess, sys, time, urllib.parse
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import requests

HERE=Path(__file__).resolve().parent
EXP=HERE.parent
EXT=EXP/'external'
DEFAULT_OUT=EXT/'phase2_final'
DEFAULT_WORKSPACE=EXT/'phase2_sources'
DEFAULT_PREP=EXT/'phase2'

DECISIONS={'confirm','abstain','reject'}

def now(): return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
    p=Path(p); return sha_bytes(p.read_bytes()) if p.exists() else None
def read_json(p,default=None):
    p=Path(p)
    if not p.exists(): return {} if default is None else default
    return json.loads(p.read_text())
def read_jsonl(p):
    p=Path(p); out=[]
    if not p.exists(): return out
    for line in p.read_text().splitlines():
        if line.strip(): out.append(json.loads(line))
    return out
def write_json(p,o):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def write_jsonl(p,rows):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))
def run(cmd,cwd=None,timeout=300,check=False):
    p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
    if check and p.returncode: raise RuntimeError(f'command failed {cmd}: {p.stderr[-1200:]}')
    return p

def git_head(p):
    q=run(['git','-C',str(p),'rev-parse','HEAD'],timeout=30)
    return q.stdout.strip() if q.returncode==0 else None

def docker_ok(): return run(['docker','info'],timeout=30).returncode==0

def safe_id(s): return re.sub(r'[^A-Za-z0-9_.-]+','-',s)[:80]

def choose_free_port(start=9300,end=9499):
    for port in range(start,end+1):
        s=socket.socket()
        try:
            s.bind(('127.0.0.1',port)); return port
        except OSError: pass
        finally: s.close()
    raise RuntimeError('no loopback port available')

def _source_maps(prep):
    plan=read_json(Path(prep)/'source_plan.json')
    rec=read_json(Path(prep)/'bootstrap_receipts.json')
    p={x['source_id']:x for x in plan.get('sources',[])}
    st=plan.get('stress_corpus') or {}
    if st.get('source_id'): p[st['source_id']]=st
    r={x['source_id']:x for x in rec.get('receipts',[])}
    return plan,p,r

def cmd_verify(a):
    prep=Path(a.prep); freeze=read_json(prep/'PHASE1_FREEZE.json'); plan,pmap,rmap=_source_maps(prep)
    issues=[]
    if freeze.get('status')!='PASS' or freeze.get('accepted_unique_environments')!=11: issues.append('PHASE1_FREEZE must PASS with exactly 11 accepted environments')
    if freeze.get('certification_confirmations')!=7: issues.append('PHASE1_FREEZE certification confirmations must equal frozen N=7')
    if freeze.get('false_confirmations_observed')!=0: issues.append('PHASE1_FREEZE false confirmations changed')
    if plan.get('status')!='PASS': issues.append('source_plan is not PASS')
    ids=[x.get('source_id') for x in plan.get('sources',[])]; stress=(plan.get('stress_corpus') or {}).get('source_id')
    if len(ids)!=6 or not stress: issues.append('expected six P2-A sources plus one stress corpus')
    rows=[]
    for sid,x in sorted(pmap.items()):
        rr=rmap.get(sid) or {}; expected=x.get('git_head'); got=rr.get('git_head'); wp=Path(x.get('workspace_path') or rr.get('workspace_path') or '')
        local=git_head(wp) if wp.exists() else None
        ok=bool(re.fullmatch(r'[0-9a-f]{40}',str(expected or ''))) and expected==got==local
        if not ok: issues.append(f'{sid}: git head/receipt/local mismatch expected={expected} receipt={got} local={local}')
        rows.append({'source_id':sid,'expected_git_head':expected,'receipt_git_head':got,'local_git_head':local,'workspace_path':str(wp),'match':ok})
    out={'status':'PASS' if not issues else 'FAIL_CLOSED','phase1_freeze_sha256':sha_file(prep/'PHASE1_FREEZE.json'),'source_plan_sha256':sha_file(prep/'source_plan.json'),'bootstrap_receipts_sha256':sha_file(prep/'bootstrap_receipts.json'),'issues':issues,'sources':rows}
    write_json(a.output,out); print(json.dumps({'status':out['status'],'issues':issues},indent=2)); return 0 if not issues else 2

def image_metadata(image):
    q=run(['docker','image','inspect',image],timeout=60)
    if q.returncode: return {'image':image,'status':'NOT_PRESENT','error':q.stderr[-1000:]}
    arr=json.loads(q.stdout); x=arr[0] if arr else {}
    return {'image':image,'status':'PRESENT','image_id':x.get('Id'),'repo_digests':sorted(x.get('RepoDigests') or []),'repo_tags':sorted(x.get('RepoTags') or []),'architecture':x.get('Architecture'),'os':x.get('Os'),'labels':dict(sorted(((x.get('Config') or {}).get('Labels') or {}).items()))}

def locate_compose(root,candidates):
    for c in candidates or []:
        p=root/c
        if p.is_file(): return p
    found=[]
    for pat in ('docker-compose.yml','docker-compose.yaml','compose.yml','compose.yaml'):
        found.extend(root.glob('**/'+pat))
    found=sorted([p for p in found if len(p.relative_to(root).parts)<=5])
    return found[0] if found else None

def cmd_runtime_freeze(a):
    if not docker_ok():
        write_json(a.output,{'status':'FAIL_CLOSED','reason':'docker_daemon_unavailable'}); return 2
    catalog=read_json(a.catalog); plan,pmap,_=_source_maps(a.prep); rows=[]; issues=[]
    for c in catalog.get('sources',[]):
        sid=c['source_id']; sp=pmap.get(sid) or {}; root=Path(sp.get('workspace_path') or (Path(a.workspace)/sid)); head=git_head(root)
        row={'source_id':sid,'git_head':head,'runtime':c.get('runtime'),'formal_n_cap':c.get('formal_n_cap',0),'workspace_path':str(root),'resolved_at':now()}
        if head!=sp.get('git_head'): row.update(status='FAIL_CLOSED_GIT_DRIFT'); issues.append(f'{sid}: git drift'); rows.append(row); continue
        mode=c.get('runtime')
        if mode in {'docker_image','docker_image_or_compose'} and c.get('image'):
            image=c['image']
            if a.resolve:
                q=run(['docker','pull',image],timeout=a.pull_timeout)
                row['pull_returncode']=q.returncode; row['pull_stderr_tail']=q.stderr[-2000:]
            meta=image_metadata(image); row['image']=meta
            row['runtime_alignment']='digest_pinned_prebuilt_image'
            if meta.get('status')!='PRESENT': row['status']='RUNTIME_UNRESOLVED'; issues.append(f'{sid}: image unresolved')
            else: row['status']='PASS'
        else:
            cp=locate_compose(root,c.get('compose_candidates'))
            row['compose_path']=str(cp.relative_to(root)) if cp else None
            if not cp: row['status']='RUNTIME_UNRESOLVED'; issues.append(f'{sid}: compose not found')
            else:
                q=run(['docker','compose','-f',str(cp),'config','--images'],cwd=cp.parent,timeout=60)
                imgs=sorted(set(x.strip() for x in q.stdout.splitlines() if x.strip())) if q.returncode==0 else []
                if a.resolve:
                    # Pull only; do not start services in the freeze stage.
                    pq=run(['docker','compose','-f',str(cp),'pull'],cwd=cp.parent,timeout=a.pull_timeout)
                    row['pull_returncode']=pq.returncode; row['pull_stderr_tail']=pq.stderr[-2000:]
                    q=run(['docker','compose','-f',str(cp),'config','--images'],cwd=cp.parent,timeout=60); imgs=sorted(set(x.strip() for x in q.stdout.splitlines() if x.strip())) if q.returncode==0 else imgs
                row['images']=[image_metadata(i) for i in imgs]
                row['runtime_alignment']='compose_from_frozen_repo_with_digest_capture'
                row['status']='PASS' if imgs and all(x.get('status')=='PRESENT' for x in row['images']) else 'RUNTIME_PARTIAL'
        fp_seed={'source_id':sid,'git_head':head,'runtime':row.get('runtime'),'image':row.get('image'),'images':row.get('images'),'compose_path':row.get('compose_path')}
        row['environment_fingerprint']=sha_bytes(json.dumps(fp_seed,sort_keys=True).encode())
        rows.append(row)
    stress=(plan.get('stress_corpus') or {}); sid=stress.get('source_id'); root=Path(stress.get('workspace_path') or (Path(a.workspace)/(sid or 'stress')))
    rows.append({'source_id':sid,'git_head':git_head(root),'runtime':'source_tree','formal_n_cap':0,'workspace_path':str(root),'status':'PASS' if git_head(root)==stress.get('git_head') else 'FAIL_CLOSED_GIT_DRIFT','environment_fingerprint':sha_bytes(f'{sid}|{git_head(root)}'.encode())})
    out={'status':'PASS' if not any(x.get('status','').startswith('FAIL_CLOSED') for x in rows) else 'FAIL_CLOSED','resolve_requested':a.resolve,'rows':rows,'issues':issues,'automatic_registry_mutation':False}
    write_json(a.output,out); print(json.dumps({'status':out['status'],'rows':len(rows),'issues':issues},indent=2)); return 0 if out['status']=='PASS' else 2

def wait_http(url,timeout=150):
    end=time.time()+timeout; last=None
    while time.time()<end:
        try:
            r=requests.get(url,timeout=5,allow_redirects=False,verify=False); last=r.status_code
            if 100<=r.status_code<600: return True,last
        except Exception: pass
        time.sleep(2)
    return False,last

def pull_digest_ref(meta):
    digs=(meta or {}).get('repo_digests') or []
    return digs[0] if digs else (meta or {}).get('image')

def start_image(source, runtime_row):
    ports=source.get('container_ports') or []
    if not ports: raise RuntimeError('no container ports declared')
    hostports=[choose_free_port(9300+i*20,9319+i*20) for i,_ in enumerate(ports)]
    name='rfc-p2-'+safe_id(source['source_id']).lower()+'-'+str(os.getpid())
    ref=pull_digest_ref(runtime_row.get('image')) or source.get('image')
    cmd=['docker','run','--rm','-d','--name',name]
    for hp,cp in zip(hostports,ports): cmd += ['-p',f'127.0.0.1:{hp}:{cp}']
    cmd += [ref]
    q=run(cmd,timeout=120)
    if q.returncode: raise RuntimeError('docker run failed: '+q.stderr[-1200:])
    return {'kind':'docker_image','name':name,'ref':ref,'hostports':hostports,'container_ports':ports}

def stop_runtime(rt):
    if not rt:return
    if rt.get('kind')=='docker_image': run(['docker','rm','-f',rt['name']],timeout=60)

def obs(r,role,request_meta=None):
    body=r.content
    return {'role':role,'status_code':r.status_code,'headers':{k:v for k,v in r.headers.items() if k.lower() in {'content-type','location'}},'body_sha256':sha_bytes(body),'body_length':len(body),'body_preview':r.text[:2000],'request':request_meta or {}}

def juice_shop_driver(base):
    s=requests.Session(); endpoint=base+'/rest/user/login'
    control_payload={'email':'nobody-rfc@example.invalid','password':'not-a-password'}
    candidate_payload={'email':"' OR 1=1-- ",'password':'x'}
    c=s.post(endpoint,json=control_payload,timeout=15,allow_redirects=False); d=s.post(endpoint,json=candidate_payload,timeout=15,allow_redirects=False)
    co=obs(c,'control',{'method':'POST','path':'/rest/user/login','json_sha256':sha_bytes(json.dumps(control_payload,sort_keys=True).encode())})
    ca=obs(d,'candidate',{'method':'POST','path':'/rest/user/login','json_sha256':sha_bytes(json.dumps(candidate_payload,sort_keys=True).encode()),'safe_proof':'authentication-only SQLi; no state mutation'})
    auth=None
    try: auth=(d.json().get('authentication') or {})
    except Exception: pass
    success=bool(c.status_code in {400,401,403} and d.status_code==200 and auth and auth.get('token'))
    ca['protected_access_marker']=bool(auth and auth.get('token')); ca['authenticated_identity']=auth.get('umail') if auth else None
    return {'driver':'juice_shop_login_sqli','category':'sqli','observations':[co,ca],'proof_valid':success,'validator_status':'confirmed' if success else 'needs_manual_review','validator_confidence':0.95 if success else 0.35,'proof_obligations':{'control_request_compared':['E1','E2'],'differential_response_or_error':['E1','E2'],'target_endpoint_match':['E1','E2'],'reproduction_request':['E2']} if success else {},'limitations':[] if success else ['expected 401/403 control and token-bearing 200 candidate not observed']}

def _csrf(text):
    for pat in [r'name=["\']_csrf["\'][^>]*value=["\']([^"\']+)',r'value=["\']([^"\']+)["\'][^>]*name=["\']_csrf["\']']:
        m=re.search(pat,text,re.I)
        if m:return html.unescape(m.group(1))
    return None

def webgoat_driver(base):
    s=requests.Session(); login=base+'/WebGoat/login'
    g=s.get(login,timeout=15); token=_csrf(g.text); user='rfcv2_'+hashlib.sha256(str(time.time()).encode()).hexdigest()[:10]; password='RFCv2!Test12345'
    reg_candidates=[
      ('/WebGoat/register.mvc',{'username':user,'password':password,'matchingPassword':password,'agree':'agree'}),
      ('/WebGoat/register',{'username':user,'password':password,'matchingPassword':password,'agree':'agree'}),
    ]
    registered=False; reg_obs=[]
    for path,data in reg_candidates:
        if token:data['_csrf']=token
        r=s.post(base+path,data=data,timeout=15,allow_redirects=False); reg_obs.append({'path':path,'status':r.status_code,'location':r.headers.get('Location')})
        if r.status_code in {200,302,303}: registered=True; break
    # Login; refresh csrf because registration may rotate session.
    lg=s.get(login,timeout=15); token=_csrf(lg.text); data={'username':user,'password':password}
    if token:data['_csrf']=token
    lr=s.post(login,data=data,timeout=15,allow_redirects=True)
    if not registered or ('login' in urllib.parse.urlsplit(lr.url).path.lower() and lr.status_code==200):
        return {'driver':'webgoat_sqli_lesson5a','category':'sqli','observations':[],'proof_valid':False,'validator_status':'needs_manual_review','validator_confidence':0.0,'proof_obligations':{},'limitations':['WebGoat deterministic registration/login fixture could not be established'],'fixture_diagnostics':{'registration_attempts':reg_obs,'login_final_url':lr.url,'login_status':lr.status_code}}
    endpoint=base+'/WebGoat/SqlInjection/attack5a'
    control={'account':"Smith'",'operator':'and','injection':"'1'='2"}
    candidate={'account':"Smith'",'operator':'or','injection':"'1'='1"}
    c=s.post(endpoint,data=control,timeout=15,allow_redirects=False); d=s.post(endpoint,data=candidate,timeout=15,allow_redirects=False)
    co=obs(c,'control',{'method':'POST','path':'/WebGoat/SqlInjection/attack5a','form_sha256':sha_bytes(urllib.parse.urlencode(control).encode())})
    ca=obs(d,'candidate',{'method':'POST','path':'/WebGoat/SqlInjection/attack5a','form_sha256':sha_bytes(urllib.parse.urlencode(candidate).encode()),'safe_proof':'read-only SELECT differential'})
    success=bool(c.status_code==200 and d.status_code==200 and co['body_sha256']!=ca['body_sha256'] and (len(d.content)>len(c.content) or re.search(r'success|congrat',d.text,re.I)))
    return {'driver':'webgoat_sqli_lesson5a','category':'sqli','observations':[co,ca],'proof_valid':success,'validator_status':'confirmed' if success else 'needs_manual_review','validator_confidence':0.90 if success else 0.35,'proof_obligations':{'control_request_compared':['E1','E2'],'differential_response_or_error':['E1','E2'],'target_endpoint_match':['E1','E2'],'reproduction_request':['E2']} if success else {},'limitations':[] if success else ['read-only SQLi differential not strong enough'],'fixture_diagnostics':{'registration_attempts':reg_obs,'login_final_url':lr.url,'login_status':lr.status_code}}

def source_discovery(source, root, max_files=120, max_hits=30):
    """Read-only source inventory for adapter-gap triage. Never derives a proof or decision."""
    root=Path(root); terms=[str(x).lower() for x in (source.get('discovery_terms') or source.get('candidate_terms') or [])]
    if not terms:
        terms=[str(source.get('category') or '').lower(), 'route', 'endpoint']
    allow_ext={'.py','.js','.ts','.java','.go','.rb','.php','.yml','.yaml','.json','.md','.txt'}
    files=[]; hits=[]
    iterable=root.rglob('*') if root.exists() else []
    for fp in iterable:
        if not fp.is_file() or fp.suffix.lower() not in allow_ext: continue
        if any(part in {'.git','node_modules','target','dist','build','.venv','venv'} for part in fp.relative_to(root).parts): continue
        files.append(fp)
        if len(files)>=max_files: break
    route_re=re.compile(r'(?:@(?:app|router)\.(?:get|post|put|delete|patch)|\b(?:GET|POST|PUT|DELETE|PATCH)\s+|\.route\(|\.get\(|\.post\()',re.I)
    for fp in files:
        try: text=fp.read_text(errors='replace')
        except Exception: continue
        for ln,line in enumerate(text.splitlines(),1):
            low=line.lower()
            if (terms and any(t and t in low for t in terms)) or route_re.search(line):
                hits.append({'path':str(fp.relative_to(root)),'line':ln,'line_sha256':sha_bytes(line.encode()),'preview':line[:500]})
                if len(hits)>=max_hits: break
        if len(hits)>=max_hits: break
    return {'source_id':source['source_id'],'workspace_path':str(root),'terms':terms,'files_scanned':len(files),'hits':hits,'note':'read-only source discovery only; no endpoint/proof is inferred from these hits'}

def oracle_review_template(rows):
    out=[]
    for x in rows:
        if x.get('status') not in {'CAPTURE_OK_EVIDENTIARY','CAPTURE_REVIEW_REQUIRED'}: continue
        out.append({
            'source_id':x.get('source_id'),
            'environment_fingerprint':x.get('environment_fingerprint'),
            'category':x.get('category'),
            'vulnerable':None,
            'ideal_decision':None,
            'oracle_source':None,
            'oracle_independent_of_validator':None,
            'independence_eligible':None,
            'independence_basis':None,
            'split_role':'certify',
            'note':'FILL FROM INDEPENDENT SOURCE/REVIEW. Do not infer from capture, validator, or RFC decision.'
        })
    return out

def cmd_execute(a):
    catalog=read_json(a.catalog); runtime=read_json(a.runtime); rmap={x['source_id']:x for x in runtime.get('rows',[])}; outdir=Path(a.outdir); outdir.mkdir(parents=True,exist_ok=True)
    rows=[]
    for src in catalog.get('sources',[]):
        sid=src['source_id']; rr=rmap.get(sid) or {}; row={'source_id':sid,'category':src.get('category'),'formal_n_cap':src.get('formal_n_cap',0),'driver':src.get('driver'),'environment_fingerprint':rr.get('environment_fingerprint'),'git_head':rr.get('git_head'),'started_at':now(),'scientific_acceptance_automatic':False}
        if rr.get('status') not in {'PASS','RUNTIME_PARTIAL'}:
            row.update(status='RUNTIME_BLOCKED',formal_candidate=False,blocker='RUNTIME_NOT_FROZEN'); rows.append(row); continue
        if src.get('driver')=='adapter_gap':
            root=Path(rr.get('workspace_path') or '')
            row.update(status='ADAPTER_GAP',formal_candidate=False,blocker=src.get('blocker'),source_discovery=source_discovery(src,root)); rows.append(row); continue
        rt=None
        try:
            if src.get('runtime') not in {'docker_image','docker_image_or_compose'}: raise RuntimeError('current curated driver requires image runtime')
            rt=start_image(src,rr); base='http://127.0.0.1:'+str(rt['hostports'][0]); ready,last=wait_http(base+src.get('readiness_path','/'),a.readiness_timeout)
            row['runtime']={**rt,'readiness_last_status':last}
            if not ready: raise RuntimeError('application readiness failed')
            res=juice_shop_driver(base) if src['driver']=='juice_shop_login_sqli' else webgoat_driver(base)
            row['result']=res; row['status']='CAPTURE_OK_EVIDENTIARY' if res.get('proof_valid') else 'CAPTURE_REVIEW_REQUIRED'; row['formal_candidate']=bool(res.get('proof_valid') and src.get('formal_n_cap',0)>0)
            row['method_outputs']={'candidate_raw_decision':'confirm','validator_only_decision':'confirm' if res.get('validator_status')=='confirmed' else 'abstain','proof_gate_only_decision':'confirm' if res.get('proof_valid') and res.get('proof_obligations') else 'abstain','confidence_threshold_decision':'confirm' if float(res.get('validator_confidence',0))>=a.confidence_threshold else 'abstain','rfc_full_decision':'confirm' if res.get('proof_valid') and float(res.get('validator_confidence',0))>=a.confidence_threshold else 'abstain'}
        except Exception as e:
            row.update(status='RUN_ERROR',formal_candidate=False,error=f'{type(e).__name__}: {e}')
        finally:
            stop_runtime(rt); row['completed_at']=now()
        write_json(outdir/(safe_id(sid)+'.json'),row); rows.append(row)
    write_jsonl(outdir/'phase2_execution_rows.jsonl',rows)
    write_jsonl(outdir/'oracle_review_template.jsonl',oracle_review_template(rows))
    write_jsonl(outdir/'adapter_discovery.jsonl',[{'source_id':x['source_id'],'blocker':x.get('blocker'),'source_discovery':x.get('source_discovery')} for x in rows if x.get('status')=='ADAPTER_GAP'])
    rep={'status':'PASS' if rows and any(x.get('formal_candidate') for x in rows) else 'PARTIAL','sources':len(rows),'formal_candidates':sum(bool(x.get('formal_candidate')) for x in rows),'capture_ok':sum(x.get('status')=='CAPTURE_OK_EVIDENTIARY' for x in rows),'adapter_gaps':sum(x.get('status')=='ADAPTER_GAP' for x in rows),'errors':sum(x.get('status')=='RUN_ERROR' for x in rows),'oracle_review_rows':len(oracle_review_template(rows)),'automatic_registry_mutation':False}
    write_json(outdir/'execution_summary.json',rep); print(json.dumps(rep,indent=2)); return 0

def cmd_stress(a):
    plan=read_json(Path(a.prep)/'source_plan.json'); st=plan.get('stress_corpus') or {}; root=Path(st.get('workspace_path') or (Path(a.workspace)/'P2-OWASP-BENCHMARK-JAVA'))
    files=sorted(root.glob('expectedresults-*.csv'))
    if not files:
        write_json(a.output,{'status':'FAIL_CLOSED','reason':'expectedresults csv not found','formal_n_contribution':0}); return 2
    p=files[-1]; rows=[]
    with p.open(newline='',encoding='utf-8-sig') as f:
        rd=csv.DictReader(f)
        for r in rd: rows.append(r)
    # Normalize common Benchmark columns without assuming only one release schema.
    def field(r,*names):
        low={k.lower():v for k,v in r.items()}
        for n in names:
            if n.lower() in low:return low[n.lower()]
        return None
    cats=defaultdict(list)
    for r in rows:
        cat=field(r,'category','cwe','test category') or 'unknown'; cats[cat].append(r)
    sample=[]; cap=max(1,a.max_cases); keys=sorted(cats)
    i=0
    while len(sample)<cap and keys:
        progressed=False
        for k in list(keys):
            if i<len(cats[k]):
                r=cats[k][i]; sample.append({'case_id':field(r,'test name','testname','test number','testnumber') or f'{k}-{i}','category':k,'expected':field(r,'real vulnerability','realvulnerability','true vulnerability','vulnerable') or field(r,'expected'),'raw':r}); progressed=True
                if len(sample)>=cap:break
        if not progressed:break
        i+=1
    out={'status':'PASS','source_id':'P2-OWASP-BENCHMARK-JAVA','expected_results_file':str(p),'expected_results_sha256':sha_file(p),'total_cases':len(rows),'sampled_cases':len(sample),'categories':dict(sorted(Counter(x['category'] for x in sample).items())),'formal_n_contribution':0,'note':'stress-only corpus; no same-runtime case contributes to formal certification N','sample':sample}
    write_json(a.output,out)
    if getattr(a,'blinded_output',None):
        write_jsonl(a.blinded_output,[{'case_id':x['case_id'],'category':x['category'],'source_id':'P2-OWASP-BENCHMARK-JAVA','formal_n_contribution':0} for x in sample])
    if getattr(a,'oracle_output',None):
        write_jsonl(a.oracle_output,[{'case_id':x['case_id'],'category':x['category'],'expected':x.get('expected'),'oracle_source_file_sha256':sha_file(p),'formal_n_contribution':0} for x in sample])
    print(json.dumps({k:v for k,v in out.items() if k!='sample'},indent=2)); return 0

def _norm(v):
    v=str(v or '').strip().lower();return v if v in DECISIONS else None

def cmd_ablation_materialize(a):
    exec_rows=read_jsonl(Path(a.execution_dir)/'phase2_execution_rows.jsonl'); agents={x.get('source_id'):x for x in read_jsonl(a.agent_outputs)} if a.agent_outputs and Path(a.agent_outputs).exists() else {}
    rows=[]; missing=[]
    for x in exec_rows:
        if x.get('status') not in {'CAPTURE_OK_EVIDENTIARY','CAPTURE_REVIEW_REQUIRED'}: continue
        mo=x.get('method_outputs') or {}; ag=agents.get(x['source_id']) or {}; agent=_norm(ag.get('agent_raw_decision'))
        if not agent: missing.append({'source_id':x['source_id'],'field':'agent_raw_decision'})
        oracle=ag.get('oracle') or {}
        ideal=_norm(oracle.get('ideal_decision')); vuln=oracle.get('vulnerable')
        if not ideal or not isinstance(vuln,bool): missing.append({'source_id':x['source_id'],'field':'oracle'})
        rows.append({'case_id':x['source_id'],'environment_id':x.get('environment_fingerprint'),'source_ecosystem':x['source_id'],'vulnerable':vuln if isinstance(vuln,bool) else None,'ideal_decision':ideal,'agent_raw_decision':agent,'validator_only_decision':_norm(mo.get('validator_only_decision')),'proof_gate_only_decision':_norm(mo.get('proof_gate_only_decision')),'confidence_threshold_decision':_norm(mo.get('confidence_threshold_decision')),'rfc_full_decision':_norm(mo.get('rfc_full_decision'))})
    write_jsonl(a.output,rows); rep={'status':'PASS' if not missing and rows else 'FAIL_CLOSED','rows':len(rows),'missing':missing,'note':'agent/oracle outputs are never inferred from RFC/validator outputs'}; write_json(Path(a.output).with_suffix('.summary.json'),rep); print(json.dumps(rep,indent=2)); return 0 if rep['status']=='PASS' else 2

def cmd_aggregate(a):
    pre=read_json(a.preflight); rt=read_json(a.runtime); ex=read_json(Path(a.execution_dir)/'execution_summary.json'); stress=read_json(a.stress); abl=read_json(a.ablation) if a.ablation and Path(a.ablation).exists() else {'status':'NOT_RUN'}
    rows=read_jsonl(Path(a.execution_dir)/'phase2_execution_rows.jsonl')
    formal=[x for x in rows if x.get('formal_candidate')]
    rep={'status':'PASS','phase':'PHASE2_FINAL_EXECUTION','phase1_frozen':pre.get('status')=='PASS','runtime_freeze_status':rt.get('status'),'p2a_sources':len(rows),'p2a_formal_review_candidates':len(formal),'p2a_candidates_by_source':[x['source_id'] for x in formal],'p2b_stress_status':stress.get('status'),'p2b_stress_cases':stress.get('sampled_cases',0),'ablation_status':abl.get('status'),'scientific_acceptance_automatic':False,'registry_mutated':False,'formal_n_increment_automatic':0,'next_action':'scientific review of P2-A candidates; explicit oracle/agent outputs required before 5-way ablation' if abl.get('status')!='PASS' else 'scientific review of P2-A candidates and freeze final metrics'}
    write_json(a.output,rep); print(json.dumps(rep,indent=2)); return 0

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('verify');p.add_argument('--prep',default=str(DEFAULT_PREP));p.add_argument('--output',required=True);p.set_defaults(fn=cmd_verify)
    p=sub.add_parser('runtime-freeze');p.add_argument('--prep',default=str(DEFAULT_PREP));p.add_argument('--workspace',default=str(DEFAULT_WORKSPACE));p.add_argument('--catalog',default=str(HERE/'config/phase2_execution_catalog.json'));p.add_argument('--output',required=True);p.add_argument('--resolve',action='store_true');p.add_argument('--pull-timeout',type=int,default=1200);p.set_defaults(fn=cmd_runtime_freeze)
    p=sub.add_parser('execute');p.add_argument('--catalog',default=str(HERE/'config/phase2_execution_catalog.json'));p.add_argument('--runtime',required=True);p.add_argument('--outdir',required=True);p.add_argument('--readiness-timeout',type=int,default=180);p.add_argument('--confidence-threshold',type=float,default=.8);p.set_defaults(fn=cmd_execute)
    p=sub.add_parser('stress');p.add_argument('--prep',default=str(DEFAULT_PREP));p.add_argument('--workspace',default=str(DEFAULT_WORKSPACE));p.add_argument('--output',required=True);p.add_argument('--blinded-output');p.add_argument('--oracle-output');p.add_argument('--max-cases',type=int,default=240);p.set_defaults(fn=cmd_stress)
    p=sub.add_parser('ablation-materialize');p.add_argument('--execution-dir',required=True);p.add_argument('--agent-outputs');p.add_argument('--output',required=True);p.set_defaults(fn=cmd_ablation_materialize)
    p=sub.add_parser('aggregate');p.add_argument('--preflight',required=True);p.add_argument('--runtime',required=True);p.add_argument('--execution-dir',required=True);p.add_argument('--stress',required=True);p.add_argument('--ablation');p.add_argument('--output',required=True);p.set_defaults(fn=cmd_aggregate)
    a=ap.parse_args();return a.fn(a)
if __name__=='__main__':raise SystemExit(main())
