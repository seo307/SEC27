# RFC/Main-V2 Final Evaluation / Ablation (V5.5)

V5.5 closes corpus expansion. It is a read-only final evaluation overlay on audited V5.4.1 and never mutates Phase-1/Phase-2 raw runs or the scientific registry.

## Evaluation cohorts

The primary final casepack is constructed before the new agent baseline is run.

1. **External reviewed cohort** — all scientifically accepted registry environments, using `first_accepted_run_id` when available. Exactly one environment fingerprint appears once.
2. **Internal controlled stress cohort** — the existing `work/live` positive/negative benchmark pairs. Only the lowest repetition (normally repetition 1) is used for the primary ablation, so the five repetitions are not treated as independent N.
3. **Phase-2 external candidate** — Juice Shop, only after a frozen-source oracle passes. Its formal registry admission remains an explicit review decision because the oracle file is completed post-capture.

The internal controlled stress cohort supplies balanced negative controls and ambiguous positives. It contributes formal N=0.

## Frozen method rules

`config/final_eval_methods.json` is hashed before any new agent output is generated.

1. `agent_raw`: explicit LLM/agent decision on blinded candidate + observations only.
2. `validator_only`: CONFIRM iff the logged validator status is `confirmed`.
3. `proof_gate_only`: CONFIRM iff all logged proof obligations are bound to evidence IDs present in the capture. Legacy internal captures without proof-bundle bindings therefore ABSTAIN by design.
4. `confidence_threshold`: CONFIRM iff logged validator confidence >= 0.80.
5. `rfc_full`: CONFIRM iff both proof gate and confidence threshold confirm.

The exact corpus-level FCR certificate is evaluated separately from per-case ablation decisions.

## Metrics

The final report includes FCR and coverage, but also metrics needed when a case is vulnerable yet should still be abstained:

- decision accuracy vs independent ideal decision,
- unsafe promotion rate,
- unsupported confirmation rate,
- ambiguous-positive overconfirmations,
- breakdown by cohort, category, and scenario.

## Juice Shop oracle

The oracle is frozen from the pinned, clean Juice Shop Git tree and challenge metadata only. It requires:

- frozen Git HEAD == source-build runtime revision,
- `routes/login.ts` contains the `loginAdminChallenge` vulnerable query marker and request-controlled SQL construction,
- `data/static/challenges.yml` identifies `Login Admin` as an `Injection` challenge with key `loginAdminChallenge`.

The oracle does not read the validator result or infer truth from capture success. The artifact records `oracle_timing=post_capture_source_only` and `formal_registry_admission=REVIEW_REQUIRED_TIMING_CAVEAT`.

## 1. Prepare the immutable casepack

```bash
export RFC_FINAL_CORRECTION_RUN="$PWD/research/risk_controlled_confirmation_experiment/external/phase2_correction_runs/20260811T045121Z-p2c541-23931"
research/risk_controlled_confirmation_experiment/phase2/run_final_evaluation.sh --prepare
```

The command prints `RUN_DIR`. Preserve it:

```bash
export RFC_FINAL_EVAL_OUT="<RUN_DIR>"
```

Expected primary casepack on the current checkpoint is approximately 24 rows: 11 accepted external environments + 12 controlled benchmark cases + 1 Juice Shop candidate, assuming all historical first-accepted run directories remain present. The runner fails closed if an accepted registry environment cannot be located.

## 2. Run the blinded raw-agent baseline

OpenAI example:

```bash
export RFC_FINAL_AGENT_PROVIDER=openai
export RFC_FINAL_AGENT_MODEL=gpt-5.4
research/risk_controlled_confirmation_experiment/phase2/run_final_evaluation.sh --agent
```

Anthropic example:

```bash
export RFC_FINAL_AGENT_PROVIDER=anthropic
export RFC_FINAL_AGENT_MODEL='<available Claude model id>'
research/risk_controlled_confirmation_experiment/phase2/run_final_evaluation.sh --agent
```

The model receives neither oracle nor validator/proof/scenario/registry labels. Agent-facing case IDs are deterministic opaque `FE-...` identifiers; original case names, cohort labels, source-ecosystem labels, and candidate titles are not sent. The runner also fails before an API call if either forbidden key names or negative/positive scenario markers survive blinding.

You can run more than one model. Each produces a separate file in `agent_outputs/`; choose one prespecified primary model for the main table and keep additional models as robustness/supplementary analyses.

## 3. Finalize

```bash
export RFC_FINAL_AGENT_OUTPUT="$RFC_FINAL_EVAL_OUT/agent_outputs/<label>.jsonl"
research/risk_controlled_confirmation_experiment/phase2/run_final_evaluation.sh --finalize
```

Primary outputs:

- `casepack_agent_blinded.jsonl`
- `casepack_case_map.jsonl` (never sent to the agent)
- `casepack_oracle.jsonl`
- `casepack_methods.jsonl`
- `FROZEN_METHOD_RULES.json`
- `SCIENTIFIC_REGISTRY_SNAPSHOT.json`
- `agent_outputs_template.jsonl`
- `juice_shop_oracle_source_freeze.json`
- `ablation_rows.jsonl`
- `FINAL_ABLATION_RESULTS.json`
- `FINAL_ABLATION_RESULTS.csv`
- `FINAL_ABLATION_RESULTS_by_cohort.csv`
- `FINAL_ABLATION_RESULTS_by_category.csv`
- `FINAL_ABLATION_RESULTS_by_scenario.csv`
- `formal_progress.json`
- `FINAL_EVALUATION_SUMMARY.json`
- `FINAL_MANIFEST.sha256`

## Non-negotiable policies

- Existing raw runs are read-only.
- Registry mutation is never automatic.
- Accepted external environments are not reselected based on new results.
- Repetitions do not increase primary case count or formal N.
- Internal stress and ablation rows have formal N=0.
- Agent outputs and oracle truth remain separate immutable files.
- Juice Shop formal registry admission is not automatic.
