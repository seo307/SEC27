#!/usr/bin/env python3
"""Discover public benchmark candidates with mechanism-aware classification.

V4 avoids full-README keyword contamination. Formal classification is based on
README title/path and vulnerability reproduction/exploit sections; references,
related-issue lists, and incidental chaining mentions are not sufficient by
themselves.  A category-independent environment fingerprint is emitted so one
underlying public environment cannot be counted twice as independent formal N.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,re
from pathlib import Path

HERE=Path(__file__).resolve().parent
PATTERNS={
 'sqli':[r'\bsqli\b',r'sql injection',r'cwe[- ]?89'],
 'idor':[r'\bidor\b',r'insecure direct object',r'broken object level authorization',r'\bbola\b',r'cwe[- ]?639'],
 'ssrf':[r'\bssrf\b',r'server[- ]side request forgery',r'cwe[- ]?918'],
 'auth_bypass':[r'authentication bypass',r'auth(?:entication)? bypass',r'improper authentication',r'cwe[- ]?287',r'unauthenticated access'],
 'ssti':[r'\bssti\b',r'server[- ]side template injection',r'template injection',r'velocity template injection',r'smarty template'],
 'xss':[r'\bxss\b',r'cross[- ]site scripting',r'javascript (?:code )?injection',r'cwe[- ]?79'],
}
CVE_RE=re.compile(r'\bCVE-\d{4}-\d{4,7}\b',re.I)
HEADING=re.compile(r'^(#{1,6})\s+(.+?)\s*$',re.M)
EXCLUDED_SECTION=re.compile(r'^(references?|related|links?|credit|acknowledg|mitigation|patch)',re.I)
REPRO_SECTION=re.compile(r'(exploit|vulnerab(?:ility|le).*(?:repro|reproduction|verification)|reproduc|proof.of.concept|\bpoc\b|attack)',re.I)


def sha(*xs): return hashlib.sha256('|'.join(map(str,xs)).encode()).hexdigest()
def read_text(p:Path):
    try:return p.read_text(errors='ignore')[:800000]
    except Exception:return ''

def first_title(text:str)->str:
    m=HEADING.search(text)
    return m.group(2).strip() if m else ''

def markdown_sections(text:str)->list[tuple[str,str]]:
    matches=list(HEADING.finditer(text)); out=[]
    if not matches:return [('',text)]
    # intro before first H2/H3 belongs to the H1 title/intro context.
    for i,m in enumerate(matches):
        start=m.end(); end=matches[i+1].start() if i+1<len(matches) else len(text)
        out.append((m.group(2).strip(), text[start:end]))
    return out

def mechanism_text(text:str)->str:
    chunks=[]
    for title,body in markdown_sections(text):
        if EXCLUDED_SECTION.search(title): continue
        if REPRO_SECTION.search(title): chunks.append(title+'\n'+body)
    return '\n'.join(chunks)

def intro_text(text:str)->str:
    # H1 plus prose until the first H2; references are excluded later by weight.
    m=re.search(r'^##\s+',text,re.M)
    return text[:m.start()] if m else text[:5000]

def hits(cat:str,text:str)->list[str]:
    return [p for p in PATTERNS[cat] if re.search(p,text,re.I)]

def classify(rel:str,text:str)->list[dict]:
    title=first_title(text); repro=mechanism_text(text); intro=intro_text(text)
    scored=[]
    for cat in PATTERNS:
        th=hits(cat,title); ph=hits(cat,rel); rh=hits(cat,repro); ih=hits(cat,intro)
        score=5*bool(th)+4*bool(ph)+3*bool(rh)+1*bool(ih)
        # Require strong placement: title/path/reproduction, never intro-only.
        eligible=bool(th or ph or rh)
        if eligible:
            basis=[]
            if th:basis.append('title')
            if ph:basis.append('path')
            if rh:basis.append('reproduction')
            if ih:basis.append('intro')
            scored.append({'category':cat,'score':score,'basis':basis,'hits':sorted(set(th+ph+rh+ih))})
    scored.sort(key=lambda x:(-x['score'],x['category']))
    if scored:
        top=scored[0]['score']
        for x in scored:x['primary_category']=(x['score']==top)
    return scored

def compose_file(d:Path):
    for n in ['docker-compose.yml','docker-compose.yaml','compose.yml','compose.yaml']:
        if (d/n).is_file():return d/n
    return None

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--registry',default=str(HERE/'source_registry.json'));ap.add_argument('--sources-root',default=str(HERE/'external/sources'));ap.add_argument('--output',default=str(HERE/'external/candidate_catalog.csv'))
    a=ap.parse_args();reg=json.loads(Path(a.registry).read_text());root=Path(a.sources_root);rows=[]
    for src in reg['sources']:
        base=root/src['name']
        if not base.exists():continue
        if src['scan_mode']=='compose_readmes':
            dirs=set()
            for pat in ('docker-compose.yml','docker-compose.yaml','compose.yml','compose.yaml'):
                dirs.update(p.parent for p in base.rglob(pat))
            for d in sorted(dirs):
                rel=d.relative_to(base);rps=[p for p in d.iterdir() if p.is_file() and p.name.lower().startswith('readme')]
                text='\n'.join(read_text(p) for p in rps); classes=classify(str(rel),text)
                if not classes:continue
                cves=sorted(set(x.upper() for x in CVE_RE.findall(first_title(text)+'\n'+str(rel))))
                parts=rel.parts;product=parts[0] if parts else src['name'];advisory=(cves[0] if cves else (parts[-1] if parts else 'unknown'))
                env_fp=sha(src['repo_url'],str(rel),advisory)
                for c in classes:
                    finding_fp=sha(env_fp,c['category'])
                    rows.append({
                      'candidate_id':f"{src['name']}:{rel}:{c['category']}",'category':c['category'],'primary_category':'true' if c['primary_category'] else 'false',
                      'classification_score':c['score'],'classification_basis':';'.join(c['basis']),'classification_hits':';'.join(c['hits']),
                      'source_name':src['name'],'source_url':src['web_url'],'relative_path':str(rel),'software_product':product,'advisory_or_state':advisory,
                      'compose_path':str(compose_file(d).relative_to(base)),'readme_path':str(rps[0].relative_to(base)) if rps else '',
                      'environment_fingerprint':env_fp,'finding_fingerprint':finding_fp,'scenario_fingerprint':finding_fp,
                      'confidence':'high' if c['primary_category'] and c['score']>=5 else 'medium',
                      'formal_independence_recommended':'true' if src.get('formal_candidate_source') and c['primary_category'] and c['score']>=5 else 'false',
                      'supports_vulnerable_modes':'true','supports_negative_control':'false'
                    })
        else:
            docs=[]
            for name in ['README.md','docs/challenges.md','docs/README.md']:
                p=base/name
                if p.is_file():docs.append(p)
            text='\n'.join(read_text(p) for p in docs)
            for c in classify('.',text):
                env_fp=sha(src['repo_url'],'shared-codebase')
                rows.append({'candidate_id':f"{src['name']}:shared:{c['category']}",'category':c['category'],'primary_category':'true' if c['primary_category'] else 'false','classification_score':c['score'],'classification_basis':';'.join(c['basis']),'classification_hits':';'.join(c['hits']),'source_name':src['name'],'source_url':src['web_url'],'relative_path':'.','software_product':src['name'],'advisory_or_state':'shared-codebase','compose_path':'','readme_path':str(docs[0].relative_to(base)) if docs else '','environment_fingerprint':env_fp,'finding_fingerprint':sha(env_fp,c['category']),'scenario_fingerprint':sha(env_fp,c['category']),'confidence':'medium','formal_independence_recommended':'false','supports_vulnerable_modes':'true','supports_negative_control':'false'})
    uniq={r['finding_fingerprint']:r for r in rows};rows=sorted(uniq.values(),key=lambda r:(r['category'],r['source_name'],r['software_product'],r['candidate_id']))
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    fields=['candidate_id','category','primary_category','classification_score','classification_basis','classification_hits','source_name','source_url','relative_path','software_product','advisory_or_state','compose_path','readme_path','environment_fingerprint','finding_fingerprint','scenario_fingerprint','confidence','formal_independence_recommended','supports_vulnerable_modes','supports_negative_control']
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    from collections import Counter
    print(json.dumps({'status':'PASS','candidates':len(rows),'by_category':dict(Counter(r['category'] for r in rows)),'formal_recommended':sum(r['formal_independence_recommended']=='true' for r in rows),'unique_environments':len({r['environment_fingerprint'] for r in rows}),'output':str(out)},indent=2))
if __name__=='__main__':main()
