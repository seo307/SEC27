#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.metadata as md, json, os, platform, subprocess, sys, time
from pathlib import Path
from common import HERE, ROOT, load_json, write_jsonl, dump_json

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repetitions',type=int,default=None)
    ap.add_argument('--output-dir',default=str(HERE/'work/live'))
    ap.add_argument('--case',action='append',dest='cases')
    args=ap.parse_args()
    cfg=load_json(HERE/'config/experiment.json'); man=load_json(HERE/'config/study_manifest.json')['cases']
    reps=args.repetitions or cfg['default_repetitions']; selected=[c for c in man if not args.cases or c['case_id'] in set(args.cases)]
    out=Path(args.output_dir); raw=out/'raw'; raw.mkdir(parents=True,exist_ok=True)
    captures=[]; oracle=[]
    env=os.environ.copy(); env.update({'PENTEST_PILOT_VALIDATION_ONLY':'1','PENTEST_PILOT_FORCE_SEEDED':'1','PENTEST_PILOT_DIRECT_PROBES':'1','PENTEST_RFC_EXPORT_CAPTURE':'1'})
    for rep in range(1,reps+1):
        for case in selected:
            cid=case['case_id']; print(f'[{rep}/{reps}] {cid}',flush=True)
            result_path=ROOT/'benchmarks'/cid/'benchmark_result.json'
            if result_path.exists(): result_path.unlink()
            t0=time.time(); p=subprocess.run([sys.executable,str(ROOT/'benchmarks/run_benchmark.py'),cid],cwd=ROOT,text=True,capture_output=True,env=env)
            if result_path.exists():
                try: result=json.loads(result_path.read_text())
                except Exception as e: result={'case_id':cid,'status':'runner_error','message':str(e)}
            else: result={'case_id':cid,'status':'runner_error','message':(p.stderr or p.stdout)[-4000:]}
            capture_id=f'{cid}.r{rep}'
            payload={'capture_id':capture_id,'case_id':cid,'category':case['category'],'pair_id':case['pair_id'],'group_id':case.get('group_id',cid),'source_class':case.get('source_class','internal_controlled'),'independence_eligible':bool(case.get('independence_eligible',False)),'repetition':rep,'elapsed_seconds':round(time.time()-t0,3),'runner_returncode':p.returncode,'result':result}
            (raw/f'{capture_id}.json').write_text(json.dumps(payload,indent=2,default=str))
            # Blinded capture deliberately excludes ground truth and ideal decision.
            captures.append(payload)
            oracle.append({'capture_id':capture_id,'case_id':cid,'category':case['category'],'pair_id':case['pair_id'],'group_id':case.get('group_id',cid),'source_class':case.get('source_class','internal_controlled'),'independence_eligible':bool(case.get('independence_eligible',False)),'split_role':case.get('split_role'),'vulnerable':case['vulnerable'],'ideal_decision':case['ideal_decision'],'clean_confirmable':case['clean_confirmable']})
    write_jsonl(out/'captures_blinded.jsonl',captures); write_jsonl(out/'oracle_live.jsonl',oracle)
    def ver(name):
        try: return md.version(name)
        except md.PackageNotFoundError: return None
    dump_json(out/'environment.json',{'python':sys.version,'platform':platform.platform(),'packages':{x:ver(x) for x in ['pydantic','requests','flask','selenium','scipy','PyYAML']},'repetitions':reps,'cases':[c['case_id'] for c in selected]})
    bad=[c for c in captures if c['result'].get('status')!='ok' or not c['result'].get('rfc_capture')]
    dump_json(out/'capture_summary.json',{'scheduled':len(captures),'captured':len(captures)-len(bad),'invalid':len(bad),'invalid_ids':[x['capture_id'] for x in bad]})
    print(json.dumps({'scheduled':len(captures),'invalid':len(bad)},indent=2))
if __name__=='__main__': main()
