# RFC Main-V2 Capture v5.1 — Evidence Integrity & Network Isolation

V5.1 is an additive runtime/evidence patch on top of audited V5. It does not
change the formal risk-control method, oracle labels, split assignments, or
existing experimental data.

## What changes

1. **Immutable run directories**
   - each pipeline run writes under `external/runs/<run_id>/`;
   - export is bound to `acquisition_summary.run_id`;
   - stale raw JSON from older runs is rejected.
2. **Request replay fidelity**
   - source-request and parsed-spec SHA-256 values are recorded;
   - direct URL parsing preserves balanced SQL/CQL parentheses;
   - obviously truncated function payloads such as a request ending at
     `version(` are rejected before execution.
3. **SQLi semantic tightening**
   - generic application/CQL/parser errors no longer satisfy SQLi proof;
   - confirmation requires backend-database evidence.
4. **Application preconditions/readiness**
   - login redirects can become `AUTH_PRECONDITION_FAILED` rather than an
     epistemic abstention;
   - deployment/warm-up pages do not satisfy readiness.
5. **TLS protocol inference**
   - documented HTTP requests mapped to container ports 443/8443/9443/10443
     are replayed as HTTPS on the assigned 9000-range host port.
6. **Local SSRF callback**
   - eligible SSRF URL parameters are substituted with a nonce-correlated
     callback on the Docker bridge gateway;
   - callback receipts become direct server-side-outbound evidence;
   - no external Internet callback is required for the confirmation signal.
7. **Network failure separation**
   - registry/DNS/network/daemon/Compose failures are classified as
     infrastructure states and must not enter FCR/recall/abstention metrics.
8. **Runtime diagnostics**
   - Compose ps/log tail is stored per scheduled group under the run directory.

## Reference environment

Use native Linux **x86_64/amd64**, Docker Engine, and Docker Compose v2.
Published benchmark ports remain restricted to:

`127.0.0.1:9000-9999`

## Apply

```bash
python main_v2_capture_patch_v5_1/apply_patch.py \
  --repo ~/paper/pentest_Research_GroupA/main_test_V2 \
  --check

python main_v2_capture_patch_v5_1/apply_patch.py \
  --repo ~/paper/pentest_Research_GroupA/main_test_V2
```

## Rerun the same smoke set

Do not change the underlying five scenarios merely because earlier results were
unfavorable. The new run receives a new immutable run ID automatically.

```bash
cd ~/paper/pentest_Research_GroupA/main_test_V2
research/risk_controlled_confirmation_experiment/run_external_capture_pipeline.sh --limit 5
```

At completion, inspect:

```text
research/risk_controlled_confirmation_experiment/external/
├── latest_run.json
└── runs/<run_id>/
    ├── network_preflight.json
    ├── screen_summary.json
    ├── screened_capture_jobs.jsonl
    ├── acquired_raw/
    │   ├── acquisition_summary.json
    │   └── RFCEXT-*.json
    ├── diagnostics/
    ├── captures_blinded.jsonl
    ├── oracle.jsonl
    ├── acquisition_ledger.json
    ├── bundle_validation.json
    └── run_manifest.json
```

## Interpretation

Infrastructure classifications such as these are excluded from formal N:

- `REGISTRY_PULL_FAILED`
- `NETWORK_DEPENDENCY_UNREACHABLE`
- `DOCKER_DAEMON_UNAVAILABLE`
- `DOCKER_COMPOSE_UNAVAILABLE`
- `TARGET_NOT_READY`
- `APPLICATION_NOT_FULLY_READY`
- `AUTH_PRECONDITION_FAILED`
- `REPLAY_FIDELITY_FAILURE`
- `PROTOCOL_MISMATCH`

A record is exportable only when it belongs to the current run and has
`CAPTURE_OK_EVIDENTIARY` or `CAPTURE_PARTIAL_EVIDENTIARY`.

## Corporate-network note

`network_preflight.json` is informational. A blocked GitHub or Docker registry
endpoint explains acquisition infrastructure failures but is not a vulnerability
outcome. SSRF confirmation uses the local Docker-bridge callback where possible,
so an Internet callback service is not required.
