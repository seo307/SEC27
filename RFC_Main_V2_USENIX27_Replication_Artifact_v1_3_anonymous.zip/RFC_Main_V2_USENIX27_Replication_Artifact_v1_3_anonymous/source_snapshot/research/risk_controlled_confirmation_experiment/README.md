# Risk-Controlled Finding Confirmation — Main Experiment v2

Target venue: **USENIX Security 2027 Cycle 2**.

Main-v2 is the audited follow-up to Main-v1. Its purpose is to test whether an autonomous penetration-testing system can **promote PROBABLE findings to final CONFIRMED status under an explicit false-confirmation risk budget**, without treating repeated runs or synthetic challenge variants as independent publication-level evidence.

## What changed from Main-v1

1. **Strict structural baseline** — `FindingConfirmationService` is invoked with target/deployment continuity enforcement. The proposed method is no longer compared against a baseline that silently ignores `ProofBundle.target_continuity_verified`.
2. **Raw-state/evidence mutations** — challenge conditions modify timestamps, deployment identities, artifact bytes, provenance links, or actual evidence objects. They never directly edit a stored risk feature.
3. **Real provenance dependencies** — correlated observations share `provenance_root` and carry `derived_from` edges. Nominal tool count and independent evidence count can therefore diverge.
4. **Intermediate-risk states** — 6-hour unchanged evidence, 18-hour unknown state, and soft contradictory telemetry create non-binary risk regions instead of only easy 0.16/0.61 separation.
5. **Exact independent-group calibration** — the formal path uses one predeclared natural record per independence-eligible scenario group. Exact one-sided Clopper–Pearson upper bounds are used both to select and independently certify a promotion threshold.
6. **No repetition inflation** — repeated runs and controlled challenge transformations are excluded from formal certification.
7. **Portable artifacts** — records store dataset-relative paths only.
8. **Fail-closed auditing** — raw-state feature recomputation, artifact-state semantics, provenance mutations, continuity enforcement, calibration sanity, and formal group uniqueness are audited before analysis.

## Analysis layers

### A. Mechanism evaluation

Uses the internal controlled Docker benchmarks and challenge conditions. This layer compares:

- `validator_accept`
- strict `structural_gate`
- `fixed_naive` tool-count threshold
- `fixed_provenance` preregistered threshold

Challenge results are evidence about mechanisms and failure modes, **not independent samples for a statistical guarantee**.

### B. Formal exact risk calibration

Uses only rows for which the separate oracle marks:

```text
independence_eligible = true
certificate_eligible  = true
```

Exactly one natural record is frozen per independent scenario group. Groups are split before label-dependent analysis into tune / certify / test sets. For each target risk α, the threshold is selected only if the exact one-sided risk upper bound on the tune groups is ≤ α. The selected threshold is then independently checked on the certification groups before being applied to the held-out test groups.

Primary α is **0.10**. α=0.05 and 0.20 are sensitivity analyses.

## Internal challenge conditions

- `clean`
- `age_6h_unchanged`
- `age_18h_unknown_state`
- `post_remediation_72h`
- `continuity_break`
- `soft_conflict`
- `hard_conflict`
- `artifact_corruption`
- `correlated_duplication`

## Formal sample-size guardrail

Zero observed errors require roughly 30 independent confirmations for a one-sided 95% upper bound below 0.10. Because both tuning and independent certification need adequate selected samples, **80+ genuinely independent natural scenario groups is a practical lower planning target for the primary α=0.10 experiment**, and 100+ is preferable when abstention reduces the number of confirmed groups.

The internal benchmark cases are marked `independence_eligible=false`. Main-v2 will therefore refuse to produce a formal certificate from internal repeats alone.

## Run

```bash
python -m pip install -r research/risk_controlled_confirmation_experiment/requirements-experiment.txt

PYTHONPATH=. python \
  research/risk_controlled_confirmation_experiment/preflight.py \
  --require-live-deps

RFC_REPETITIONS=5 \
  research/risk_controlled_confirmation_experiment/run_all.sh
```

## Outputs

```text
work/live/
work/dataset/
  records_blinded.jsonl
  oracle.jsonl
  analysis_metadata.jsonl
  AUDIT_REPORT_V2.json
work/results/
  summary.json
  risk_coverage_curve.json
  formal_split_assignments.jsonl
  calibration_trace.json
  formal_certificates.json
  formal_input_summary.json
  predictions.jsonl
  RESULT_AUDIT_V2.json
```

## Important interpretation rule

A `CERTIFIED` status is meaningful only for the formal independent-group path. Internal challenge results may support statements about observed failure modes and mechanism behavior, but they do not establish a finite-sample risk guarantee.
