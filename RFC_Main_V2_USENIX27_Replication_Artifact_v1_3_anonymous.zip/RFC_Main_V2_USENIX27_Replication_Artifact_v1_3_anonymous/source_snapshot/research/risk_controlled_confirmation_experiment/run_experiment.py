#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from common import HERE, load_json, read_jsonl, write_jsonl, dump_json, sha256_file
from risk_statistics import exact_selective_certificate
from formal_readiness import evaluate as evaluate_formal_readiness

CONFIRMING = {'confirmed', 'probable'}


def decision(method: str, r: dict, threshold=None) -> str:
    vr = r['validator_result']
    structural = bool(r['structural_gate']['allowed'])
    if method == 'validator_accept':
        return 'confirm' if vr.get('status') in CONFIRMING else ('abstain' if vr.get('status') in {'needs_manual_review','manual_review','inconclusive'} else 'reject')
    if method == 'structural_gate':
        return 'confirm' if structural else 'abstain'
    if method == 'fixed_naive':
        return 'confirm' if structural and r['naive_risk_score'] <= threshold else 'abstain'
    if method in {'fixed_provenance', 'calibrated'}:
        return 'confirm' if structural and r['risk_score'] <= threshold else 'abstain'
    raise KeyError(method)


def known(o):
    return o.get('vulnerable') is not None


def stats(rows, oracle, decisions):
    conf = [r for r in rows if decisions[r['record_id']] == 'confirm' and known(oracle[r['record_id']])]
    false = [r for r in conf if oracle[r['record_id']]['vulnerable'] is False]
    ideal_conf = [r for r in rows if oracle[r['record_id']]['ideal_decision'] == 'confirm']
    correct_ideal = sum(decisions[r['record_id']] == 'confirm' for r in ideal_conf)
    unsafe = [r for r in rows if decisions[r['record_id']] == 'confirm' and oracle[r['record_id']]['ideal_decision'] != 'confirm']
    return {
        'known_confirmations': len(conf),
        'false_confirmations': len(false),
        'fcr': len(false) / len(conf) if conf else None,
        'ideal_confirm_recall': correct_ideal / len(ideal_conf) if ideal_conf else None,
        'unsafe_confirmations': len(unsafe),
        'coverage': sum(decisions[r['record_id']] == 'confirm' for r in rows) / len(rows) if rows else None,
    }


def _split_role(group_id: str, cfg: dict, predeclared: str | None = None) -> str:
    if predeclared in {'tune','certify','test'}:
        return predeclared
    seed = cfg['formal_split']['seed']
    x = int(hashlib.sha256(f'{seed}|{group_id}'.encode()).hexdigest()[:16], 16) / float(0xFFFFFFFFFFFFFFFF)
    t = cfg['formal_split']['tune_fraction']
    c = cfg['formal_split']['certify_fraction']
    return 'tune' if x < t else ('certify' if x < t + c else 'test')


def _formal_rows(records, oracle, cfg):
    # Exactly one natural/certificate row per group. No repeated run/challenge may
    # contribute more than one observation. If repeated natural records exist,
    # the lexicographically first record is frozen as the group's unit.
    by_group = {}
    for r in records:
        o = oracle[r['record_id']]
        if not o.get('certificate_eligible') or not o.get('independence_eligible'):
            continue
        if not known(o):
            continue
        gid = o['group_id']
        by_group.setdefault(gid, []).append(r)
    selected = []
    duplicates = {}
    for gid, rr in sorted(by_group.items()):
        rr = sorted(rr, key=lambda x: x['record_id'])
        selected.append(rr[0])
        if len(rr) > 1:
            duplicates[gid] = [x['record_id'] for x in rr[1:]]
    return selected, duplicates


def _threshold_candidates(rows):
    vals = sorted({float(r['risk_score']) for r in rows if r['structural_gate']['allowed']})
    return vals


def select_threshold_exact(rows, oracle, alpha, delta):
    best = None
    trace = []
    for t in _threshold_candidates(rows):
        d = {r['record_id']: decision('calibrated', r, t) for r in rows}
        s = stats(rows, oracle, d)
        cert = exact_selective_certificate(s['false_confirmations'], s['known_confirmations'], delta=delta)
        ok = s['known_confirmations'] > 0 and cert['upper'] <= alpha
        trace.append({'threshold': t, **s, 'risk_upper': cert['upper'], 'eligible': ok})
        if ok:
            key = (s['known_confirmations'], t)
            if best is None or key > best[0]:
                best = (key, t)
    return (best[1] if best else None), trace


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset-dir', default=str(HERE/'work/dataset'))
    ap.add_argument('--output-dir', default=str(HERE/'work/results'))
    args = ap.parse_args()
    d = Path(args.dataset_dir); out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    records_path=d/'records_blinded.jsonl'; oracle_path=d/'oracle.jsonl'; meta_path=d/'analysis_metadata.jsonl'; cfg_path=HERE/'config/experiment.json'
    records=read_jsonl(records_path); rec_by={r['record_id']:r for r in records}
    oracle={o['record_id']:o for o in read_jsonl(oracle_path)}
    meta={m['record_id']:m for m in read_jsonl(meta_path)}
    cfg=load_json(cfg_path)
    readiness=evaluate_formal_readiness(d,cfg_path)
    dump_json(out/'formal_readiness.json', readiness)
    dump_json(out/'input_fingerprint.json', {
        'records_sha256':sha256_file(records_path),'oracle_sha256':sha256_file(oracle_path),
        'metadata_sha256':sha256_file(meta_path),'experiment_config_sha256':sha256_file(cfg_path)
    })
    dump_json(out/'frozen_experiment.json', cfg)

    # A. Mechanism evaluation: fixed/preregistered baselines on every record.
    predictions=[]; summary={}
    methods=['validator_accept','structural_gate','fixed_naive','fixed_provenance']
    for method in methods:
        th=cfg['fixed_threshold'] if method.startswith('fixed_') else None
        dec={r['record_id']:decision(method,r,th) for r in records}
        for r in records:
            predictions.append({'record_id':r['record_id'],'analysis':'mechanism','method':method,'threshold':th,'decision':dec[r['record_id']]})
        s=stats(records,oracle,dec); cond={}
        for condition in sorted({meta[r['record_id']]['condition'] for r in records}):
            rr=[r for r in records if meta[r['record_id']]['condition']==condition]
            dd={r['record_id']:dec[r['record_id']] for r in rr}
            cond[condition]=stats(rr,oracle,dd)
        summary[f'{method}|fixed']={**s,'by_condition':cond}

    # B. Preregistered risk-coverage curve (descriptive, not calibrated).
    curve=[]
    for t in cfg['risk_threshold_grid']:
        dec={r['record_id']:decision('calibrated',r,t) for r in records}
        curve.append({'threshold':t,**stats(records,oracle,dec)})
    dump_json(out/'risk_coverage_curve.json', curve)

    # C. Formal exact calibration/certification on independent natural groups only.
    formal, duplicate_groups = _formal_rows(records, oracle, cfg)
    formal_assign=[]
    for r in formal:
        o=oracle[r['record_id']]
        role=_split_role(o['group_id'],cfg,o.get('split_role'))
        formal_assign.append({'record_id':r['record_id'],'group_id':o['group_id'],'role':role,'category':r['category'],'source_class':o.get('source_class')})
    write_jsonl(out/'formal_split_assignments.jsonl',formal_assign)
    role_by={x['record_id']:x['role'] for x in formal_assign}
    tune=[r for r in formal if role_by.get(r['record_id'])=='tune']
    cert_rows=[r for r in formal if role_by.get(r['record_id'])=='certify']
    test=[r for r in formal if role_by.get(r['record_id'])=='test']

    formal_results=[]
    formal_comparison=[]
    calibration_trace={}
    for alpha in cfg['alphas']:
        threshold, trace=select_threshold_exact(tune,oracle,alpha,cfg['confidence_delta']) if tune else (None,[])
        calibration_trace[str(alpha)]=trace
        if threshold is None:
            formal_results.append({'alpha':alpha,'threshold':None,'status':'NOT_RUN_NO_CALIBRATED_THRESHOLD','tune_groups':len(tune),'certify_groups':len(cert_rows),'test_groups':len(test)})
            continue
        cert_dec={r['record_id']:decision('calibrated',r,threshold) for r in cert_rows}
        cs=stats(cert_rows,oracle,cert_dec)
        ccert=exact_selective_certificate(cs['false_confirmations'],cs['known_confirmations'],delta=cfg['confidence_delta'])
        min_n=cfg['formal_min_confirmations'][str(alpha)]
        status='CERTIFIED' if ccert['upper']<=alpha and ccert['confirmations']>=min_n else ('INSUFFICIENT_INDEPENDENT_CONFIRMATIONS' if ccert['upper']<=alpha else 'NOT_CERTIFIED')
        test_dec={r['record_id']:decision('calibrated',r,threshold) for r in test}
        ts=stats(test,oracle,test_dec)
        fixed_dec={r['record_id']:decision('fixed_provenance',r,cfg['fixed_threshold']) for r in test}
        fixed_ts=stats(test,oracle,fixed_dec)
        differing=sum(test_dec[r['record_id']] != fixed_dec[r['record_id']] for r in test)
        formal_comparison.append({
            'alpha':alpha,'calibrated_threshold':threshold,'fixed_threshold':cfg['fixed_threshold'],
            'heldout_groups':len(test),'differing_decisions':differing,
            'fixed_provenance':fixed_ts,'calibrated':ts,
        })
        for r in test:
            predictions.append({'record_id':r['record_id'],'analysis':'formal_test','method':'calibrated','alpha':alpha,'threshold':threshold,'decision':test_dec[r['record_id']],'formal_certificate_status':status})
        formal_results.append({
            'alpha':alpha,'threshold':threshold,'status':status,
            'tune_groups':len(tune),'certify_groups':len(cert_rows),'test_groups':len(test),
            'certificate':cs,'certificate_exact':ccert,'required_independent_confirmations':min_n,
            'heldout_test':ts,
        })

    dump_json(out/'formal_certificates.json',formal_results)
    dump_json(out/'formal_method_comparison.json',formal_comparison)
    dump_json(out/'calibration_trace.json',calibration_trace)
    dump_json(out/'formal_input_summary.json',{
        'formal_eligible_groups':len(formal),'tune_groups':len(tune),'certify_groups':len(cert_rows),'test_groups':len(test),
        'duplicate_group_records_discarded':duplicate_groups,
        'guardrail':'one record per independent group; challenge/repetition records excluded',
        'formal_readiness_status':readiness.get('status')
    })
    write_jsonl(out/'predictions.jsonl',predictions)
    dump_json(out/'summary.json',summary)
    print(json.dumps({'mechanism':summary,'formal':formal_results},indent=2))

if __name__=='__main__':
    main()
