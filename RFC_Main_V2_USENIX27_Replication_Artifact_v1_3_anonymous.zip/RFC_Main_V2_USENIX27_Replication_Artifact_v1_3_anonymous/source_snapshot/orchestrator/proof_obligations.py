"""
Per-vulnerability proof obligations (corrections spec P0-D §6.3).

Each vulnerability type declares the minimum obligations that must be present
in a ProofBundle before a finding may be CONFIRMED. Obligations are opaque
string tokens; the Worker/Validator that assembles the bundle is responsible
for adding the tokens it has genuinely satisfied.
"""
from __future__ import annotations

from typing import Dict, List

# Canonical obligation token sets per vulnerability type.
PROOF_OBLIGATIONS: Dict[str, List[str]] = {
    "sql_injection": [
        "control_request_compared",       # payload vs control request
        "differential_response_or_error", # response diff / DB error / time delay
        "target_endpoint_match",          # evidence target == finding target
        "reproduction_request",           # repeatable request captured
    ],
    "idor": [
        "distinct_identities_or_objects", # different principal or object id
        "unauthorized_resource_access",   # unauthorized identity got resource
        "authorized_control_request",     # legitimate control request exists
    ],
    "ssrf": [
        "server_side_outbound_interaction",  # server made outbound request
        "callback_or_internal_response",     # callback fired / internal endpoint reacted
        "not_client_side_request",           # proven not a client-side request
    ],
    "auth_bypass": [
        "pre_post_auth_comparison",       # authenticated vs unauthenticated
        "protected_resource_access",      # protected resource actually reached
        "no_valid_session_used",          # succeeded without valid session/token
    ],
    "privilege_escalation": [
        "valid_foothold",                 # a real foothold session exists
        "escalation_action_executed",     # escalation action actually ran
        "effective_identity_changed",     # euid/identity changed
        "session_continuity",             # same/linkable session chain
    ],
    "cve_applicability": [
        "product_and_version_identified", # product + version known
        "cve_affected_range_match",        # version within CVE affected range
        "environment_or_mitigation_check", # deployment/mitigation considered
        # NB: version string alone must NOT confirm — hence the extra checks.
    ],
}


def obligations_for(vulnerability_type: str) -> List[str]:
    """Return required obligation tokens for a vulnerability type (or [])."""
    return list(PROOF_OBLIGATIONS.get(vulnerability_type, []))


def missing_obligations(vulnerability_type: str, satisfied: List[str]) -> List[str]:
    """Return required obligations not present in `satisfied`."""
    required = obligations_for(vulnerability_type)
    sat = set(satisfied or [])
    return [o for o in required if o not in sat]
