"""
orchestrator/finding_lifecycle.py
=====================================
보고서에서 finding을 검증 수준별로 분류하고, 재검증/조치확인까지
관리한다 (implementation_plan.md §16).

"finding"으로 취급하는 evidence type은 AttackSurfaceMapper가 이미
high_value_targets로 분류하는 것과 대체로 같다(취약점/자격증명/노출된
비밀 등) -- 여기서 다시 그 목록을 재정의하지 않고 그대로 가져다 쓴다.

stable_key: finding_id는 매번 새로 생성되는 랜덤 ID라서 여러 스캔
회차를 비교(ContinuousValidationMode/report_diff)할 때 같은 finding을
추적할 수 없다. stable_key는 target+type+(cve 또는 port/service/
template_id)로 결정론적으로 계산해서, 같은 실제 이슈면 재실행해도
같은 키가 나오게 한다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, List, Optional, Set

from orchestrator.evidence_quality import EvidenceQualityScorer
from orchestrator.schemas import ConflictObject, Evidence, EvidenceType, _short_id

if TYPE_CHECKING:
    from orchestrator.findings import FindingCandidate, ValidatorResult

_FINDING_EVIDENCE_TYPES = {
    EvidenceType.VULNERABILITY_CANDIDATE,
    EvidenceType.CVE_CANDIDATE,
    EvidenceType.EXPLOIT_EVIDENCE,
    EvidenceType.KEV_SIGNAL,
    EvidenceType.DEFAULT_CREDENTIAL_SIGNAL,
    EvidenceType.SECRET_EXPOSURE_SIGNAL,
    EvidenceType.MISCONFIGURATION_SIGNAL,
    EvidenceType.AD_EXPOSURE_SIGNAL,
}

_CROSS_TOOL_SUPPORT_THRESHOLD = 0.65
_LOW_RELIABILITY_THRESHOLD = 0.5


class FindingStatus(str, Enum):
    INFO = "informational"
    POSSIBLE = "possible"
    PROBABLE = "probable"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    NEEDS_MANUAL_REVIEW = "needs_manual_review"
    RESOLVED = "resolved"
    REOPENED = "reopened"


def _compute_stable_key(evidence: Evidence) -> str:
    v = evidence.value
    parts = [evidence.target, evidence.type.value]
    if v.get("cve"):
        parts.append(str(v["cve"]))
    elif v.get("cves"):
        parts.append(",".join(sorted(str(c) for c in v["cves"])))
    elif v.get("cve_id"):
        parts.append(str(v["cve_id"]))
    else:
        parts.append(str(v.get("port", "")))
        parts.append(str(v.get("service", "")))
        parts.append(str(v.get("template_id", "")))
    return "|".join(parts)


@dataclass
class Finding:
    finding_id: str
    stable_key: str
    title: str
    status: FindingStatus
    severity: str
    target: str
    evidence_ids: List[str] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    first_seen: str = ""
    last_seen: str = ""

    def to_dict(self) -> dict:
        return {
            "finding_id": self.finding_id, "stable_key": self.stable_key, "title": self.title,
            "status": self.status.value, "severity": self.severity, "target": self.target,
            "evidence_ids": self.evidence_ids, "reasons": self.reasons,
            "first_seen": self.first_seen, "last_seen": self.last_seen,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Finding":
        return cls(
            finding_id=d["finding_id"], stable_key=d["stable_key"], title=d["title"],
            status=FindingStatus(d["status"]), severity=d["severity"], target=d["target"],
            evidence_ids=d.get("evidence_ids", []), reasons=d.get("reasons", []),
            first_seen=d.get("first_seen", ""), last_seen=d.get("last_seen", ""),
        )


class FindingLifecycleManager:
    def __init__(self) -> None:
        self._scorer = EvidenceQualityScorer()

    def build_findings(
        self,
        all_evidences: List[Evidence],
        conflicts: Optional[List[ConflictObject]] = None,
        validated_evidence_ids: Optional[Set[str]] = None,
    ) -> List[Finding]:
        return [
            self.classify(ev, all_evidences, conflicts, validated_evidence_ids)
            for ev in all_evidences if ev.type in _FINDING_EVIDENCE_TYPES
        ]

    def classify(
        self,
        evidence: Evidence,
        all_evidences: List[Evidence],
        conflicts: Optional[List[ConflictObject]] = None,
        validated_evidence_ids: Optional[Set[str]] = None,
    ) -> Finding:
        conflicts = conflicts or []
        validated_evidence_ids = validated_evidence_ids or set()
        quality = self._scorer.score(evidence, all_evidences, conflicts)
        reasons: List[str] = []

        conflicting = [c for c in conflicts if evidence.id in c.evidence_ids]
        mitigation_conflict = any(c.conflict_type.value == "mitigation_conflict" for c in conflicting)
        human_review_conflict = any(c.requires_human_review for c in conflicting)

        # 상태 전환 규칙 (§16 그대로): safe validation 확인 > 미해결 mitigation
        # 충돌 > cross-tool 확인 > 단일 저신뢰 소스 > 단일 신뢰 소스.
        if evidence.id in validated_evidence_ids:
            status = FindingStatus.PROBABLE
            reasons.append("validation evidence present; final confirmation requires ProofBundle gate")
        elif mitigation_conflict or human_review_conflict:
            status = FindingStatus.NEEDS_MANUAL_REVIEW
            reasons.append("conflicting mitigation evidence requires manual review")
        elif quality.cross_tool_support >= _CROSS_TOOL_SUPPORT_THRESHOLD:
            status = FindingStatus.PROBABLE
            reasons.append("cross-tool corroboration; final confirmation requires ProofBundle gate")
        elif quality.source_reliability < _LOW_RELIABILITY_THRESHOLD:
            status = FindingStatus.POSSIBLE
            reasons.append("single low-reliability (LLM-only or weak) source")
        else:
            status = FindingStatus.PROBABLE
            reasons.append("single reliable tool with specific evidence")

        severity = str(evidence.value.get("severity", "MEDIUM")).upper()
        title = str(
            evidence.value.get("name") or evidence.value.get("description")
            or evidence.value.get("template_id") or evidence.type.value
        )

        return Finding(
            finding_id=_short_id("F"), stable_key=_compute_stable_key(evidence),
            title=title, status=status, severity=severity, target=evidence.target,
            evidence_ids=[evidence.id], reasons=reasons,
            first_seen=evidence.timestamp, last_seen=evidence.timestamp,
        )

    # ── 상태 전환 (§16 "재검증/조치확인") ──────────────────────────────────────

    def transition_on_regression(self, previous: Finding, still_present: bool) -> Finding:
        if previous.status == FindingStatus.RESOLVED and still_present:
            previous.status = FindingStatus.REOPENED
            previous.reasons.append("issue reappeared after being marked resolved")
        return previous

    def transition_on_remediation_verified(self, previous: Finding) -> Finding:
        previous.status = FindingStatus.RESOLVED
        previous.reasons.append("remediation verification succeeded")
        return previous

    def mark_false_positive(self, previous: Finding, reason: str) -> Finding:
        previous.status = FindingStatus.FALSE_POSITIVE
        previous.reasons.append(reason)
        return previous

    # ── xbow_scheme_addendum.md §4/§5 연동 ──────────────────────────────────
    # Coordinator/WorkerAgent/ValidatorLayer(orchestrator/findings.py,
    # orchestrator/validators/)가 만드는 FindingCandidate/ValidatorResult를
    # 여기서 기존 Finding/FindingStatus로 합류시킨다 -- Finding 모델을 두 개로
    # 쪼개지 않기 위한 결정(project_pentest_ai_implementation_plan.md 참고).

    def classify_from_validator_result(
        self, candidate: "FindingCandidate", result: "ValidatorResult",
    ) -> Finding:
        """ValidatorResult.status 문자열은 FindingStatus의 value와 정확히
        같다(confirmed/probable/needs_manual_review/false_positive) --
        addendum이 그렇게 이름 붙였고, 여기서 그 값을 그대로 재사용한다."""
        raw_status = FindingStatus(result.status)
        # Legacy validator results may not bypass the central ProofBundle gate.
        status = FindingStatus.PROBABLE if raw_status == FindingStatus.CONFIRMED else raw_status
        reasons = [f"validator result: {result.status} (risk={result.risk})"]
        if raw_status == FindingStatus.CONFIRMED:
            reasons.append("awaiting central ProofBundle confirmation gate")
        if result.limitations:
            reasons.append(f"limitations: {'; '.join(result.limitations)}")

        return Finding(
            finding_id=_short_id("F"),
            stable_key=_compute_stable_key_from_candidate(candidate),
            title=candidate.title, status=status,
            severity=_impact_to_severity(candidate.suspected_impact),
            target=candidate.target_node_id,
            evidence_ids=list(dict.fromkeys(candidate.evidence_ids + result.evidence_ids)),
            reasons=reasons,
            first_seen=candidate.created_at, last_seen=result.created_at,
        )


def _compute_stable_key_from_candidate(candidate: "FindingCandidate") -> str:
    """FindingCandidate에는 evidence의 cve/port/service 같은 필드가 없으므로,
    target_node_id(그래프 노드 id, 그 자체로 이미 host/port/url을 담고 있음)
    + category로 결정론적 키를 만든다."""
    return "|".join(["candidate", candidate.target_node_id, candidate.category])


def _impact_to_severity(suspected_impact: str) -> str:
    impact = (suspected_impact or "").upper()
    for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        if level in impact:
            return level
    return "MEDIUM"
