"""
ProofBundle (corrections spec P0-D §6.1).

A ProofBundle is the evidence package a finding must carry before it can be
CONFIRMED. It references (by id) the direct/derived evidence, validator
results, and raw artifacts that back the claim, plus the continuity/integrity
flags the confirmation gate checks.
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field

from orchestrator.schemas import utc_now


class ProofBundle(BaseModel):
    finding_id: str
    target_id: str
    session_id: Optional[str] = None

    claim: str
    vulnerability_type: str

    preconditions: List[str] = Field(default_factory=list)
    direct_evidence_refs: List[str] = Field(default_factory=list)
    derived_evidence_refs: List[str] = Field(default_factory=list)
    validator_result_refs: List[str] = Field(default_factory=list)
    raw_artifact_refs: List[str] = Field(default_factory=list)

    contradictions: List[str] = Field(default_factory=list)
    proof_obligations: List[str] = Field(default_factory=list)

    target_continuity_verified: bool = False
    session_continuity_verified: bool = False
    artifact_integrity_verified: bool = False

    created_at: str = Field(default_factory=utc_now)
