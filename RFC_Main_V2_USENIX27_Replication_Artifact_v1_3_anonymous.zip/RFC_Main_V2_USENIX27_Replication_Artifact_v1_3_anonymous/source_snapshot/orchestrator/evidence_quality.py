"""
orchestrator/evidence_quality.py
====================================
LLM 판단에 들어가는 evidence의 질을 수치화한다 (implementation_plan.md §11).

AttackSurfaceMapper._score()/CVEApplicabilityEngine.assess()와 같은 패턴 --
Evidence 자체에 캐시하지 않고 호출 시점의 all_evidences/conflicts를
기준으로 매번 새로 계산하는 순수 함수다. cross_tool_support/conflict_penalty
같은 항목이 "이 evidence 하나"가 아니라 "지금까지 쌓인 전체 evidence"에
의존하기 때문에, Evidence.make() 시점에 고정해서 저장하면 나중에 도착하는
교차검증/충돌 evidence를 반영할 수 없다.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional

from orchestrator.schemas import ConflictObject, ContextScores, Evidence, EvidenceType

# source_tool별 기본 신뢰도. "LLM-only claim -> low source_reliability" 원칙 --
# 실제 recon 도구 실행 결과는 높게, LLM 자체 판단/주입은 낮게 잡는다.
_TOOL_RELIABILITY = {
    "context_injection": 0.30,
    "claude_reasoner": 0.35,
    "nmap": 0.85, "scan_network": 0.85,
    "httpx": 0.80, "scan_web": 0.80,
    "sslscan": 0.85, "ssl_tls_audit": 0.85,
    "whatweb": 0.75, "wafw00f": 0.75,
    "nuclei": 0.85,
    "auth_surface_analyze": 0.75,
    "cve_applicability_check": 0.60,  # 판단 결과이지 직접 관측이 아님
    "binary_triage": 0.90,
    "remote_binary_collect": 0.98,
}
_DEFAULT_TOOL_RELIABILITY = 0.55

# evidence type별 재현 가능성 -- 재스캔해도 같은 답이 나오는 사실(포트/버전/
# TLS 설정)은 높게, 휴리스틱/판단성 결과는 낮게.
_REPRODUCIBILITY_BY_TYPE = {
    EvidenceType.OPEN_PORT: 0.90,
    EvidenceType.SERVICE_DETECTED: 0.80,
    EvidenceType.SERVICE_VERSION: 0.75,
    EvidenceType.TLS_CONFIG: 0.85,
    EvidenceType.TECHNOLOGY_DETECTED: 0.75,
    EvidenceType.VULNERABILITY_CANDIDATE: 0.45,
    EvidenceType.CVE_CANDIDATE: 0.40,
    EvidenceType.CVE_APPLICABILITY_ASSESSMENT: 0.50,
    EvidenceType.CONTEXT_CLAIM: 0.20,
    EvidenceType.AUTH_SURFACE: 0.70,
    EvidenceType.ADMIN_SURFACE: 0.70,
    EvidenceType.BINARY_METADATA: 0.95,
    EvidenceType.BINARY_HARDENING: 0.85,
    EvidenceType.BINARY_INDICATOR: 0.75,
    EvidenceType.BINARY_ANALYSIS_DIAGNOSTIC: 0.90,
    EvidenceType.ARTIFACT_ACQUISITION: 0.98,
}
_DEFAULT_REPRODUCIBILITY = 0.55

_EXPLOITABILITY_TYPES = {
    EvidenceType.VULNERABILITY_CANDIDATE, EvidenceType.CVE_CANDIDATE,
    EvidenceType.EXPLOIT_EVIDENCE, EvidenceType.KEV_SIGNAL,
    EvidenceType.DEFAULT_CREDENTIAL_SIGNAL, EvidenceType.SECRET_EXPOSURE_SIGNAL,
}

_FRESHNESS_FULL_HOURS = 1.0
_FRESHNESS_HALF_LIFE_HOURS = 24.0

_SPECIFIC_VALUE_FIELDS = ("version", "cve", "cves", "cve_id", "port", "template_id")


@dataclass
class EvidenceQuality:
    evidence_id: str
    source_reliability: float
    freshness: float
    reproducibility: float
    cross_tool_support: float
    specificity: float
    exploitability_relevance: float
    conflict_penalty: float
    final_score: float

    def to_dict(self) -> dict:
        return {
            "evidence_id": self.evidence_id,
            "source_reliability": round(self.source_reliability, 3),
            "freshness": round(self.freshness, 3),
            "reproducibility": round(self.reproducibility, 3),
            "cross_tool_support": round(self.cross_tool_support, 3),
            "specificity": round(self.specificity, 3),
            "exploitability_relevance": round(self.exploitability_relevance, 3),
            "conflict_penalty": round(self.conflict_penalty, 3),
            "final_score": round(self.final_score, 3),
        }


class EvidenceQualityScorer:
    def score(
        self,
        evidence: Evidence,
        all_evidences: List[Evidence],
        conflicts: Optional[List[ConflictObject]] = None,
    ) -> EvidenceQuality:
        conflicts = conflicts or []

        source_reliability = _TOOL_RELIABILITY.get(evidence.source_tool, _DEFAULT_TOOL_RELIABILITY)
        freshness = self._freshness(evidence)
        reproducibility = _REPRODUCIBILITY_BY_TYPE.get(evidence.type, _DEFAULT_REPRODUCIBILITY)
        cross_tool_support = self._cross_tool_support(evidence, all_evidences)
        specificity = self._specificity(evidence)
        exploitability_relevance = 0.75 if evidence.type in _EXPLOITABILITY_TYPES else 0.25
        conflict_penalty = self._conflict_penalty(evidence, conflicts)

        final_score = max(0.0, min(1.0, (
            0.25 * source_reliability
            + 0.15 * freshness
            + 0.10 * reproducibility
            + 0.25 * cross_tool_support
            + 0.10 * specificity
            + 0.15 * exploitability_relevance
            - conflict_penalty
        )))

        return EvidenceQuality(
            evidence_id=evidence.id, source_reliability=source_reliability,
            freshness=freshness, reproducibility=reproducibility,
            cross_tool_support=cross_tool_support, specificity=specificity,
            exploitability_relevance=exploitability_relevance,
            conflict_penalty=conflict_penalty, final_score=final_score,
        )

    # ── 내부 ──────────────────────────────────────────────────────────────────

    def _freshness(self, evidence: Evidence) -> float:
        try:
            ts = datetime.strptime(evidence.timestamp, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except Exception:
            return 0.5  # 파싱 불가 -- 판단 불가로 중립값
        age_hours = (datetime.now(timezone.utc) - ts).total_seconds() / 3600.0
        if age_hours <= _FRESHNESS_FULL_HOURS:
            return 1.0
        return max(0.1, 0.5 ** (age_hours / _FRESHNESS_HALF_LIFE_HOURS))

    def _cross_tool_support(self, evidence: Evidence, all_evidences: List[Evidence]) -> float:
        port = evidence.value.get("port")
        host = evidence.host or evidence.target
        related_tools = {evidence.source_tool}
        for other in all_evidences:
            if other.id == evidence.id:
                continue
            if (other.host or other.target) != host:
                continue
            if port is not None and other.value.get("port") == port:
                related_tools.add(other.source_tool)
            elif port is None and other.type == evidence.type:
                related_tools.add(other.source_tool)

        n = len(related_tools)
        if n >= 3:
            return 0.90
        if n == 2:
            return 0.65
        return 0.30

    def _specificity(self, evidence: Evidence) -> float:
        hits = sum(1 for f in _SPECIFIC_VALUE_FIELDS if evidence.value.get(f))
        if hits >= 2:
            return 0.85
        if hits == 1:
            return 0.55
        return 0.30

    def _conflict_penalty(self, evidence: Evidence, conflicts: List[ConflictObject]) -> float:
        for c in conflicts:
            if evidence.id in c.evidence_ids:
                return 0.35 if c.requires_human_review else 0.20
        return 0.0


def compute_context_scores(
    evidences: List[Evidence],
    conflicts: Optional[List[ConflictObject]] = None,
) -> ContextScores:
    """
    AlphaEngine.compute()의 context_quality 파라미터를 실제로 채워주는
    헬퍼 -- PentestOrchestrator.run()이 지금까지 이 파라미터를 넘긴 적이
    없어서 항상 None으로 동작했다 (§0 원칙에 맞게 EvidenceQualityScore
    기반으로 실제 값을 계산해 연결한다).
    """
    scorer = EvidenceQualityScorer()
    conflicts = conflicts or []

    def _avg_quality(evs: List[Evidence]) -> float:
        if not evs:
            return 0.0
        scores = [scorer.score(e, evidences, conflicts).final_score for e in evs]
        return sum(scores) / len(scores)

    exposure_evs = [e for e in evidences if e.type == EvidenceType.EXPOSURE_SIGNAL]
    service_evs = [e for e in evidences if e.type in (
        EvidenceType.OPEN_PORT, EvidenceType.SERVICE_DETECTED, EvidenceType.SERVICE_VERSION,
    )]
    tech_evs = [e for e in evidences if e.type == EvidenceType.TECHNOLOGY_DETECTED]

    return ContextScores(
        exposure_confidence=_avg_quality(exposure_evs),
        service_confidence=_avg_quality(service_evs),
        technology_confidence=_avg_quality(tech_evs),
    )
