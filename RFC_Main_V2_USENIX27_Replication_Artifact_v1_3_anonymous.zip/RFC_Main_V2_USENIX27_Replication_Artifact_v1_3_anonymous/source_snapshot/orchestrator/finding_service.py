"""
Finding confirmation gate (corrections spec P0-D §6.2).

Finding status is NEVER assigned directly. Callers use
`FindingConfirmationService.confirm(finding_id, proof_bundle)`, which runs the
full 10-point gate. Any failure downgrades the finding to MANUAL_REVIEW (when
a human could still adjudicate) or UNSUPPORTED (when the claim is contradicted
or unbacked) — never CONFIRMED.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional

from orchestrator.proof_bundle import ProofBundle
from orchestrator.proof_obligations import missing_obligations
from orchestrator.schemas import ExecutionStatus, _short_id, utc_now


class ConfirmationStatus(str, Enum):
    CANDIDATE = "candidate"
    PENDING_VALIDATION = "pending_validation"
    PROBABLE = "probable"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    INCONCLUSIVE = "inconclusive"
    MANUAL_REVIEW = "manual_review"
    UNSUPPORTED = "unsupported"


@dataclass
class Finding:
    finding_id: str
    target_id: str
    title: str
    vulnerability_type: str
    status: ConfirmationStatus = ConfirmationStatus.CANDIDATE
    severity: str = "unknown"
    proof_bundle: Optional[ProofBundle] = None
    gate_failures: List[str] = field(default_factory=list)
    session_id: Optional[str] = None


@dataclass
class ConfirmationResult:
    allowed: bool
    resulting_status: ConfirmationStatus
    failures: List[str]


# Validator statuses that count as "pass" for confirmation.
_PASSING_VALIDATOR_STATUSES = {"confirmed", "pass", "validated"}
# Contradiction/refutation → hard UNSUPPORTED, not manual review.
_UNSUPPORTED_ON = {"contradiction", "target_mismatch"}


class FindingConfirmationService:
    """Runs the confirmation gate and owns finding status transitions.

    Dependency lookups are injected so the gate is testable in isolation:
      - evidence_status_of(evidence_id) -> ExecutionStatus | None
      - validator_status_of(ref) -> str | None
      - verify_artifacts(refs) -> bool
      - require_session_continuity: whether session continuity is mandatory
    """

    def __init__(
        self,
        *,
        evidence_status_of: Callable[[str], Optional[ExecutionStatus]],
        validator_status_of: Callable[[str], Optional[str]],
        verify_artifacts: Callable[[List[str]], bool],
    ):
        self._evidence_status_of = evidence_status_of
        self._validator_status_of = validator_status_of
        self._verify_artifacts = verify_artifacts
        self._findings: Dict[str, Finding] = {}

    def register(self, finding: Finding) -> None:
        self._findings[finding.finding_id] = finding

    def get(self, finding_id: str) -> Optional[Finding]:
        return self._findings.get(finding_id)

    # ── The gate ───────────────────────────────────────────────────────────
    def confirm(
        self,
        finding_id: str,
        proof_bundle: Optional[ProofBundle],
        *,
        require_session_continuity: bool = False,
        require_target_continuity: bool = False,
    ) -> ConfirmationResult:
        finding = self._findings.get(finding_id)
        if finding is None:
            raise KeyError(f"unknown finding: {finding_id}")

        failures: List[str] = []
        hard_unsupported = False

        # 1. ProofBundle must exist.
        if proof_bundle is None:
            failures.append("no_proof_bundle")
            return self._finalize(finding, None, failures, hard_unsupported=True)

        # 6. Target ID must match (checked early; mismatch is hard-unsupported).
        if proof_bundle.target_id != finding.target_id:
            failures.append("target_mismatch")
            hard_unsupported = True

        # 2. Required proof obligations satisfied.
        missing = missing_obligations(
            proof_bundle.vulnerability_type, proof_bundle.proof_obligations
        )
        if missing:
            failures.append(f"missing_obligations:{','.join(missing)}")

        # 3. At least one direct evidence.
        if not proof_bundle.direct_evidence_refs:
            failures.append("no_direct_evidence")

        # 4. All referenced evidence must be from SUCCEEDED executions.
        all_ev = list(proof_bundle.direct_evidence_refs) + list(
            proof_bundle.derived_evidence_refs
        )
        for ev_id in all_ev:
            status = self._evidence_status_of(ev_id)
            if status != ExecutionStatus.SUCCEEDED:
                failures.append(f"evidence_not_succeeded:{ev_id}")

        # 5. Validator result must pass (or allowed equivalent).
        if not proof_bundle.validator_result_refs:
            failures.append("no_validator_result")
        else:
            passed = any(
                (self._validator_status_of(ref) or "").lower()
                in _PASSING_VALIDATOR_STATUSES
                for ref in proof_bundle.validator_result_refs
            )
            if not passed:
                failures.append("validator_did_not_pass")

        # 7a. Target/deployment continuity when explicitly required.
        # ProofBundle has carried this field since the original gate design; v2
        # makes the intended semantics executable for strict confirmation studies.
        if require_target_continuity and not proof_bundle.target_continuity_verified:
            failures.append("target_continuity_unverified")

        # 7b. Session continuity when required.
        if require_session_continuity and not proof_bundle.session_continuity_verified:
            failures.append("session_continuity_unverified")

        # 8. Raw artifact reference must exist.
        if not proof_bundle.raw_artifact_refs:
            failures.append("no_raw_artifact")

        # 9. Artifact hash must verify.
        elif not self._verify_artifacts(proof_bundle.raw_artifact_refs):
            failures.append("artifact_integrity_failed")

        # 10. No unresolved contradictions.
        if proof_bundle.contradictions:
            failures.append("unresolved_contradiction")
            hard_unsupported = True

        return self._finalize(finding, proof_bundle, failures, hard_unsupported)

    def _finalize(
        self,
        finding: Finding,
        proof_bundle: Optional[ProofBundle],
        failures: List[str],
        hard_unsupported: bool,
    ) -> ConfirmationResult:
        finding.proof_bundle = proof_bundle
        finding.gate_failures = failures
        if not failures:
            finding.status = ConfirmationStatus.CONFIRMED
            return ConfirmationResult(True, ConfirmationStatus.CONFIRMED, [])
        # Failures: choose UNSUPPORTED for contradiction/mismatch, else MANUAL_REVIEW.
        status = (
            ConfirmationStatus.UNSUPPORTED
            if hard_unsupported
            else ConfirmationStatus.MANUAL_REVIEW
        )
        finding.status = status
        return ConfirmationResult(False, status, failures)


def new_finding(
    *,
    target_id: str,
    title: str,
    vulnerability_type: str,
    severity: str = "unknown",
    session_id: Optional[str] = None,
) -> Finding:
    return Finding(
        finding_id=_short_id("F"),
        target_id=target_id,
        title=title,
        vulnerability_type=vulnerability_type,
        severity=severity,
        session_id=session_id,
    )
