"""
orchestrator/schemas.py
=======================
핵심 데이터 모델 — Evidence, TargetState, Conflict, AlphaDecision, PolicyGateDecision 등.
모든 다른 orchestrator 모듈이 이 파일만 import한다.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


# ── Enums ────────────────────────────────────────────────────────────────────

class EvidenceType(str, Enum):
    OPEN_PORT              = "open_port"
    SERVICE_DETECTED       = "service_detected"
    SERVICE_VERSION        = "service_version"
    HTTP_STATUS            = "http_status"
    TLS_CONFIG             = "tls_config"
    WAF_DETECTED           = "waf_detected"
    TECHNOLOGY_DETECTED    = "technology_detected"
    VULNERABILITY_CANDIDATE= "vulnerability_candidate"
    CVE_CANDIDATE          = "cve_candidate"
    OS_GUESS               = "os_guess"
    EXPOSURE_SIGNAL        = "exposure_signal"
    MITIGATION_SIGNAL      = "mitigation_signal"
    AUTH_REQUIRED          = "auth_required"
    CONTEXT_CLAIM          = "context_claim"
    EXPLOIT_EVIDENCE       = "exploit_evidence"
    KEV_SIGNAL             = "kev_signal"
    CONFLICT               = "conflict"
    UNSUPPORTED_CLAIM      = "unsupported_claim"
    TOOL_ERROR             = "tool_error"
    SCOPE_VIOLATION        = "scope_violation"
    SANITIZATION_SIGNAL    = "sanitization_signal"
    # Phase 2 (AttackSurfaceMapper / nuclei_safe / AuthSurfaceAnalyzer) --
    # TECHNOLOGY_DETECTED/SERVICE_DETECTED/SERVICE_VERSION/TLS_CONFIG/
    # VULNERABILITY_CANDIDATE/EXPOSURE_SIGNAL 등 기존 타입으로 이미 표현
    # 가능한 것들(TECH_FINGERPRINT, SERVICE_FINGERPRINT, TLS_WEAKNESS 등)은
    # implementation_plan.md의 예시 이름 그대로 추가하지 않고 기존 타입을
    # 재사용한다 -- 아래는 기존 타입으로 표현할 수 없는 것만 추가.
    NUCLEI_MATCH           = "nuclei_match"
    MISCONFIGURATION_SIGNAL= "misconfiguration_signal"
    SECRET_EXPOSURE_SIGNAL = "secret_exposure_signal"
    AUTH_SURFACE           = "auth_surface"
    ADMIN_SURFACE          = "admin_surface"
    WEB_ENDPOINT           = "web_endpoint"
    DEFAULT_CREDENTIAL_SIGNAL = "default_credential_signal"
    CVE_APPLICABILITY_ASSESSMENT = "cve_applicability_assessment"
    AD_EXPOSURE_SIGNAL     = "ad_exposure_signal"
    # personal_use_improvements.md -- 기존 타입으로 표현 안 되는 것만 추가
    # (endpoint/admin/debug 노출은 WEB_ENDPOINT를 kind 태그로 재사용).
    PARAMETER_CANDIDATE    = "parameter_candidate"
    GRAPHQL_INTROSPECTION_SIGNAL = "graphql_introspection_signal"
    ACCESS_CONTROL_SIGNAL  = "access_control_signal"
    BROWSER_OBSERVATION    = "browser_observation"
    LOGIN_SURFACE          = "login_surface"
    FILE_EXPOSURE_SIGNAL   = "file_exposure_signal"
    CORS_SIGNAL            = "cors_signal"
    # Local reverse-engineering artifacts. These describe direct static
    # observations and are intentionally separate from vulnerability findings.
    BINARY_METADATA        = "binary_metadata"
    BINARY_HARDENING       = "binary_hardening"
    BINARY_INDICATOR       = "binary_indicator"
    BINARY_ANALYSIS_DIAGNOSTIC = "binary_analysis_diagnostic"
    ARTIFACT_ACQUISITION   = "artifact_acquisition"


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"
    UNKNOWN  = "UNKNOWN"


class ActionClass(str, Enum):
    PASSIVE                = "passive"
    NON_INVASIVE_VERIFY    = "non_invasive_verify"
    LIMITED_ACTIVE_SCAN    = "limited_active_scan"
    INTRUSIVE_VALIDATION   = "intrusive_validation"
    EXPLOIT_LIKE_VALIDATION= "exploit_like_validation"
    POST_EXPLOITATION      = "post_exploitation"


class ConflictType(str, Enum):
    SERVICE_IDENTITY_CONFLICT = "service_identity_conflict"
    EXPOSURE_CONFLICT         = "exposure_conflict"
    VERSION_CONFLICT          = "version_conflict"
    MITIGATION_CONFLICT       = "mitigation_conflict"
    VULNERABILITY_CONFLICT    = "vulnerability_conflict"


# ── P0 Execution & Evidence Integrity ────────────────────────────────────────

class ExecutionStatus(str, Enum):
    """
    P0 requirement: Explicit execution status classification.
    Prevents blocked/failed results from generating positive evidence.
    """
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    BLOCKED = "blocked"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"
    UNAVAILABLE = "unavailable"
    PARSE_ERROR = "parse_error"
    EMPTY_OUTPUT = "empty_output"


class ObservationKind(str, Enum):
    """
    P0 requirement: Separate LLM claims from observations.
    """
    DIRECT = "direct"              # Raw HTTP response, command output
    DERIVED = "derived"            # Parsed from raw output
    MODEL_CLAIM = "model_claim"    # LLM interpretation
    SYNTHETIC = "synthetic"        # Simulation data


class UnsupportedReasonCode(str, Enum):
    """P0: Detailed tracking of unsupported claims."""
    BLOCKED_BUT_CLAIMED_SUCCESS = "blocked_but_claimed_success"
    FAILED_BUT_CLAIMED_SUCCESS = "failed_but_claimed_success"
    EMPTY_OUTPUT_BUT_CLAIMED_SUCCESS = "empty_output_but_claimed_success"
    TIMED_OUT_BUT_CLAIMED_SUCCESS = "timed_out_but_claimed_success"
    CANCELLED_BUT_CLAIMED_SUCCESS = "cancelled_but_claimed_success"
    UNAVAILABLE_BUT_CLAIMED_SUCCESS = "unavailable_but_claimed_success"
    PARSE_ERROR_BUT_CLAIMED_SUCCESS = "parse_error_but_claimed_success"
    TARGET_MISMATCH = "target_mismatch"
    MISSING_PROOF = "missing_proof"
    STALE_SESSION = "stale_session"


# ── ID generators / timestamp ────────────────────────────────────────────────

def _short_id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:6].upper()}"


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── Evidence ─────────────────────────────────────────────────────────────────

@dataclass
class Evidence:
    """
    단일 recon 결과를 정규화한 증거 객체.
    모든 tool output은 반드시 이 schema로 변환한다.
    """
    id: str
    target_id: str
    target: str
    type: EvidenceType
    value: Dict[str, Any]
    source_tool: str
    source_command_ref: str        # raw output 파일 경로 또는 참조
    confidence: float              # 0.0 ~ 1.0
    timestamp: str
    tags: List[str]
    host: str = ""

    @classmethod
    def make(
        cls,
        target_id: str,
        target: str,
        ev_type: EvidenceType,
        value: Dict[str, Any],
        source_tool: str,
        source_command_ref: str,
        confidence: float,
        tags: List[str],
        host: str = "",
    ) -> "Evidence":
        return cls(
            id=_short_id("E"),
            target_id=target_id,
            target=target,
            type=ev_type,
            value=value,
            source_tool=source_tool,
            source_command_ref=source_command_ref,
            confidence=min(1.0, max(0.0, confidence)),
            timestamp=utc_now(),
            tags=tags,
            host=host,
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "target_id": self.target_id,
            "target": self.target,
            "host": self.host,
            "type": self.type.value,
            "value": self.value,
            "source_tool": self.source_tool,
            "source_command_ref": self.source_command_ref,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Evidence":
        return cls(
            id=d["id"],
            target_id=d["target_id"],
            target=d["target"],
            host=d.get("host", ""),
            type=EvidenceType(d["type"]),
            value=d["value"],
            source_tool=d["source_tool"],
            source_command_ref=d["source_command_ref"],
            confidence=d["confidence"],
            timestamp=d["timestamp"],
            tags=d["tags"],
        )


# ── Conflict ──────────────────────────────────────────────────────────────────

@dataclass
class ConflictObject:
    """
    두 개 이상의 evidence가 서로 충돌할 때 생성되는 객체.
    Claude에게 raw 충돌 판단을 맡기지 않기 위해 자동 생성한다.
    """
    id: str
    target_id: str
    conflict_type: ConflictType
    evidence_ids: List[str]
    description: str
    severity: str               # "low" | "medium" | "high"
    policy: str                 # "require_secondary_confirmation" 등
    allowed_next_action_class: str
    requires_human_review: bool = False

    @classmethod
    def make(
        cls,
        target_id: str,
        conflict_type: ConflictType,
        evidence_ids: List[str],
        description: str,
        severity: str = "medium",
        policy: str = "require_secondary_confirmation",
        allowed_next_action_class: str = "non_invasive_verify",
        requires_human_review: bool = False,
    ) -> "ConflictObject":
        return cls(
            id=_short_id("C"),
            target_id=target_id,
            conflict_type=conflict_type,
            evidence_ids=evidence_ids,
            description=description,
            severity=severity,
            policy=policy,
            allowed_next_action_class=allowed_next_action_class,
            requires_human_review=requires_human_review,
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "target_id": self.target_id,
            "conflict_type": self.conflict_type.value,
            "evidence_ids": self.evidence_ids,
            "description": self.description,
            "severity": self.severity,
            "policy": self.policy,
            "allowed_next_action_class": self.allowed_next_action_class,
            "requires_human_review": self.requires_human_review,
        }


# ── Target State sub-models ──────────────────────────────────────────────────

@dataclass
class ExposureState:
    level: str               # "internet_facing" | "internal" | "unknown" | "conflict"
    confidence: float
    evidence_ids: List[str]


@dataclass
class ServiceState:
    port: int
    protocol: str
    service: str
    version: str             # "unknown" if unconfirmed
    confidence: float
    evidence_ids: List[str]


@dataclass
class TechnologyState:
    name: str
    version: str
    confidence: float
    evidence_ids: List[str]


@dataclass
class MitigationState:
    type: str                # "waf" | "firewall" | "auth_required" | ...
    vendor: str
    confidence: float
    evidence_ids: List[str]


@dataclass
class VulnerabilityCandidate:
    id: str
    description: str
    cve: Optional[str]
    severity: str
    confidence: float
    evidence_ids: List[str]
    source_tool: str


# ── Target State ─────────────────────────────────────────────────────────────

@dataclass
class TargetState:
    """
    Evidence Store를 기반으로 target별 현재 상태를 요약한 모델.
    Claude에게는 raw evidence 대신 이 객체를 전달한다.
    """
    target_id: str
    target: str
    hosts: List[str]
    exposure: ExposureState
    services: List[ServiceState]
    technologies: List[TechnologyState]
    mitigations: List[MitigationState]
    vulnerability_candidates: List[VulnerabilityCandidate]
    conflicts: List[ConflictObject]
    last_updated: str

    def to_dict(self) -> dict:
        return {
            "target_id": self.target_id,
            "target": self.target,
            "hosts": self.hosts,
            "exposure": {
                "level": self.exposure.level,
                "confidence": self.exposure.confidence,
                "evidence_ids": self.exposure.evidence_ids,
            },
            "services": [
                {
                    "port": s.port,
                    "protocol": s.protocol,
                    "service": s.service,
                    "version": s.version,
                    "confidence": s.confidence,
                    "evidence_ids": s.evidence_ids,
                }
                for s in self.services
            ],
            "technologies": [
                {
                    "name": t.name,
                    "version": t.version,
                    "confidence": t.confidence,
                    "evidence_ids": t.evidence_ids,
                }
                for t in self.technologies
            ],
            "mitigations": [
                {
                    "type": m.type,
                    "vendor": m.vendor,
                    "confidence": m.confidence,
                    "evidence_ids": m.evidence_ids,
                }
                for m in self.mitigations
            ],
            "vulnerability_candidates": [
                {
                    "id": v.id,
                    "description": v.description,
                    "cve": v.cve,
                    "severity": v.severity,
                    "confidence": v.confidence,
                    "evidence_ids": v.evidence_ids,
                    "source_tool": v.source_tool,
                }
                for v in self.vulnerability_candidates
            ],
            "conflicts": [c.to_dict() for c in self.conflicts],
            "last_updated": self.last_updated,
        }


# ── Context Scores ────────────────────────────────────────────────────────────

@dataclass
class ContextScores:
    """Evidence Store에서 파생된 context 품질 점수."""
    exposure_confidence: float        # exposure evidence 평균 confidence
    service_confidence: float         # service evidence 평균 confidence
    technology_confidence: float      # technology evidence 평균 confidence

    def to_dict(self) -> dict:
        return {
            "exposure_confidence": round(self.exposure_confidence, 3),
            "service_confidence": round(self.service_confidence, 3),
            "technology_confidence": round(self.technology_confidence, 3),
        }


# ── Alpha Decision ────────────────────────────────────────────────────────────

@dataclass
class AlphaDecision:
    """Alpha engine 계산 결과 — blend_score = α × LLM + (1-α) × static."""
    alpha: float
    static_score: float
    llm_score: Optional[float]        # LLM 호출 전이면 None
    blend_score: float
    context_description: str
    timestamp: str

    def to_dict(self) -> dict:
        return {
            "alpha": round(self.alpha, 4),
            "static_score": round(self.static_score, 4),
            "llm_score": round(self.llm_score, 4) if self.llm_score is not None else None,
            "blend_score": round(self.blend_score, 4),
            "context_description": self.context_description,
            "timestamp": self.timestamp,
        }


# ── Policy Gate Decision ──────────────────────────────────────────────────────

@dataclass
class PolicyGateDecision:
    """Policy Gate 판정 결과."""
    decision: str                          # "allow" | "block" | "require_approval"
    reason: str
    allowed_action_classes: List["ActionClass"]
    requires_human_approval: bool
    timestamp: str

    def to_dict(self) -> dict:
        return {
            "decision": self.decision,
            "reason": self.reason,
            "allowed_action_classes": [ac.value for ac in self.allowed_action_classes],
            "requires_human_approval": self.requires_human_approval,
            "timestamp": self.timestamp,
        }


# ── Scope ─────────────────────────────────────────────────────────────────────

@dataclass
class Scope:
    authorized: bool
    targets: List[str]                     # 승인된 target_id 목록
    max_action_class: "ActionClass"        # 이 수준까지만 허용
    disallowed_action_classes: List["ActionClass"] = field(default_factory=list)

    _CLASS_ORDER = [
        "passive",
        "non_invasive_verify",
        "limited_active_scan",
        "intrusive_validation",
        "exploit_like_validation",
        "post_exploitation",
    ]

    def allows(self, action_class: "ActionClass") -> bool:
        if action_class in self.disallowed_action_classes:
            return False
        try:
            ac_idx  = self._CLASS_ORDER.index(action_class.value)
            max_idx = self._CLASS_ORDER.index(self.max_action_class.value)
            return ac_idx <= max_idx
        except ValueError:
            return False

    def target_authorized(self, target_id: str) -> bool:
        if not self.targets:
            return True    # 빈 목록 = 제한 없음
        return target_id in self.targets


# ── Scope Rule (implementation_plan.md §3 ScopeGuard용) ──────────────────────

@dataclass
class ScopeRule:
    """
    ScopeGuard가 target/action을 판정하는 데 쓰는 승인 범위 정의.
    Scope(세션 단위, target_id 기반)와는 별도로 domain/CIDR 기반 판정,
    subdomain opt-in, private range 정책 등 실제 pentest 계약서에 가까운
    조건을 표현한다.
    """
    authorized_targets: List[str] = field(default_factory=list)
    authorized_domains: List[str] = field(default_factory=list)
    authorized_cidrs: List[str] = field(default_factory=list)
    denied_targets: List[str] = field(default_factory=list)
    allow_subdomains: bool = False
    max_subdomains: int = 0
    allow_private_ranges: bool = False
    max_action_class: str = "limited_active_scan"
    allowed_profiles: List[str] = field(default_factory=lambda: ["recon_only", "standard_external_pentest"])
    approval_required_action_classes: List[str] = field(default_factory=lambda: [
        "intrusive_validation",
        "exploit_like_validation",
        "post_exploitation",
    ])
    expires_at: Optional[str] = None
    metadata: Dict[str, str] = field(default_factory=dict)
