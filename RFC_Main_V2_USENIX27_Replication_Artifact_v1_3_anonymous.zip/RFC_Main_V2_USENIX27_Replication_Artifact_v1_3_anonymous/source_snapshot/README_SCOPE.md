# Source Snapshot Scope

This directory is a curated, anonymous snapshot of the code needed to inspect the RFC confirmation mechanism and the experiment/evaluation harness.

Included:
- `orchestrator/finding_service.py`: central structural confirmation gate.
- `orchestrator/proof_bundle.py`: ProofBundle schema.
- `orchestrator/proof_obligations.py`: vulnerability-family proof obligations.
- `orchestrator/finding_lifecycle.py`: probable/confirmed lifecycle integration.
- `research/risk_controlled_confirmation_experiment/`: acquisition, provenance, risk statistics, Phase-2, and final-evaluation code.
- `tests_core/`: focused structural-gate tests.

The snapshot was reconstructed read-only from the pre-existing project archive and overlaid, in order, with the audited patch payloads listed in `../provenance/PATCH_ORDER.txt`.

Excluded:
- unrelated product/application code,
- `.git` history,
- third-party cloned benchmark source trees,
- caches and `*:Zone.Identifier`,
- intermediate debug/failed runs not used by the paper.

The frozen paper results do not depend on excluded code.

Note: the larger application's `orchestrator/__init__.py` is intentionally omitted; the included paper-relevant modules form a Python namespace package for focused inspection/tests without importing unrelated application components.
