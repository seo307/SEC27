# License Note for Anonymous Review

This anonymous review package is supplied for peer-review and reproducibility evaluation. A stable public-release location and explicit redistribution license should be selected for the camera-ready artifact if the paper is accepted. Third-party benchmark repositories are not redistributed in this package.
