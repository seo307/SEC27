# Artifact Claims and Paper Mapping

## C1 — Final ablation corpus
**Claim:** 24 unique evaluation cases spanning six vulnerability families; 11 external reviewed, 12 controlled stress, and one Phase-2 external candidate.

**Frozen evidence:** `data/final_evaluation/CASEPACK_SUMMARY.json`

**Reproduce:** `python3 scripts/smoke_test.py`

## C2 — Structural proof gating removes observed unsupported/unsafe/false promotions
**Claim:** validator-only produces 1 false confirmation, 5 unsupported confirmations, and 2 unsafe promotions; proof-gate-only produces 0/0/0.

**Frozen evidence:** `data/final_evaluation/ablation_rows.jsonl`

**Reproduce:** `./run_reproduce.sh`

## C3 — Confidence threshold does not improve over validator-only in this casepack
**Claim:** confidence-threshold and validator-only decisions are identical on 24/24 cases.

**Reproduce:** `./run_reproduce.sh`

## C4 — Full RFC and proof-gate-only are identical at the per-case layer in this casepack
**Claim:** proof-gate-only and RFC-full decisions are identical on 24/24 cases. The statistical risk layer is evaluated separately at corpus level.

**Reproduce:** `./run_reproduce.sh`

## C5 — Raw agent ambiguity behavior
**Claim:** the frozen GPT-5.4 baseline over-confirms 2 of 5 ambiguous-positive cases.

**Frozen evidence:** `data/final_evaluation/agent_outputs/openai-gpt-5.4.jsonl`, separate oracle rows in `casepack_oracle.jsonl`.

**Reproduce:** `./run_reproduce.sh`

## C6 — Formal risk certificate is unavailable
**Claim:** 0 observed false confirmations among 7 independent certification confirmations yields one-sided 95% exact upper bound 0.3481636551311609, above q=.10; certificate = NOT READY.

**Frozen evidence:** `data/final_evaluation/formal_progress.json` and scientific registry snapshot.

**Reproduce:** `./run_reproduce.sh`

## C7 — Independence policy
Repeated internal runs and controlled stress cases contribute formal N=0; accepted external environments are deduplicated by environment fingerprint.

**Frozen evidence:** `FROZEN_METHOD_RULES.json`, `SCIENTIFIC_REGISTRY_SNAPSHOT.json`, internal controlled `oracle_live.jsonl`, and accepted external run archives.

## C8 — Artifact integrity / pre-agent freezing
Method rules and registry were frozen before the agent run; final outputs are manifest-bound.

**Frozen evidence:** `data/final_evaluation/PRE_AGENT_MANIFEST.sha256`, `FINAL_MANIFEST.sha256`.

**Reproduce:** `python3 scripts/verify_artifact.py`
