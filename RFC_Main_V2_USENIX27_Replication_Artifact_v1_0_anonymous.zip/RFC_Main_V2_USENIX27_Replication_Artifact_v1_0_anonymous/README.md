# RFC: Risk-Controlled Finding Confirmation — Anonymous Replication Artifact

This is the anonymous submission-time artifact for a USENIX Security '27 paper on risk-controlled confirmation of vulnerability findings produced by autonomous offensive-security agents.

## Artifact scope

The package supports three evaluation tiers:

1. **Frozen-results reproduction (recommended, no network/API/Docker):**
   verifies hashes and recomputes the paper's 24-case ablation metrics and the exact zero-failure Clopper–Pearson checkpoint.
2. **Source inspection / focused tests:**
   provides a curated RFC/ProofBundle/experiment source snapshot and focused confirmation-gate tests.
3. **Optional live rerun:**
   provides the final evaluation and Phase-2 scripts. Live LLM reruns require the reviewer's own provider credentials; live benchmark acquisition additionally requires Docker/Compose and public benchmark sources. These optional reruns are not required to reproduce the paper's reported tables.

**No existing experimental record was edited to construct this artifact.** The package copies frozen artifacts and creates only derived indices, documentation, manifests, and standalone reproduction scripts.

## Getting Started (about 2–5 minutes)

Requirements for the primary reproduction path:
- Linux/macOS/WSL
- Python 3.9+
- no third-party Python packages
- no network access

Run:

```bash
./run_smoke.sh
./run_reproduce.sh
```

Expected smoke checks include:
- 24 final ablation cases
- 6 vulnerability families
- 11 accepted external reviewed environments in the casepack
- 12 controlled stress cases
- 24/24 completed frozen GPT-5.4 decisions
- formal certification confirmations = 7
- observed false confirmations = 0
- q=.10 certificate = NOT READY

`run_reproduce.sh` writes:
- `reproduced/REPRODUCED_RESULTS.json`
- `reproduced/REPRODUCED_ABLATION.csv`

The regenerated overall table must match `data/final_evaluation/FINAL_ABLATION_RESULTS.csv`.

## Expected main results

| Method | Confirm | False conf. | FCR | Unsupported | Unsafe | Ideal-confirm recall |
|---|---:|---:|---:|---:|---:|---:|
| Agent raw (GPT-5.4) | 14 | 0 | 0.0% | 4 | 2 | 92.3% |
| Validator only | 15 | 1 | 6.7% | 5 | 2 | 100% |
| Confidence >= .80 | 15 | 1 | 6.7% | 5 | 2 | 100% |
| Proof gate only | 10 | 0 | 0.0% | 0 | 0 | 76.9% |
| RFC full | 10 | 0 | 0.0% | 0 | 0 | 76.9% |

Additional frozen checks:
- validator-only and confidence-threshold decisions are identical on 24/24 cases;
- proof-gate-only and RFC-full per-case decisions are identical on 24/24 cases;
- the raw GPT-5.4 baseline over-confirms 2 of 5 ambiguous-positive cases;
- formal checkpoint: 0 false confirmations among 7 independent certification confirmations;
- one-sided 95% exact upper bound = 0.3481636551311609;
- predeclared q = 0.10, therefore certification is **NOT READY**.

## Directory map

```text
.
├── README.md
├── ARTIFACT_CLAIMS.md
├── MANIFEST.sha256
├── ARTIFACT_METADATA.json
├── ANONYMIZATION_REPORT.json
├── run_smoke.sh
├── run_reproduce.sh
├── Dockerfile.reproduce
├── scripts/
│   ├── verify_artifact.py
│   ├── smoke_test.py
│   ├── anonymization_scan.py
│   └── reproduce_paper_results.py
├── data/
│   ├── final_evaluation/          # canonical 24-case frozen evaluation
│   ├── internal_controlled/       # 12 cases x 5 repetitions; formal N=0
│   └── accepted_external_runs/    # first-accepted provenance runs for 11 envs
├── source_snapshot/
│   ├── orchestrator/              # structural ProofBundle confirmation gate
│   ├── research/risk_controlled_confirmation_experiment/
│   └── tests_core/
├── provenance/
│   ├── PATCH_ORDER.txt
│   └── audited_patches/
└── docs/
    ├── OPEN_SCIENCE_APPENDIX_TEXT.md
    ├── ARTIFACT_EVALUATION_GUIDE.md
    ├── ANONYMIZATION_AND_RELEASE.md
    ├── KNOWN_LIMITATIONS.md
    └── THIRD_PARTY.md
```

## Frozen-result provenance

The canonical final evaluation is the immutable run corresponding to:
`20260811T053711Z-finaleval-26179`.

It contains:
- blinded agent inputs,
- frozen GPT-5.4 outputs,
- separated oracle rows,
- frozen method rules,
- registry snapshot,
- joined ablation rows,
- overall/category/scenario/cohort CSV and JSON tables,
- pre-agent and final SHA-256 manifests,
- formal progress and Juice Shop source-oracle freeze.

The accepted external provenance directory contains the first-accepted acquisition runs referenced by the scientific registry. Internal controlled repetitions are provided separately and are explicitly excluded from formal independent N.

## Source tests

The complete product repository is intentionally not redistributed. `source_snapshot/` contains the paper-relevant confirmation and experiment code, reconstructed from the frozen project archive and overlaid with the audited patch lineage.

For a lightweight structural inspection:

```bash
python3 -m pip install pydantic pytest
PYTHONPATH=source_snapshot python3 -m pytest -q source_snapshot/tests_core
```

The larger experiment harness has additional optional dependencies in `requirements-source.txt`.

## Optional live LLM rerun

The paper's exact GPT-5.4 responses are frozen and already included; **a live rerun is not expected to be bit-for-bit identical** because hosted model/service behavior may change.

If a reviewer nevertheless wants to execute a new blinded run, see:
`source_snapshot/research/risk_controlled_confirmation_experiment/phase2/FINAL_EVALUATION_GUIDE.md`.

A provider API key and `openai` Python SDK are required. Do not replace the canonical frozen agent outputs when reproducing the paper.

## Safety and ethics

Live acquisition code is intended only for local/public intentionally vulnerable benchmark environments. The artifact's paper-facing reproduction path is completely offline and performs no network interaction or exploitation.

## Double-blind status

This review package has no Git history, author names, personal email addresses, user home paths, or organization-specific identifiers. `scripts/anonymization_scan.py` performs a release scan; its frozen result is written to `ANONYMIZATION_REPORT.json`.

Before uploading, host the package through an anonymous, non-tracking link. For USENIX Security '27, the CFP recommends anonymous.4open.science with conference ID `SEC27`.
