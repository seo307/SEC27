# Open Science Appendix — Artifact Text

The anonymous submission artifact contains the RFC implementation snapshot; frozen method rules; the scientific environment registry; immutable first-accepted external acquisition runs; the internal controlled benchmark captures/oracle; blinded final agent inputs; the frozen GPT-5.4 outputs used in the paper; separately stored oracle rows; scripts for regenerating the 24-case ablation tables and formal certification checkpoint; and SHA-256 manifests. The primary table reproduction requires only Python and no network access. Repeated internal benchmark observations are included for mechanism reproducibility but are explicitly marked as contributing formal N=0.

Anonymous review URL: **REPLACE_WITH_ANONYMOUS_NON_TRACKING_URL**

The artifact is intended to remain frozen after the USENIX Security '27 artifact grace period. Live LLM or Docker benchmark reruns are optional and are not required to reproduce the reported quantitative results.
