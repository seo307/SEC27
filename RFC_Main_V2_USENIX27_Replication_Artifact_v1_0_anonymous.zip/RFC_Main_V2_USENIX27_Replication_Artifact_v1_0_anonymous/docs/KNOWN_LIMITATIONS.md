# Known Artifact Limitations

1. The frozen raw-agent baseline uses one hosted model identifier (`gpt-5.4`). Hosted services can change; therefore a live rerun is not expected to be byte-identical. The exact responses used by the paper are included.
2. The final 24-case ablation contributes formal N=0. Formal certification is computed only from the explicitly accepted external registry.
3. The structural proof gate and full RFC produce identical per-case decisions on this frozen casepack. The risk layer's distinct role is corpus-level certification/refusal.
4. The scientific registry has only seven independent certification confirmations; the q=.10 certificate is therefore NOT READY.
5. The source snapshot is curated to the paper-relevant mechanism and experiment code, not the entire larger application repository.
6. Third-party benchmark source trees are not redistributed. Their provenance appears in frozen run records; optional live reruns may fetch public benchmark sources.
7. One Phase-2 Juice Shop candidate is excluded from formal registry admission because its independent source-only oracle was frozen post-capture.
